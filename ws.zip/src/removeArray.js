
arr1=[3,4,3,3]
arr2=[2,3,4,3]
var i=0;
var j=0;
for(i=0;i<arr1.length;i++){
    for(j=0;j<arr2.length;j++){
        if(arr1[i]===arr2[j]){
            arr2.splice(j,1);
            j--;
            break;
        }
    }
}

console.log(arr2);