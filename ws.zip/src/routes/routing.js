const express = require('express');
const routing = express.Router();
const teamTaskService=require('../service/users');
const ProjectCreation=require('../model/projectcreation');
const TaskCreation=require('../model/taskCreation');
const RequestCreation =require('../model/requestcreation');
const EventCreation=require('../model/eventCreation');
const NotificationCreation=require('../model/notificationCreation');
routing.post('/login', (req, res, next) => {
    let userEmailId = req.body.emailId;
    let password = req.body.password;
    console.log(userEmailId,password);
    
    teamTaskService.password(userEmailId, password).then((userDetail) => {
        res.json({"message":userDetail});
    }).catch((err) => next(err))
})
routing.get('/downloadReportByProject/:projectId',(req,res,next)=>{
    let projectId=req.params.projectId;
    teamTaskService.downloadReportByProject(projectId).then((project)=>{
        res.json(project);
    }).catch((err)=>next(err))
})
routing.get('/downloadReportByUser/:userId',(req,res,next)=>{
    let userId=req.params.userId;
    teamTaskService.downloadReportByUser(userId).then((user)=>{
        res.json(user);
    }).catch((err)=>next(err))
})
routing.get('/getManagerId',(req,res,next)=>{
    
    teamTaskService.getManagerId().then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
routing.get('/getProjectByProjectId/:projectId',(req,res,next)=>{
    let projectId=req.params.projectId;
    teamTaskService.getProjectByProjectId(projectId).then((project)=>{
        res.json(project);
    }).catch((err)=>next(err))
})
routing.get('/getTaskByTaskId/:projectId/:tasksId',(req,res,next)=>{
    let projectId=req.params.projectId;
    let tasksId=req.params.tasksId;
    teamTaskService.getTaskByTaskId(projectId,tasksId).then((task)=>{
        res.json(task);
    }).catch((err)=>next(err))
})
routing.post('/createNotification/:managerId', (req, res, next) => {
    let managerId= req.params.managerId;
    const notificationCreation = new NotificationCreation(req.body);
    notificationCreation.managerId=managerId;
    teamTaskService.createNotification(notificationCreation).then((nId)=>{
        res.json({"message":"Notification creation is successful with notification id :"+ nId});
    }).catch((err)=> next(err))
   
})

routing.post('/createProject/:managerId', (req, res, next) => {
    let managerId= req.params.managerId;
    const projectCreation = new ProjectCreation(req.body);
    projectCreation.managerId=managerId;
    projectCreation.status="Ongoing";
    teamTaskService.createProject(projectCreation).then((pId)=>{
        res.json({"message":"Project creation is successful with project id :"+ pId});
    }).catch((err)=> next(err))
   
})
routing.put('/updateProject/:managerId/:projectId', (req, res, next) => {
    let projectId=req.params.projectId;
    const projectCreation = new ProjectCreation(req.body);
    projectCreation.projectId=projectId;
    teamTaskService.updateProject(projectCreation).then((pId)=>{
        res.json({"message":"Project updation is successful for project id :"+ pId});
    }).catch((err)=> next(err))
   
})
routing.delete('/deleteProject/:projectId',(req,res,next)=>{
    let projectId=req.params.projectId;
    teamTaskService.deleteProject(projectId).then((pId)=>{
        res.json({"message":"Project deletion is successful for project id :"+ pId});
    }).catch((err)=> next(err))
})
routing.put('/updateTask/:managerId/:projectId', (req, res, next) => {
    let projectId=req.params.projectId;
    const taskCreation = new TaskCreation(req.body);
    teamTaskService.updateTask(taskCreation,projectId).then((tId)=>{
        res.json({"message":"Task updation is successful for task id :"+ tId});
    }).catch((err)=> next(err))
   
})
routing.delete('/deleteTask/:projectId/:tasksId',(req,res,next)=>{
    let projectId=req.params.projectId;
    let tasksId=req.params.tasksId;
    teamTaskService.deleteTask(projectId,tasksId).then((tId)=>{
        res.json({"message":"Task deletion is successful for task id :"+ tId});
    }).catch((err)=> next(err))
})
routing.put('/addNewTask/:managerId/:projectId', (req, res, next) => {
    let projectId=req.params.projectId;
    const taskCreation = new TaskCreation(req.body);
    teamTaskService.addNewTask(taskCreation,projectId).then((tId)=>{
        res.json({"message":"Task Addition is successful with task id :"+ tId});
    }).catch((err)=> next(err))
   
})
routing.get('/viewAllProjects', (req,res,next)=>{
    teamTaskService.viewAllProjects().then((projects)=>{
        res.json(projects);
    }).catch((err)=>next(err))
})
routing.get('/getProjectEmpNames/:projectName', (req,res,next)=>{
    let projectName=req.params.projectName;
    teamTaskService.getProjectEmpNames(projectName).then((emps)=>{
        res.json(emps);
    }).catch((err)=>next(err))
})

routing.get('/viewAllTeamMembersAndAvaialbilityByType',(req,res,next)=>{
    teamTaskService.viewAllTeamMembersAndAvaialbilityByType().then((emps)=>{
        res.json(emps);

    }).catch((err)=>next(err))
})

routing.post('/updateStatus/:empId', (req,res,next)=>{
    
    
    let empId=req.params.empId;
    const requestCreation = new RequestCreation(req.body);
    requestCreation.userId=empId;
    teamTaskService.updateStatus(requestCreation).then((result)=>{
        res.json({"message":"Request for update status has been successfully made with id "+ result});
    })
    .catch((err)=>next(err))
})
routing.put('/updateProjectTimeline/:projectId/:managerId', (req,res,next)=>{
    let projectId=req.params.projectId;
    let managerId=req.params.managerId;
    let startDate=req.body.startDate;
    let endDate=req.body.endDate;

    teamTaskService.updateProjectTimeline(projectId,managerId,startDate,endDate).then((result)=>{
        res.json({"message":"Timeline has been Successfully been updated for project id: "+ result});
    })
    .catch((err)=>next(err))
})

routing.put('/updateTaskTimeline/:projectId/:managerId/:taskId', (req,res,next)=>{
    let projectId=req.params.projectId;
    let managerId=req.params.managerId;
    let taskId=req.params.taskId;
    let startDate=req.body.startDate;
    let endDate=req.body.endDate;

    teamTaskService.updateProjectTimeline(projectId,managerId,startDate,endDate).then((result)=>{
        res.json({"message":"Timeline has been Successfully been updated for project id: "+ result});
    })
    .catch((err)=>next(err))
})

routing.get('/viewOngoingProjects/:managerId',(req,res,next)=>{
    let managerId=req.params.managerId;
    teamTaskService.viewOngoingProjects(managerId).then((projects)=>{
        res.json(projects);
    }).catch((err)=>next(err))
})
routing.get('/viewOngoingProjectDetails/:managerId/:projectId',(req,res,next)=>{
    let projectId=req.params.projectId;
    let managerId=req.params.managerId;
    teamTaskService.viewOngoingProjectDetails(managerId,projectId).then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})

routing.get('/viewCompletedProjects/:managerId',(req,res,next)=>{
    let managerId=req.params.managerId;
    teamTaskService.viewCompletedProjects(managerId).then((projects)=>{
        res.json(projects);
    }).catch((err)=>next(err))
})

routing.get('/viewCompletedProjectDetails/:managerId/:projectId',(req,res,next)=>{
    let projectId=req.params.projectId;
    let managerId=req.params.managerId;
    teamTaskService.viewCompletedProjectDetails(managerId,projectId).then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})

// routing.put('/assignTask/:projectId',(req,res,next)=>{
//     let projectId=req.params.projectId;
//     const taskCreation=new TaskCreation(req.body);
    
//     teamTaskService.assignTask(projectId,taskCreation).then((taskId)=>{
//         res.json({"message":"Task assignment is successfull with task id :"+ taskId});
//     }).catch((err)=>next(err))

// })

// routing.put('/addTeamMemberWithNewTask/:projectId',(req,res,next)=>{
//     let projectId=req.params.projectId;
//     const taskCreation=new TaskCreation(req.body);
//     console.log(taskCreation.empId[0])
//     teamTaskService.addTeamMemberWithNewTask(projectId,taskCreation).then((taskId)=>{
//         res.json({"message":"Employee has been added to project with task id :"+ taskId});
//     }).catch((err)=>next(err))
// })
// routing.put('/addTeamMemberToExistingTask/:projectId/:taskId/empId',(req,res,next)=>{
//     let projectId=req.params.projectId;
//     let taskId=req.params.taskId;
//     let empId=req.params.empId;
//     teamTaskService.addTeamMemberToExistingTask(projectId,taskId,empId).then((tid)=>{
//         res.json({"message":"Employee has been added to project with task id :"+ tid});
//     }).catch((err)=>next(err))
// })
routing.get('/getEmpDetails/:empId',(req,res,next)=>{
    let empId=req.params.empId;
    teamTaskService.getEmpDetails(empId).then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
routing.get('/searchEmp/:emp',(req,res,next)=>{
    let emp=req.params.emp;
    teamTaskService.searchEmp(emp).then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
routing.get('/viewAllEmployees',(req,res,next)=>{
    teamTaskService.viewAllEmployees().then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})

routing.get('/viewLeaveRequests',(req,res,next)=>{
    teamTaskService.viewLeaveRequests().then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
routing.get('/viewTimeExtensionRequests',(req,res,next)=>{
    teamTaskService.viewTimeExtensionRequests().then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
routing.get('/viewNewTaskRequests',(req,res,next)=>{
    teamTaskService.viewNewTaskRequests().then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
routing.get('/viewStatusUpdateRequest',(req,res,next)=>{
    teamTaskService.viewStatusUpdateRequest().then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
routing.put('/acceptLeaveRequests/:userId/:requestId',(req,res,next)=>{
    let userId=req.params.userId;
    let requestId=req.params.requestId;
    let requestStatus=req.body.requestStatus;
    teamTaskService.acceptLeaveRequests(userId,requestId,requestStatus).then((status)=>{
        res.json({"message":"Request has been "+ status});
    }).catch((err)=>next(err))
})
routing.put('/acceptTimeExtensionRequests/:projectId/:tasksId/:requestId',(req,res,next)=>{
    let projectId=req.params.projectId;
    let tasksId=req.params.tasksId;
    let requestId=req.params.requestId;
    let requestStatus=req.body.requestStatus;
    let extension=req.body.extension;
    teamTaskService.acceptTimeExtensionRequests(projectId,tasksId,requestId,requestStatus,extension).then((status)=>{
        res.json({"message":"Request has been "+ status});
    }).catch((err)=>next(err))
})
routing.put('/acceptNewTaskRequests/:projectId/:userId/:requestId',(req,res,next)=>{
    let projectId=req.params.projectId;
    let requestId=req.params.requestId;
    let requestStatus="Accepted";
    const taskCreation=new TaskCreation(req.body);
    taskCreation.status="Ongoing";
    teamTaskService.acceptNewTaskRequests(projectId,taskCreation,requestId,requestStatus).then((status)=>{
        res.json({"message":"Request has been "+ status});
    }).catch((err)=>next(err))
})
routing.put('/acceptStatusUpdateRequests/:projectId/:tasksId/:requestId',(req,res,next)=>{
    let projectId=req.params.projectId;
    let tasksId=req.params.tasksId;
    let requestId=req.params.requestId;
    let requestStatus=req.body.requestStatus;
    let value=req.body.value;
    teamTaskService.acceptStatusUpdateRequests(projectId,tasksId,requestId,requestStatus, value).then((status)=>{
        res.json({"message":"Request has been "+ status});
    }).catch((err)=>next(err))
})
routing.put('/updateRequestStatus/:requestId',(req,res,next)=>{
    let requestId=req.params.requestId;
    let requestStatus=req.body.requestStatus;
    teamTaskService.updateRequestStatus(requestId,requestStatus).then((status)=>{
        res.json({"message":"Request has been "+ status});
    }).catch((err)=>next(err))
})
routing.get('/viewAcceptedRequests',(req,res,next)=>{
    teamTaskService.viewAcceptedRequests().then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
routing.post('/createEvent/:managerId',(req,res,next)=>{

    let managerId=req.params.managerId;
    const eventCreation = new EventCreation(req.body);
        eventCreation.createdBy=managerId;
    eventCreation.status="Upcoming";
    
   
    
    teamTaskService.createEvent(eventCreation).then((eId)=>{
        res.json({"message":"event creation is successful with event id :"+ eId});
    }).catch((err)=> next(err))
})
routing.put('/updateEvent/:managerId/:eventId',(req,res,next)=>{
    let managerId=req.params.managerId;
    let eventId=req.params.eventId;
    const eventCreation = new EventCreation(req.body);
    eventCreation.createdBy=managerId;
    eventCreation.eventId=eventId;
    eventCreation.status="Upcoming";
    teamTaskService.updateEvent(eventCreation).then((eId)=>{
        res.json({"message":"event updation is successful for event id :"+ eId});
    }).catch((err)=> next(err))
})
routing.delete('/deleteEvent/:eventId',(req,res,next)=>{
    let eventId=req.params.eventId;
    teamTaskService.deleteEvent(eventId).then((eId)=>{
        res.json({"message":"event deletion is successful for event id :"+ eId});
    }).catch((err)=> next(err))
})
routing.get('/viewEventByDate/:eventDate/:userId',(req,res,next)=>{
    let eventDate=new Date(req.params.eventDate);
    
    let userId=req.params.userId;
    teamTaskService.viewEventByDate(userId,eventDate).then((events)=>{
        res.json(events);
    }).catch((err)=> next(err))
})
routing.get('/viewEventByEventId/:eventId',(req,res,next)=>{
    let eventId=req.params.eventId;
    teamTaskService.viewEventByEventId(eventId).then((event)=>{
        res.json(event);
    }).catch((err)=> next(err))
})
// routing.get('/viewCompletedTasksForTeamMember/:empId',(req,res,next)=>{
//     let empId=req.params.empId;
//     teamTaskService.viewCompletedTasksForTeamMember(empId).then((data)=>{
//         res.json(data);
//     }).catch((err)=>next(err))
// })

routing.get('/viewOngoingTasksForTeamMember/:empId',(req,res,next)=>{
    let empId=req.params.empId;
    teamTaskService.viewOngoingTasksForTeamMember(empId).then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})


routing.get('/viewOngoingProjectsForTeamMember/:empId',(req,res,next)=>{
    let empId=req.params.empId;
    teamTaskService.viewOngoingProjectsForTeamMember(empId).then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})

routing.get('/viewOngoingProjectDetailsForTeamMember/:empId/:projectId',(req,res,next)=>{
    let projectId=req.params.projectId;
    let empId=req.params.empId;
    teamTaskService.viewOngoingProjectDetailsForTeamMember(empId,projectId).then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})

routing.get('/viewCompletedProjectsForTeamMember/:empId',(req,res,next)=>{
    let empId=req.params.empId;
    teamTaskService.viewCompletedProjectsForTeamMember(empId).then((projects)=>{
        res.json(projects);
    }).catch((err)=>next(err))
})

routing.get('/viewCompletedProjectDetailsForTeamMember/:empId/:projectId',(req,res,next)=>{
    let projectId=req.params.projectId;
    let empId=req.params.empId;
    teamTaskService.viewCompletedProjectDetailsForTeamMember(empId,projectId).then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
routing.get('/viewNotification/:empId',(req,res,next)=>{
    let empId=req.params.empId;
    teamTaskService.viewNotification(empId).then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
routing.delete('/deleteOneNotification/:empId/:notificationId',(req,res,next)=>{
    let empId=req.params.empId;
    let notificationId=req.params.notificationId;
    teamTaskService.deleteOneNotification(empId,notificationId).then((data)=>{
        res.json({"message":"Notification deletion is successful for notification id :"+ data});
    }).catch((err)=>next(err))
})
routing.delete('/deleteAllNotifications/:empId',(req,res,next)=>{
    let empId=req.params.empId;
    teamTaskService.deleteAllNotifications(empId).then((data)=>{
        res.json({"message":"Notification deletion is successful for emp id :"+ data});
    }).catch((err)=>next(err))
})
routing.get('/viewRequestsForTeamMember/:userId',(req,res,next)=>{
    let userId=req.params.userId;
    teamTaskService.viewRequestsForTeamMember(userId).then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
routing.post('/createRequest/:userId',(req,res,next)=>{
    let userId=req.params.userId;
    const requestCreation = new RequestCreation(req.body);
    requestCreation.userId=userId;
    requestCreation.requestStatus="Pending";
    teamTaskService.createRequest(requestCreation).then((rId)=>{
        res.json({"message":"Request creation is successful with request id :"+ rId});
    }).catch((err)=> next(err))
})

// routing.get('/viewAllOngoingProjectsForTeamMember/:empId',(req,res,next)=>{
//     let empId=req.params.empId;
//     teamTaskService.viewAllOngoingProjectsForTeamMember(empId).then((data)=>{
//         res.json(data);
//     }).catch((err)=>next(err))
// })
routing.get('/viewAllTasksForTeamMember/:projectId',(req,res,next)=>{
    let projectId=req.params.projectId;
    teamTaskService.viewAllTasksForTeamMember(projectId).then((data)=>{
        res.json(data);
    }).catch((err)=>next(err))
})
module.exports = routing;