a ={
    "projectName": "TeamTaskManagementProject",
    "empId": ["U1002","U1005"],
    "status": "Completed",
    "timeline": {
        "startDate": "04-13-2019",
        "endDate": "04-15-2019"
    },
    "description": "To create task and team management software",
    "tasks": [{
        "tasksName": "create task",
        "empId": ["U1002"],
        "status": "Ongoing",
        "timeline": {
            "startDate": "04-13-2019",
            "endDate": "04-14-2019"
        },
        "comment": "Do it properly"
    },
    {
        "tasksName": "view task",
        "empId": ["U1005"],
        "status": "Ongoing",
        "timeline": {
            "startDate": "04-13-2019",
            "endDate": "04-14-2019"
        },
        "comment": "Do it properly"
    }]
}
b={
    "projectId": "P1003",
    "projectName": "TeamTaskManagementProject3",
    "userId": "U1005",
    "taskName": "create task",
    "tasksId": "T1001",
    "timeline": {
        "startDate": "05-02-2019",
        "endDate": "05-04-2019"
    },
    "taskStatus":"i have done my work"
    
}
c={
    "taskName": "backend testing Task",
    "comment":"abcd efgh",
    "empId":["U1007"],
    "timeline": {
        "startDate": "04-13-2019",
        "endDate": "04-14-2019"
    }
}
d={
    "eventName": "party",
    "projectName": "TeamTaskManagementProject2",
    "eventDate": "05-15-2019",
    "time": "18:20",
    "venue": "L2-006",
    "reason": "for enjoy",
    "members": ["U1005", "U1006"],
    'status': "Upcoming"
}