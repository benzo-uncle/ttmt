class RequestCreation {
    constructor(obj) {
        this.requestId=obj.requestId;
        this.projectId=obj.projectId;
        this.projectName=obj.projectName;
        this.userId=obj.userId;
        this.userName=obj.userName;
        this.timeline=obj.timeline;
        this.requestType=obj.requestType;
        this.requestReason=obj.requestReason;
        this.tasksId=obj.tasksId;
        this.taskName=obj.taskName;
        this.NoOfDays=obj.NoOfDays;
        this.requestStatus=obj.requestStatus;
        this.taskStatus=obj.taskStatus;

    }
}

module.exports = RequestCreation;