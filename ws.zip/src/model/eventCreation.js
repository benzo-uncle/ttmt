class EventCreation {
    constructor(obj) {
        this.eventId=obj.eventId;
        this.projectName=obj.projectName;
        this.eventName=obj.eventName;
        this.members=obj.members;
        this.eventDate=obj.eventDate;
        this.time=obj.time;
        this.createdBy=obj.createdBy;
        this.venue=obj.venue;
        this.status=obj.status;
        this.reason=obj.reason;
    }
}

module.exports = EventCreation;