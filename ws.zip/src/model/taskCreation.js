class TaskCreation {
    constructor(obj) {
        this.tasksId=obj.tasksId;
        this.tasksName=obj.tasksName;
        this.comment=obj.comment;
        this.empId=obj.empId;
        this.timeline=obj.timeline;
        this.status=obj.status;
    }
}

module.exports = TaskCreation;