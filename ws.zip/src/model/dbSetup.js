const collection = require('../utilities/connection');

const today = new Date();
const year = today.getFullYear();
const month = today.getMonth();
const day = today.getDate();
const hours = today.getHours();
const minutes = today.getMinutes();

const userDb = [
    {
        userId: "U1000",
        userName: "Bob",
        emailId: "m",
        password: "m",
        availability: "Assigned",
        empType: "Manager",
        projectsId: [],
    },
    {
        userId: "U1099",
        userName: "Alice",
        emailId: "t",
        password: "t",
        availability: "Assigned",
        empType: "TeamMember",
        projectsId: [],
    },
    {
        userId: "U1001",
        userName: "Ayushi",
        emailId: "ayushi14.trn@infosys.com",
        password: "ayushi@123",
        availability: "Assigned",
        empType: "Manager",
        projectsId: ["P1001"],
    },
    {
        userId: "U1000",
        userName: "Bob",
        emailId: "m",
        password: "m",
        availability: "Assigned",
        empType: "Manager",
        projectsId: [],
        tasksId: []
    },
    {
        userId: "U1002",
        userName: "Vasu",
        emailId: "vasu01.trn@infosys.com",
        password: "vasu@123",
        completedTaskCount:1,
        rating:3,
        availability: "Assigned",
        empType: "TeamMember",
        projectsId: ["P1001","P1004"],
    },
    {
        userId: "U1003",
        userName: "Rahul",
        emailId: "rahul37.trn@infosys.com",
        password: "rahul@123",
        availability: "Assigned",
        rating:0,
        completedTaskCount:0,
        empType: "TeamMember",
        projectsId: ["P1001","P1001"],
    },
    {
        userId: "U1004",
        userName: "Shubham",
        emailId: "shubham78.trn@infosys.com",
        password: "shubham@123",
        completedTaskCount:0,
        rating:0,
        availability: "Assigned",
        empType: "TeamMember",
        projectsId: ["P1001"],
    },
    {
        userId: "U1005",
        userName: "Khushali",
        emailId: "khushali01.trn@infosys.com",
        password: "khushali@123",
        availability: "Available",
        empType: "TeamMember",
        projectsId: ["P1002", "P1003"],
    },
    {
        userId: "U1006",
        userName: "Pulkit",
        emailId: "pulkit14.trn@infosys.com",
        password: "pulkit@123",
        availability: "Available",
        empType: "TeamMember",
        projectsId: ["P1002", "P1003"],
    },
    {
        userId: "U1007",
        userName: "rajat",
        emailId: "rajat15.trn@infosys.com",
        password: "rajat@123",
        availability: "Available",
        rating:1,
        empType: "TeamMember",
        projectsId: ["P1002", "P1004"],
    }
]
const projectDb = [
    {
        projectId: "P1001",
        projectName: "TeamTaskManagementProject1",
        managerId: "U1001",
        empId: ["U1002", "U1003", "U1004","U1003"],
        status: "Ongoing",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 2)
        },
        percentage:0,
        description: "To create task and team management software",
        tasks: [{
            tasksId: "T1001",
            tasksName: "create task",
            empId: ["U1002"],
            status: "Ongoing",
            timeline: {
                startDate: new Date(year, month, day),
                endDate: new Date(year, month, day + 2)
            },
            comment: "Do it properly"
        },
        {
            tasksId: "T1002",
            tasksName: "view task",
            empId: ["U1003","U1004"],
            status: "Ongoing",
            timeline: {
                startDate: new Date(year, month, day),
                endDate: new Date(year, month, day + 3)
            },
            comment: "Do it properly"
        },
        {
            tasksId: "T1003",
            tasksName: "delete task",
            empId: ["U1003"],
            status: "Ongoing",
            timeline: {
                startDate: new Date(year, month, day),
                endDate: new Date(year, month, day + 1)
            },
            comment: "Do it properly"
        }
        ]
    },
    {
        projectId: "P1002",
        projectName: "TeamTaskManagementProject2",
        managerId: "U1001",
        empId: ["U1005", "U1006", "U1007"],
        status: "Ongoing",
        percentage:50,
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 5)
        },
        description: "To create task and team management software",
        tasks: [{
            tasksId: "T1001",
            tasksName: "create task",
            empId: ["U1005"],
            status: "Ongoing",
            timeline: {
                startDate: new Date(year, month, day),
                endDate: new Date(year, month, day + 2)
            },
            comment: "Do it properly"
        },
        {
            tasksId: "T1002",
            tasksName: "view task",
            empId: ["U1006"],
            status: "Ongoing",
            timeline: {
                startDate: new Date(year, month, day),
                endDate: new Date(year, month, day + 3)
            },
            comment: "Do it by tuesday"
        },
        {
            tasksId: "T1003",
            tasksName: "delete task",
            empId: ["U1007"],
            status: "Completed",
            timeline: {
                startDate: new Date(year, month, day),
                endDate: new Date(year, month, day + 1)
            },
            comment: "Do it properly"
        }
        ]
    },
    {
        projectId: "P1003",
        projectName: "TeamTaskManagementProject3",
        managerId: "U1001",
        empId: ["U1005", "U1006"],
        status: "Ongoing",
        percentage:0,
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 10)
        },
        description: "To create task and team management software",
        tasks: [{
            tasksId: "T1001",
            tasksName: "create task",
            empId: ["U1005"],
            status: "Ongoing",
            timeline: {
                startDate: new Date(year, month, day),
                endDate: new Date(year, month, day + 2)
            },
            comment: "Do it properly"
        },
        {
            tasksId: "T1002",
            tasksName: "view task",
            empId: ["U1006"],
            status: "Ongoing",
            timeline: {
                startDate: new Date(year, month, day),
                endDate: new Date(year, month, day + 3)
            },
            comment: "Do it properly"
        }
        ]
    },
    {
        projectId: "P1004",
        projectName: "TeamTaskManagementProject4",
        managerId: "U1001",
        empId: ["U1002"],
        status: "Completed",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 15)
        },
        description: "To create task and team management software",
        tasks: [{
            tasksId: "T1001",
            tasksName: "create task",
            empId: ["U1002"],
            status: "Completed",
            timeline: {
                startDate: new Date(year, month, day),
                endDate: new Date(year, month, day + 2)
            },
            comment: "Do it properly"
        },
        ]
    }
]

const requestDb = [
    {
        requestId: "R1001",
        projectId: "P1001",
        projectName: "TeamTaskManagementProject1",
        userId: "U1002",
        userName: "Vasu",
        requestType: "Leave",
        requestReason: "I am going on a trip with my family",
        taskName: "",
        tasksId: "",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 2)
        },
        NoOfDays: 2,
        requestStatus: "Pending"
    },
    {
        requestId: "R1002",
        projectId: "P1001",
        projectName: "TeamTaskManagementProject1",
        userId: "U1003",
        userName: "Rahul",
        requestType: "TimeExtension",
        requestReason: "I was not well, thats why i m not able to complete my work on time",
        taskName: "view task",
        tasksId: "T1002",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 3)
        },
        NoOfDays: 2,
        requestStatus: "Pending"
    },
    {
        requestId: "R1003",
        projectId: "P1002",
        projectName: "TeamTaskManagementProject2",
        userId: "U1007",
        userName: "Rajat",
        requestType: "NewTask",
        requestReason: "I have intrest in delete tasks.",
        taskName: "DeleteTask",
        tasksId: "T1003",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 1)
        },
        NoOfDays: 2,
        requestStatus: "Pending"
    },
    {
        requestId: "R1004",
        projectId: "P1004",
        projectName: "TeamTaskManagementProject4",
        userId: "U1007",
        userName: "Rajat",
        requestType: "NewTask",
        requestReason: "I am keen to work in the above task and project",
        taskName: "backend testing Task",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 2)
        },
        NoOfDays: 2,
        requestStatus: "Accepted"
    },
    {
        requestId: "R1005",
        projectId: "P1003",
        projectName: "TeamTaskManagementProject3",
        userId: "U1005",
        userName: "Khushali",
        requestType: "Leave",
        requestReason: "I am going on a trip with my family",
        taskName: "create task",
        tasksId: "T1001",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 2)
        },
        NoOfDays: 2,
        requestStatus: "Pending"
    },
    {
        requestId: "R1006",
        projectId: "P1002",
        projectName: "TeamTaskManagementProject2",
        userId: "U1006",
        userName: "Pulkit",
        requestType: "TimeExtension",
        requestReason: "I am slow at work.",
        taskName: "view task",
        tasksId: "T1002",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 3)
        },
        NoOfDays: 2,
        requestStatus: "Pending"
    },
    {
        requestId: "R1007",
        projectId: "P1002",
        projectName: "TeamTaskManagementProject2",
        userId: "U1006",
        userName: "Pulkit",
        requestType: "UpdateStatus",
        taskStatus: "i have completed one user story out of two",
        taskName: "view task",
        tasksId: "T1002",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 3)
        },
        requestStatus: "Pending"
    },
    {
        requestId: "R1008",
        projectId: "P1001",
        projectName: "TeamTaskManagementProject1",
        userId: "U1002",
        userName: "Vasu",
        requestType: "UpdateStatus",
        taskStatus: "i have completed one user story out of two",
        taskName: "create task",
        tasksId: "T1001",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 2)
        },
        requestStatus: "Pending"
    }
    ,
    {
        requestId: "R1009",
        projectId: "P1001",
        projectName: "TeamTaskManagementProject1",
        userId: "U1002",
        userName: "Vasu",
        requestType: "UpdateStatus",
        taskStatus: "i have completed one user story out of two",
        taskName: "create task",
        tasksId: "T1002",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 2)
        },
        requestStatus: "Pending"
    },
    {
        requestId: "R1010",
        projectId: "P1004",
        projectName: "TeamTaskManagementProject4",
        userId: "U1002",
        userName: "Vasu",
        requestType: "UpdateStatus",
        taskStatus: "i have completed one user story out of two",
        taskName: "create task",
        tasksId: "T1001",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 2)
        },
        requestStatus: "Pending"
    },
    {
        requestId: "R1011",
        projectId: "P1001",
        projectName: "TeamTaskManagementProject1",
        userId: "U1003",
        userName: "Rahul",
        requestType: "UpdateStatus",
        taskStatus: "doneeeeee",
        taskName: "view task",
        tasksId: "T1002",
        timeline: {
            startDate: new Date(year, month, day),
            endDate: new Date(year, month, day + 2)
        },
        requestStatus: "Pending"
    }
]
const eventDb = [
    {
        eventId: "E1001",
        eventName: "meeting",
        createdBy: "U1001",
        projectName: "TeamTaskManagementProject1",
        eventDate: new Date(year, month, day),
        time: "03:20",
        venue: "L2-005",
        reason: "for visit",
        members: ["U1002", "U1003"],
        status: "Upcoming"
    },
    {
        eventId: "E1002",
        eventName: "party",
        createdBy: "U1001",
        projectName: "TeamTaskManagementProject2",
        eventDate: new Date(year, month, day + 3),
        time: "18:20",
        venue: "L2-006",
        reason: "for enjoy",
        members: ["U1005", "U1006"],
        status: "Upcoming"
    },
    {
        eventId: "E1003",
        eventName: "scrum meeting",
        createdBy: "U1001",
        projectName: "TeamTaskManagementProject1",
        eventDate: new Date(year, month, day + 2),
        time: "10:20",
        venue: "L2-005",
        reason: "for discussion",
        members: ["U1002", "U1003", "U1004"],
        status: "Upcoming"
    },
    {
        eventId: "E1004",
        eventName: "submission",
        createdBy: "U1001",
        projectName: "TeamTaskManagementProject2",
        eventDate: new Date(year, month, day + 1),
        time: "15:20",
        venue: "L2-008",
        reason: "for submission",
        members: ["U1005", "U1006"],
        status: "Upcoming"
    }
]
const notificationDb = [
    {
        notificationId:"N1001",
        "date": "5/9/2019",
        "eventName": "",
        "notificationType": "Task Status Request",
        "projectId": "P1001",
        "projectName": "TeamTaskManagementProject1",
        "taskId": "T1002",
        "tasksName": "view task",
        "time": "3:39:14 PM",
        userId: ["U1003","U1002"],
        "venue": ""
        },
        {
            notificationId:"N1002",
            "date": "5/10/2019",
            "eventName": "",
            "notificationType": "Task Status Request",
            "projectId": "P1001",
            "projectName": "TeamTaskManagementProject1",
            "taskId": "T1002",
            "tasksName": "view task",
            "time": "6:39:14 PM",
            userId: ["U1003","U1002"],
            "venue": ""
            }
]


exports.setupDb = () => {
    return collection.getUserCollection().then((users) => {
        return users.deleteMany().then(() => {
            return users.insertMany(userDb).then(() => {
                return collection.getProjectCollection().then((projects) => {
                    return projects.deleteMany().then(() => {
                        return projects.insertMany(projectDb).then(() => {
                            return collection.getRequestCollection().then((requests) => {
                                return requests.deleteMany().then(() => {
                                    return requests.insertMany(requestDb).then(() => {
                                        return collection.getEventCollection().then(events => {
                                            return events.deleteMany().then(() => {
                                                return events.insertMany(eventDb).then(() => {
                                                    return collection.getNotificationCollection().then((notifications) => {
                                                        return notifications.deleteMany().then(() => {
                                                            return notifications.insertMany(notificationDb).then((data) => {
                                                                if (data) return "Insertion Successfull"
                                                                else {
                                                                    let err = new Error("Insertion failed");
                                                                    err.status = 400;
                                                                    throw err;
                                                                }
                                                            })
                                                        })
                                                    })

                                                })
                                            })
                                        })


                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    })
}


