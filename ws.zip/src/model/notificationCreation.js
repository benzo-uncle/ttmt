class NotificationCreation {
    constructor(obj) {
        this.notificationId=obj.notificationId;
        this.notificationType=obj.notificationType;
        this.eventName=obj.eventName;
        this.projectId=obj.projectId;
        this.projectName=obj.projectName;
        this.time=obj.time;
        this.managerId=obj.managerId;
        this.venue=obj.venue;
        this.date=obj.date;
        this.taskName=obj.taskName;
        this.taskId=obj.taskId;
        this.userId=obj.userId;
    }
}

module.exports = NotificationCreation;