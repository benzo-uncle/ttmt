const dbModel = require('../utilities/connection');

let teamTaskDb = {};

teamTaskDb.generateProjectId = () => {
    return dbModel.getProjectCollection().then((model) => {

        return model.distinct("projectId").then((ids) => {
            let num = [];
            var i = 0;
            for (i = 0; i < ids.length; i++) {
                num.push(Number(ids[i].slice(1, ids[i].length)))
            }

            let bId = Math.max(...num);

            bId = bId + 1;
            pId = "P" + bId;

            return pId;
        })
    })
}

teamTaskDb.generateTaskId = (projectId) => {
    return dbModel.getProjectCollection().then((model) => {

        return model.distinct("tasks.tasksId", { projectId: projectId }).then((ids) => {
            if (ids.length === 0) {
                return "T1001"
            }
            else {
                let num = [];
                var i = 0;
                for (i = 0; i < ids.length; i++) {
                    num.push(Number(ids[i].slice(1, ids[i].length)))
                }


                let bId = Math.max(...num);

                bId = bId + 1;
                pId = "T" + bId;

                return pId;
            }
        })
    })
}
teamTaskDb.generateRequestId = () => {
    return dbModel.getRequestCollection().then((model) => {

        return model.distinct("requestId").then((ids) => {
            let num = [];
            var i = 0;
            for (i = 0; i < ids.length; i++) {
                num.push(Number(ids[i].slice(1, ids[i].length)))
            }


            let bId = Math.max(...num);

            bId = bId + 1;
            pId = "R" + bId;

            return pId;
        })
    })
}
teamTaskDb.generateEventId = () => {
    return dbModel.getEventCollection().then((model) => {

        return model.distinct("eventId").then((ids) => {
            let num = [];
            var i = 0;
            for (i = 0; i < ids.length; i++) {
                num.push(Number(ids[i].slice(1, ids[i].length)))
            }


            let bId = Math.max(...num);

            bId = bId + 1;
            pId = "E" + bId;

            return pId;
        })
    })
}
teamTaskDb.generateNotificationId = () => {
    return dbModel.getNotificationCollection().then((model) => {

        return model.distinct("notificationId").then((ids) => {

            let num = [];
            var i = 0;
            for (i = 0; i < ids.length; i++) {
                num.push(Number(ids[i].slice(1, ids[i].length)))
            }

            let bId = Math.max(...num);

            bId = bId + 1;
            pId = "N" + bId;



            return pId;
        })
    })
}
teamTaskDb.getManagerId=()=>{
    return dbModel.getUserCollection().then((model)=>{
        return model.findOne({empType:"Manager"},{userId:1,_id:0}).then((data)=>{
            if (data !== null) {
                return data;
            }
            else {
                return null;
            }
        })
    })
}
teamTaskDb.getProjectByProjectId = (projectId) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.findOne({ projectId: projectId }).then((data) => {
            if (data !== null) {
                return data;
            }
            else {
                return null;
            }
        })
    })
}
teamTaskDb.getTaskByTaskId = (projectId, tasksId) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.findOne({ projectId: projectId, 'tasks.tasksId': tasksId }, { 'tasks.$': 1, _id: 0 }).then((data) => {
            if (data !== null) {
                return data;
            }
            else {
                return null;
            }
        })
    })
}
teamTaskDb.userDetails = (userEmailId) => {
    return dbModel.getUserCollection().then((db) => {
        return db.findOne({ emailId: userEmailId }).then((userData) => {
            if (userData !== null) {
                return userData
            } else {
                return null;
            }
        })
    })
}


teamTaskDb.viewAllEmployees = () => {
    return dbModel.getUserCollection().then((model) => {
        return model.find({ empType: "TeamMember" }, { userId: 1, userName: 1, projectsId: 1, _id: 0 }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                return data;
            }
        })
    })
}

// teamTaskDb.viewAllTeamMembersAndAvaialbilityByType = () => {
//     return dbModel.getUserCollection().then((model) => {
//         return model.find({ empType: "TeamMember" }, { _id: 0, userName: 1, availability: 1 }).then((data) => {
//             if (data.length === 0) {
//                 return null;
//             }
//             else {
//                 return data;
//             }
//         })
//     })
// }

teamTaskDb.getProjectEmpNames = (projectName) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.find({ projectName: projectName }, { empId: 1, _id: 0 }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {

                var arr = data[0].empId;
                return dbModel.getUserCollection().then((model1) => {
                    return model1.find({ userId: { $in: data[0].empId } }, { userName: 1, userId: 1, _id: 0 }).then((data1) => {

                        return data1;
                    })
                })


            }
        })
    })
}
teamTaskDb.getEmpDetails = (empId) => {
    return dbModel.getUserCollection().then((model) => {
        return model.find({ userId: empId }, { userName: 1, _id: 0 }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                return data;
            }
        })
    })
}
teamTaskDb.downloadReportByUser = (userId) => {
    return dbModel.getUserCollection().then((model1) => {
        return model1.findOne({ userId:userId }, { userName: 1,rating:1,userId:1,projectsId:1,availability:1, _id: 0 }).then((data1) => {
            if (!data1) {
                return null;
            }
            else {
                var empId=data1.userId;
                return model1.find({},{userId:1,userName:1,_id:0}).then((userData)=>{
                    console.log("names",userData);
                    return dbModel.getProjectCollection().then((model) => {
                        return model.find({empId:empId }, { _id: 0, tasks: 1, projectName: 1, projectId: 1,status:1,timeline:1,description:1,percentage:1,managerId:1 }).then((data) => {
                            if (data.length === 0) {
                                return null;
                            }
                            else {
                               
                                
                                
                                var i=0;
                                var k=0;
                                var j=0;
                                var l=0;
                                var m=0;
                                var returnArr=[];
                                for(k=0;k<data.length;k++){
                                    
                                    var arr = data[k].tasks;
                                    var tasks = [];
                                    for(i=0;i<arr.length;i++){
                                        var empNames=[];
                                        for(m=0;m<arr[i].empId.length;m++){
                                        for(l=0;l<userData.length;l++){
                                            if(arr[i].empId[m]===userData[l].userId){
                                                empNames.push(userData[l].userName);
                                            }
                                        }
                                    }
                                        for(j=0;j<arr[i].empId.length;j++){
                                            

                                            if(arr[i].empId[j]===empId){
                                                var task = {
                                                    tasksName: "",
                                                    empNames:[],
                                                    status: "",
                                                    tasksRating:"",
                                                    timeline: {},
                                                    comment: "",
                                                    projectName:"",
                                                    projectStataus:"",
                                                    projectTimeline:{},
                                                    description:"",
                                                    percentage:""
                                                }
                                                
                                                task.tasksName=arr[i].tasksName;
                                                task.empNames=empNames;
                                                task.status=arr[i].status;
                                                task.timeline=arr[i].timeline;
                                                task.tasksRating=arr[i].tasksRating;
                                                task.comment=arr[i].comment;
                                                task.projectName=data[k].projectName;
                                                task.projectStataus=data[k].status;
                                                task.projectTimeline=data[k].timeline;
                                                task.description=data[k].description;
                                                task.percentage=data[k].percentage;
                                                returnArr.push(task);
                                            }
                                        }
                                       
                                       
                                    }
                                    
                                   
                                }
                               console.log(returnArr);
                                return returnArr;
                            }
                        })
                    })
                })
                
            //     // var i=0;
            //     // for(i=0;i<data.length;i++){
            //     //     empId.push(data[i].userId);
            //     //    }
            //     // var returnArr=[];

            //     // var projObj={
            //     //     projectName:"",
            //     //     status:""
            //     // }
            //     // var projectArr=[];
            //     var arr = [];
            //     console.log(empId);
               
            //     return dbModel.getProjectCollection().then((model1)=>{
                    
               
            //     return model1.find({tasks:{$all:[{"$elemMatch":{empId:empId}}]}},{_id:0,projectId:1,projectName:1,status:1,percentage:1,description:1,managerId:1,timeline:1,'tasks.$':1}).then((data1)=>{

            //              console.log(data,data1);

            //             //  var j=0;
            //              var z=0;
            //              var k=0;
                      
            //                 var obj={
            //                     userName:"",
            //                     rating:"",
            //                     userId:"",
            //                     availability:"",
            //                     projects:[]
                            
            //                 }
            //                 obj.userName=data.userName;
            //                 obj.rating=data.rating;
            //                 obj.userId=data.userId;
            //                 obj.availability=data.availability;
            //                 for(z=0;z<data.projectsId.length;z++){
            //                     for(k=0;k<data1.length;k++){
            //                         if(data.projectsId[z]===data1[k].projectId){
            //                             obj.projects.push(data1[k]);
            //                         }
            //                     }
            //                 }
            //             //     arr.push(obj);
                      
            //             //  console.log(arr);
            //            return obj;
            //      })
                 
        
            // }) 
            
            }
        })
    })
}

teamTaskDb.searchEmp = (emp) => {
    //var emp='/'+emp+'/'

    return dbModel.getUserCollection().then((model) => {
        return model.find({ userName: { $regex: emp, $options: 'i' } }, { userName: 1, rating: 1, userId: 1,availability:1, projectsId: 1, _id: 0 }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                var empId = [];
                var i = 0;
                for (i = 0; i < data.length; i++) {
                    empId.push(data[i].userId);
                }
                // var returnArr=[];

                // var projObj={
                //     projectName:"",
                //     status:""
                // }
                // var projectArr=[];
                var arr = [];
                console.log(empId);

                return dbModel.getProjectCollection().then((model1) => {


                    return model1.find({ empId: { $in: empId } }, { _id: 0, projectName: 1, projectId: 1, status: 1 }).then((data1) => {




                        console.log(data);

                        var j = 0;
                        var z = 0;
                        var k = 0;
                        for (j = 0; j < data.length; j++) {
                            var obj = {
                                userName: "",
                                rating: "",
                                availability:"",
                                userId: "",
                                projects: []

                            }
                            obj.userName = data[j].userName;
                            obj.rating = data[j].rating;
                            obj.availability=data[j].availability;
                            obj.userId = data[j].userId;
                            for (z = 0; z < data[j].projectsId.length; z++) {
                                for (k = 0; k < data1.length; k++) {
                                    if (data[j].projectsId[z] === data1[k].projectId) {
                                        obj.projects.push(data1[k]);
                                    }
                                }
                            }
                            arr.push(obj);
                        }
                        console.log(arr);
                        return arr;
                    })





                    //  projectArr=[];


                    // returnArr=arr;
                    // return returnArr;
                })

            }
        })
    })
}
teamTaskDb.viewLeaveRequests = () => {
    return dbModel.getRequestCollection().then((model) => {
        return model.find({ requestType: "Leave", requestStatus: "Pending" }, { requestId: 1, userName: 1, timeline: 1, NoOfDays: 1, requestReason: 1, userId: 1, _id: 0 }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                return data;
            }
        })
    })
}
teamTaskDb.viewTimeExtensionRequests = () => {
    return dbModel.getRequestCollection().then((model) => {
        return model.find({ requestType: "TimeExtension", requestStatus: "Pending" }, { requestId: 1, projectName: 1, projectId: 1, userName: 1, NoOfDays: 1, taskName: 1, tasksId: 1, requestReason: 1, _id: 0 }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                return data;
            }
        })
    })
}

teamTaskDb.viewNewTaskRequests = () => {
    return dbModel.getRequestCollection().then((model) => {
        return model.find({ requestType: "NewTask", requestStatus: "Pending" }, { requestId: 1, projectName: 1, projectId: 1, userId: 1, userName: 1, taskName: 1, requestReason: 1, _id: 0 }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                return data;
            }
        })
    })
}
teamTaskDb.viewStatusUpdateRequest = () => {
    return dbModel.getRequestCollection().then((model) => {
        return model.find({ requestType: "UpdateStatus", requestStatus: "Pending" }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                return data;
            }
        })
    })
}
teamTaskDb.acceptLeaveRequests = (userId, requestId, requestStatus) => {
    return dbModel.getUserCollection().then((model) => {
        return model.updateOne({ userId: userId }, { $set: { availability: "On-Leave" } }).then((data) => {
            if (data.nModified === 1) {
                return teamTaskDb.updateRequestStatus(requestId, requestStatus).then((reqStatus) => {
                    return reqStatus;
                })
            }
            else {
                let err = new Error("unable to Accept your leave request");
                err.status = 400;
                throw err;
            }
        })
    })
}
teamTaskDb.acceptTimeExtensionRequests = (projectId, tasksId, requestId, requestStatus, extension) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.findOne({ projectId: projectId, 'tasks.tasksId': tasksId }, { tasks: 1, _id: 0 }).then((eDate) => {
            console.log(eDate);
            var endDate = new Date(eDate.tasks[0].timeline.endDate);
            endDate.setDate(endDate.getDate() + extension);
            console.log("new", endDate);
            return model.update({ projectId: projectId, 'tasks.tasksId': tasksId }, { $set: { 'tasks.$.timeline.endDate': endDate } }).then((data) => {
                if (data.nModified === 1) {
                    return teamTaskDb.updateRequestStatus(requestId, requestStatus).then((reqStatus) => {
                        console.log("hiii");
                        return reqStatus;
                    })
                }
                else {
                    let err = new Error("unable to Accept your time extension request");
                    err.status = 400;
                    throw err;
                }
            })


        })
    })
}
teamTaskDb.acceptNewTaskRequests = (projectId, taskCreation, requestId, requestStatus) => {
    return teamTaskDb.addTeamMemberWithNewTask(projectId, taskCreation).then((tId) => {
        return teamTaskDb.updateRequestStatus(requestId, requestStatus).then((reqStatus) => {
            return reqStatus;
        })
    })
}

// teamTaskDb.updateUserRating = (requestId, value) => {
//     console.log(value);

//     return dbModel.getRequestCollection().then((model) => {
//         return model.findOne({ requestId: requestId }, { _id: 0, userId: 1 }).then((user) => {
//             console.log("user", user.userId);
//             if (user !== null) {
//                 return dbModel.getUserCollection().then((model1) => {
//                     return model1.findOne({ userId: user.userId }, { _id: 0, projectsId: 1,rating:1 }).then((projects) => {
//                         console.log(projects.projectsId);
//                         return dbModel.getProjectCollection().then((projectsModel) => {
//                             console.log("before foreach", projects.projectsId);

//                                 var completedCount=0

//                                 return projectsModel.find({ empId:user.userId,'tasks.empId':user.userId }, { _id: 0, "tasks.$": 1 }).then((taskArr) => {
//                                     console.log("i m h", taskArr);
//                                      taskArr.tasks.forEach((tasks) => {
//                                         // console.log("task in for each",tasks);
//                                         console.log("tasks.empId", tasks.empId, user.userId,tasks.status, tasks.empId.indexOf(user.userId));

//                                         if (tasks.empId.indexOf(user.userId) !== -1) {
//                                             if (tasks.status === "Completed") {
//                                                 completedCount = completedCount + 1

//                                             }
//                                         }
//                                     })
//                                 })

//                             //    var prvRating=(projects.rating)*(completedCount-1)
//                             // var newRating=(prvRating+value)/completedCount;
//                             // console.log(newRating,"new") 
//                         })
//                     })
//                 })
//             }
//             else {
//                 return false;
//             }
//         })
//     })
// }

teamTaskDb.updateUserRating = (requestId,tasksId,projectId,value)=>{

    return dbModel.getProjectCollection().then((model1)=>{
        return model1.findOne({projectId:projectId,'tasks.tasksId':tasksId},{_id:0,'tasks.$':1}).then((task)=>{
           console.log(task);
            
            
            return dbModel.getUserCollection().then((model2)=>{
                return model2.find({userId:task.tasks[0].empId},{_id:0,rating:1,completedTaskCount:1,userId:1}).then((data)=>{
                var empId=task.tasks[0].empId;
                console.log("data",data);
                var i=0;
                var j=0;
            for(i=0;i<empId.length;i++){
                for(j=0;j<data.length;j++){
                    if(empId[i]===data[j].userId){
                        console.log("empid",empId[i]);
                        if(data[j].completedTaskCount!==0){
                            var prvRating=data[j].rating * (data[j].completedTaskCount)
                            console.log("prv",prvRating);
                            console.log(value,"value1");
                            
                            var newRating= (Number(value)+prvRating)/(data[j].completedTaskCount+1);
                        }
                        else{
                            console.log(value,"value2");
                            var newRating= value;
                        }
                        model2.updateOne({userId:empId[i]},{$set:{rating:newRating},$inc:{completedTaskCount:1}}).then((response)=>{
                            console.log("response",response.nModified);
                            if(response.nModified!==1){
                                return false
                            }
                            
                        })
                    }
                }

            }
            return true
        })
        })
        })
    })

    // return dbModel.getRequestCollection().then((model)=>{
    //     return model.findOne({requestId:requestId},{_id:0,userId:1}).then((user)=>{
    //         return dbModel.getUserCollection().then((model1)=>{
    //             return model1.findOne({userId:user.userId},{_id:0,rating:1,completedTaskCount:1}).then((data)=>{
    //                 console.log(data);
                    
    //                 if(data.completedTaskCount!==0){
    //                 var prvRating=data.rating * (data.completedTaskCount)
    //                 console.log("prv",prvRating);
    //                 console.log(value,"value");
                    
    //                 var newRating= (Number(value)+prvRating)/(data.completedTaskCount+1);
    //             }
    //             else{
    //                 var newRating= value;
    //             }
    //             return model1.updateOne({userId:user.userId},{$set:{"rating":newRating},$inc:{"completedTaskCount":1}}).then((response)=>{
    //                 console.log(response.nModified);
    //                 if(response.nModified===1){
    //                     return true
    //                 }
    //                 else{
    //                     return false
    //                 }
    //             })
    //             })
    //         })
    //     })
    // })
}


teamTaskDb.updateProjectStatus = (projectId) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.find({ projectId: projectId }, { _id: 0, tasks: 1 }).then((tasksArray) => {
            var tasksArrayLength = tasksArray[0].tasks.length;
            var completedCount = 0;
            tasksArray[0].tasks.forEach((task) => {
                if (task.status === "Completed") {
                    completedCount = completedCount + 1
                }
            })
            percentage = ((completedCount / tasksArrayLength) * 100).toFixed(3)
            status = "Ongoing";
            console.log(percentage);

            if (percentage === "100.000") {
                console.log("in 100");

                status = "Completed";
            }
            return model.updateOne({ projectId: projectId }, { $set: { percentage: percentage, status: status } }).then((data) => {
                if (data.nModified === 1) {
                    return true;
                } else {
                    let err = new Error("Project Status Could Not Update");
                    err.status = 400;
                    throw err;
                }
            })
        }) 
    })
}
teamTaskDb.acceptStatusUpdateRequests = (projectId, tasksId, requestId, requestStatus, value) => {
    return dbModel.getProjectCollection().then((model) => {
        console.log("hi value", value);
        return model.updateOne({ projectId: projectId, 'tasks.tasksId': tasksId }, { $set: { 'tasks.$.status': "Completed", 'tasks.$.tasksRating': value } }).then((data) => {
            if (data.nModified === 1) {

                return teamTaskDb.updateRequestStatus(requestId, requestStatus).then((reqStatus) => {
                    return reqStatus;
                })
            }
            else {
                let err = new Error("unable to Accept your Status update request");
                err.status = 400;
                throw err;
            }
        })
    })
}
teamTaskDb.updateRequestStatus = (requestId, requestStatus) => {

    return dbModel.getRequestCollection().then((model) => {
        return model.updateOne({ requestId: requestId }, { $set: { requestStatus: requestStatus } }).then((result) => {
            if (result.nModified === 1) {
                return requestStatus;
            }
            else {
                let err = new Error("unable to update request status");
                err.status = 400;
                throw err;
            }
        })
    })
}
teamTaskDb.viewAcceptedRequests = () => {
    return dbModel.getRequestCollection().then((model) => {
        return model.find({ requestStatus: "Accepted" }, { _id: 0, requestType: 1, projectName: 1, userName: 1, taskName: 1, timeline: 1, NoOfDays: 1 }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                return data;
            }
        })
    })
}
teamTaskDb.createProject = (projectCreation) => {
    return dbModel.getProjectCollection().then((model) => {
        return teamTaskDb.generateProjectId().then((pId) => {
            projectCreation.projectId = pId;
            var arr = projectCreation.tasks;
            arr[0].tasksId = "T1001";
            var i = 0;
            for (i = 1; i < arr.length; i++) {
                var n = Number(arr[i - 1].tasksId.slice(1, arr[i - 1].tasksId.length))
                n = n + 1;
                arr[i].tasksId = "T" + n;
            }

            projectCreation.tasks = arr;
            return model.create(projectCreation).then((output) => {

                console.log(projectCreation.projectId + "1321651461");
                if (output) {
                    return dbModel.getUserCollection().then((model2) => {
                        console.log(projectCreation.empId + "gvughf")
                        return model2.updateMany({ userId: { $in: projectCreation.empId } }, { $push: { projectsId: projectCreation.projectId } }).then((result) => {
                            if (result.nModified <= 0) {
                                let err = new Error("unable to assign task and project to employees");
                                err.status = 400;
                                throw err;
                            }
                            else {
                                console.log("in ")
                                return projectCreation.projectId;
                            }
                        })
                    })




                }
                else {
                    let err = new Error("Project creation failed");
                    err.status = 400;
                    throw err;
                }

            })
        })
    })
}

teamTaskDb.updateProject = (projectCreation) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.updateOne({ projectId: projectCreation.projectId }, { $set: { projectName: projectCreation.projectName, description: projectCreation.description, 'timeline.startDate': projectCreation.timeline.startDate, 'timeline.endDate': projectCreation.timeline.endDate } }).then((output) => {
            if (output.nModified === 1) {
                return projectCreation.projectId;
            }
            else {
                let err = new Error("Project updation failed");
                err.status = 400;
                throw err;
            }
        })
    })
}


teamTaskDb.deleteProject = (projectId) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.findOne({ projectId: projectId }, { projectName: 1, _id: 0 }).then((name) => {

            var projectName = name.projectName;
            console.log(projectName)
            return model.deleteOne({ projectId: projectId }).then((output) => {
                if (output.deletedCount === 1) {
                    return dbModel.getRequestCollection().then((model2) => {
                        return model2.deleteMany({ projectId: projectId }).then((output2) => {

                            return dbModel.getEventCollection().then((model3) => {
                                return model3.deleteMany({ projectName: projectName }).then((output3) => {

                                    return dbModel.getNotificationCollection().then((model4) => {
                                        return model4.deleteMany({ projectId: projectId }).then((output4) => {



                                            return dbModel.getUserCollection().then((model1) => {
                                                return model1.updateMany({}, { $pull: { projectsId: projectId } }).then((data) => {
                                                    if (data.nModified > 0) {
                                                        return projectId;
                                                    }
                                                    else {
                                                        let err = new Error("Unable to remove project from users");
                                                        err.status = 400;
                                                        throw err;
                                                    }
                                                })
                                            })
                                        })
                                    })
                                })
                            })


                        })
                    })


                }
                else {
                    let err = new Error("Project Deletion failed");
                    err.status = 400;
                    throw err;
                }
            })
        })
    })
}
teamTaskDb.updateTask = (taskCreation, projectId) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.findOne({ projectId: projectId, 'tasks.tasksId': taskCreation.tasksId }, { _id: 0, 'tasks.$': 1 }).then((id1) => {

            var arr = id1.tasks[0].empId;
            return model.updateOne({ projectId: projectId, 'tasks.tasksId': taskCreation.tasksId }, { $set: { 'tasks.$.tasksName': taskCreation.tasksName, 'tasks.$.comment': taskCreation.comment, 'tasks.$.timeline.startDate': taskCreation.timeline.startDate, 'tasks.$.timeline.endDate': taskCreation.timeline.endDate, 'tasks.$.empId': taskCreation.empId }, $push: { empId: { $each: taskCreation.empId } } }).then((output) => {
                if (output.nModified === 1) {
                    return dbModel.getProjectCollection().then((model2) => {
                        return model2.findOne({ projectId: projectId }, { _id: 0, empId: 1 }).then((id) => {
                            var empIdArr = id.empId;

                            var i = 0;
                            var j = 0;
                            for (i = 0; i < arr.length; i++) {
                                for (j = 0; j < empIdArr.length; j++) {
                                    if (arr[i] === empIdArr[j]) {
                                        empIdArr.splice(j, 1);
                                        j--;
                                        break;
                                    }
                                }
                            }

                            return model2.updateOne({ projectId: projectId }, { $set: { empId: empIdArr } }).then((output2) => {
                                return dbModel.getUserCollection().then((model1) => {
                                    var z = 0;
                                    for (z = 0; z < arr.length; z++) {
                                        model1.findOne({ userId: arr[z] }, { _id: 0, projectsId: 1, userId: 1 }).then((data) => {
                                            var projectArr = data.projectsId;
                                            var userId = data.userId;
                                            var k = 0;
                                            for (k = 0; k < projectArr.length; k++) {
                                                if (projectArr[k] === projectId) {
                                                    projectArr.splice(k, 1);
                                                    k--;
                                                    break;
                                                }
                                            }
                                            model1.updateOne({ userId: userId }, { $set: { projectsId: projectArr } }).then((data) => {
                                                if (data.nModified !== 1) {
                                                    let err = new Error("Task updation failed in user project array");
                                                    err.status = 400;
                                                    throw err;
                                                }
                                            })

                                        })
                                    }
                                    return model1.updateMany({ userId: taskCreation.empId }, { $push: { projectsId: projectId } }).then((output1) => {
                                        if (output1.nModified > 0) {
                                            return taskCreation.tasksId;
                                        }
                                        else {
                                            let err = new Error("Task updation failed in user db");
                                            err.status = 400;
                                            throw err;
                                        }
                                    })
                                })
                            })

                        })
                    })


                }
                else {
                    let err = new Error("Task addition failed");
                    err.status = 400;
                    throw err;
                }
            })
        })


    })
}
teamTaskDb.deleteTask = (projectId, tasksId) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.findOne({ projectId: projectId, 'tasks.tasksId': tasksId }, { _id: 0, 'tasks.$': 1 }).then((data) => {
            console.log(data);
            var tasks = data.tasks[0];
            return model.updateOne({ projectId: projectId, 'tasks.tasksId': tasksId }, { $pull: { tasks: tasks } }).then((output) => {
                if (output.nModified === 1) {
                    return dbModel.getRequestCollection().then((model1) => {
                        return model1.deleteMany({ tasksId: tasksId }).then((output1) => {
                            return tasksId;

                        })
                    })

                }
                else {
                    let err = new Error("Task Deletion failed");
                    err.status = 400;
                    throw err;
                }
            })
        })

    })
}
teamTaskDb.addNewTask = (taskCreation, projectId) => {
    return dbModel.getProjectCollection().then((model) => {
        return teamTaskDb.generateTaskId(projectId).then((taskId) => {
            taskCreation.tasksId = taskId;
            taskCreation.status = "Ongoing";
            return model.updateOne({ projectId: projectId }, { $push: { tasks: taskCreation, empId: { $each: taskCreation.empId } } }).then((output) => {
                if (output.nModified === 1) {
                    return dbModel.getUserCollection().then((model1) => {
                        return model1.updateMany({ userId: taskCreation.empId }, { $push: { projectsId: projectId } }).then((output1) => {
                            if (output1.nModified > 0) {
                                return taskCreation.tasksId;
                            }
                            else {
                                let err = new Error("Task addition failed in user db");
                                err.status = 400;
                                throw err;
                            }
                        })
                    })

                }
                else {
                    let err = new Error("Task addition failed");
                    err.status = 400;
                    throw err;
                }
            })
        })
    })
}

///////////////////////////////////////////////////////////////////////////////
teamTaskDb.viewAllProjects = () => {
    return dbModel.getProjectCollection().then((model) => {
        return model.find().then((projects) => {
            if (projects.length === 0) {
                return null;
            }
            else {
                return projects
            }
        })
    })
}

teamTaskDb.viewOngoingProjects = (managerId) => {
    return dbModel.getProjectCollection().then((model => {
        return model.find({ managerId: managerId, status: "Ongoing" }, { projectName: 1, status: 1, percentage: 1, timeline: 1, projectId: 1, _id: 0 }).then((projects) => {
            if (projects.length === 0) {
                return null;
            }
            else {
                return projects
            }
        })
    }))
}

teamTaskDb.viewCompletedProjects = (managerId) => {
    return dbModel.getProjectCollection().then((model => {
        return model.find({ managerId: managerId, status: "Completed" }, { projectName: 1, description: 1, timeline: 1, projectId: 1, _id: 0 }).then((projects) => {
            if (projects.length === 0) {
                return null;
            }
            else {
                return projects
            }
        })
    }))
}


teamTaskDb.viewOngoingProjectDetails = (managerId, projectId) => {
    return dbModel.getProjectCollection().then((model => {
        return model.findOne({ managerId: managerId, projectId: projectId }, { empId: 1, projectId: 1, projectName: 1, description: 1, tasks: 1, _id: 0 }).then((data) => {
            if (!data) {
                return null;

            }
            else {
                var arr = data.tasks;
                return dbModel.getUserCollection().then((model1) => {
                    return model1.find({ userId: { $in: data.empId } }, { userName: 1, userId: 1, _id: 0 }).then((data1) => {

                        var i = 0;
                        var j = 0;
                        var z = 0;
                        for (i = 0; i < arr.length; i++) {
                            for (z = 0; z < arr[i].empId.length; z++) {
                                for (j = 0; j < data1.length; j++) {
                                    if (arr[i].empId[z] === data1[j].userId) {
                                        arr[i].empId[z] = data1[j].userName;
                                    }
                                }
                            }

                        }

                        return data;
                    })
                })


            }
        })
    }))
}

teamTaskDb.viewCompletedProjectDetails = (managerId, projectId) => {
    return dbModel.getProjectCollection().then((model => {
        return model.findOne({ projectId: projectId }, { empId: 1, tasks: 1, _id: 0 }).then((data) => {
            if (!data) {
                return null;

            }
            else {
                var arr = data.tasks;
                return dbModel.getUserCollection().then((model1) => {
                    return model1.find({ userId: { $in: data.empId } }, { userName: 1, userId: 1, _id: 0 }).then((data1) => {

                        var i = 0;
                        var j = 0;
                        var z = 0;
                        for (i = 0; i < arr.length; i++) {
                            for (z = 0; z < arr[i].empId.length; z++) {
                                for (j = 0; j < data1.length; j++) {
                                    if (arr[i].empId[z] === data1[j].userId) {
                                        arr[i].empId[z] = data1[j].userName;
                                    }
                                }
                            }

                        }

                        return data;
                    })
                })


            }
        })
    }))
}

teamTaskDb.createEvent = (eventCreation) => {
    return dbModel.getEventCollection().then((model) => {
        return teamTaskDb.generateEventId().then((eventId) => {
            eventCreation.eventId = eventId;
            return model.create(eventCreation).then((output) => {
                if (output) {

                    var form = {
                        projectId: "",
                        projectName: eventCreation.projectName,
                        tasksName: "",
                        taskId: "",
                        managerId: eventCreation.createdBy,
                        userId: eventCreation.members,
                        notificationType: "Event",
                        eventId: eventCreation.eventId,
                        eventName: eventCreation.eventName,
                        venue: eventCreation.venue,
                        time: eventCreation.time,
                        date: eventCreation.eventDate

                    }


                    return dbModel.getProjectCollection().then((model1) => {
                        return model1.findOne({ projectName: eventCreation.projectName }, { projectId: 1, _id: 0 }).then((id) => {
                            var projectId = id.projectId;
                            form.projectId = projectId;
                            return teamTaskDb.createNotification(form).then((nId) => {
                                return eventCreation.eventId;
                            })
                        })
                    })

                }
                else {
                    let err = new Error("event creation failed");
                    err.status = 400;
                    throw err;
                }

            })
        })
    })
}
teamTaskDb.updateEvent = (eventCreation) => {
    return dbModel.getEventCollection().then((model) => {
        return model.updateOne({ eventId: eventCreation.eventId }, { $set: { projectName: eventCreation.projectName, time: eventCreation.time, venue: eventCreation.venue, reason: eventCreation.reason, members: eventCreation.members } }).then((data) => {
            if (data.nModified === 1) {
                return eventCreation.eventId;
            }
            else {
                let err = new Error("event updation failed");
                err.status = 400;
                throw err;
            }
        })
    })
}
teamTaskDb.deleteEvent = (eventId) => {
    return dbModel.getEventCollection().then((model) => {
        return model.deleteOne({ eventId: eventId }).then((output) => {
            if (output.deletedCount === 1) {
                return eventId
            }
            else {
                let err = new Error("event deletion failed");
                err.status = 400;
                throw err;
            }
        })
    })
}
teamTaskDb.viewEventByDate = (userId, eventDate) => {
    return dbModel.getEventCollection().then((model) => {
        return model.find({ eventDate: eventDate, $or: [{ createdBy: userId }, { members: userId }] }).then((events) => {
            if (events.length === 0) {
                return null;
            }
            else {

                return dbModel.getUserCollection().then((model1) => {
                    return model1.find({}, { userName: 1, userId: 1, _id: 0 }).then((data1) => {
                        var z = 0;
                        for (z = 0; z < events.length; z++) {
                            var arr = events[z].members;
                            var i = 0;
                            var j = 0;
                            for (i = 0; i < arr.length; i++) {
                                for (j = 0; j < data1.length; j++) {
                                    if (arr[i] === data1[j].userId) {
                                        arr[i] = data1[j].userName;
                                    }
                                }
                            }
                            events[z].members = arr;
                        }

                        return events;
                    })
                })



            }
        })
    })
}
teamTaskDb.viewEventByEventId = (eventId) => {
    return dbModel.getEventCollection().then((model) => {
        return model.findOne({ eventId: eventId }).then((event) => {
            if (!event) {
                return null;
            }
            else {
                return event;
            }
        })
    })
}
teamTaskDb.updateStatus = (requestCreation) => {
    return dbModel.getRequestCollection().then((model) => {
        return teamTaskDb.generateRequestId().then((requestId) => {
            requestCreation.requestId = requestId;
            requestCreation.requestType = "UpdateStatus";
            requestCreation.requestStatus = "Pending";
            return dbModel.getUserCollection().then((model1) => {
                return model1.findOne({ userId: requestCreation.userId }, { userName: 1, _id: 0 }).then((data) => {
                    if (!data) {
                        let err = new Error("username not found");
                        err.status = 400;
                        throw err;
                    }
                    else {
                        requestCreation.userName = data.userName;
                        return model.create(requestCreation).then((output) => {
                            if (output) {
                                return requestCreation.requestId;
                            }
                            else {
                                let err = new Error("request creation failed");
                                err.status = 400;
                                throw err;
                            }

                        })
                    }

                })
            })






        })
    })
}

teamTaskDb.createNotification = (notificationCreation) => {
    return dbModel.getNotificationCollection().then((model) => {
        return teamTaskDb.generateNotificationId().then((notificationId) => {
            notificationCreation.notificationId = notificationId;
            return dbModel.getUserCollection().then((model1) => {
                return model1.find({ userName: notificationCreation.userId }, { userId: 1, _id: 0 }).then((data) => {

                    if (notificationCreation.notificationType === "Task Status Request") {
                        var i = 0;
                        var arr = [];
                        for (i = 0; i < data.length; i++) {
                            arr[i] = data[i].userId;
                        }

                        notificationCreation.userId = arr;
                    }

                    return model.create(notificationCreation).then((output) => {
                        if (output) {
                            return notificationCreation.notificationId;
                        }
                        else {
                            let err = new Error("notification creation failed");
                            err.status = 400;
                            throw err;
                        }

                    })

                })
            })
        })

    })
}



// teamTaskDb.updateProjectTimeline=(projectId,managerId,startDate,endDate)=>{
//     return dbModel.getProjectCollection().then((model)=>{
//         return model.updateOne({projectId:projectId},{$set:{"timeline.startDate":startDate,"timeline.endDate":endDate}}).then((data)=>{
//             if(data.nModified===1){
//                 return projectId;
//             }
//             else{
//                 let err = new Error("Unable to update Project timeline");
//                 err.status = 400;
//                 throw err;
//             }
//         })
//     })
// }
// teamTaskDb.updateTaskTimeline=(projectId,managerId,taskId,startDate,endDate)=>{
//     return dbModel.getProjectCollection().then((model)=>{
//         return model.updateOne({projectId:projectId,"tasks.tasksId":taskId},{$set:{"tasks.$.timeline.startDate":startDate,"tasks.$.timeline.endDate":endDate}}).then((data)=>{
//             if(data.nModified===1){
//                 return taskId;
//             }
//             else{
//                 let err = new Error("Unable to update task timeline");
//                 err.status = 400;
//                 throw err;
//             }
//         })
//     })
// }


teamTaskDb.assignTask = (projectId, taskCreation) => {
    return dbModel.getProjectCollection().then((model) => {
        return teamTaskDb.generateTaskId(projectId).then((tId) => {
            taskCreation.tasksId = tId;
            return model.updateOne({ projectId: projectId }, { $push: { tasks: taskCreation } }).then((data) => {
                if (data.nModified === 1) {

                    return dbModel.getUserCollection().then((model2) => {
                        return model2.updateOne({ userId: taskCreation.empId[0] }, { $push: { tasksId: taskCreation.tasksId, projectsId: projectId } }).then((result) => {
                            if (result.nModified === 1) {
                                return taskCreation.tasksId;
                            }
                            else {
                                let err = new Error("No such employee exists");
                                err.status = 400;
                                throw err;
                            }
                        })
                    })
                }
                else {
                    let err = new Error("Task Assignment failed");
                    err.status = 400;
                    throw err;
                }
            })
        })
    })
}

teamTaskDb.addTeamMemberWithNewTask = (projectId, taskCreation) => {
    return dbModel.getProjectCollection().then((model) => {

        return teamTaskDb.assignTask(projectId, taskCreation).then((tId) => {
            return model.updateOne({ projectId: projectId }, { $push: { empId: taskCreation.empId[0] } }).then((data) => {
                if (data.nModified === 1) {
                    return taskCreation.tasksId;
                }
                else {
                    let err = new Error("no such project exists");
                    err.status = 400;
                    throw err;
                }
            })

        })
    })
}


teamTaskDb.downloadReportByProject = (projectId) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.findOne({ projectId: projectId }).then((data) => {
            if (!data) {
                return null;
            }
            else {
                var project = {
                    projectId: data.projectId,
                    projectName: data.projectName,
                    managerId: data.managerId,
                    empId: data.empId,
                    empName: [],
                    status: data.status,
                    timeline: data.timeline,
                    percentage: data.percentage,
                    description: data.description,
                    tasks: []
                }
                var task = {
                    tasksId: "",
                    tasksName: "",
                    empId: [],
                    empName: [],
                    status: "",
                    timeline: {},
                    comment: ""
                }

                var arr = data.tasks;
                return dbModel.getUserCollection().then((model1) => {
                    return model1.find({ userId: { $in: data.empId } }, { _id: 0, userId: 1, userName: 1 }).then((data1) => {

                        var i1 = 0;
                        var j1 = 0;
                        for (i1 = 0; i1 < data.empId.length; i1++) {
                            for (j1 = 0; j1 < data1.length; j1++) {
                                if (data.empId[i1] === data1[j1].userId) {
                                    project.empName.push(data1[j1].userName);
                                }
                            }
                        }
                        var i = 0;
                        var j = 0;
                        var z = 0;
                        var tasks = [];
                        for (i = 0; i < arr.length; i++) {

                            task.tasksId = arr[i].tasksId;
                            task.empName = [];
                            task.tasksName = arr[i].tasksName;
                            task.status = arr[i].status;
                            task.timeline = arr[i].timeline;
                            task.empId = arr[i].empId;
                            task.comment = arr[i].comment;

                            for (z = 0; z < arr[i].empId.length; z++) {
                                for (j = 0; j < data1.length; j++) {
                                    if (arr[i].empId[z] === data1[j].userId) {
                                        task.empName.push(data1[j].userName);
                                    }
                                }
                            }
                            tasks.push(task);
                            task = {};
                            //tasks[i]=task;
                            console.log(tasks, i);

                        }
                        //console.log(tasks);
                        project.tasks = tasks;
                        return project;
                    })
                })

            }
        })
    })
}

// teamTaskDb.addTeamMemberToExistingTask=(projectId,taskId,empId)=>{
//     return dbModel.getProjectCollection().then((model)=>{
//         return model.updateOne({projectId:projectId,"tasks.tasksId":taskId},{$push:{empId:empId,"tasks.empId":empId}}).then((data)=>{
//             if(data.nModified===1){
//                 return dbModel.getUserCollection().then((model1)=>{
//                     return model1.updateOne({userId:empId},{$push:{projectsId:projectId,tasksId:taskId}}).then((data1)=>{
//                         if(data1.nModified===1){
//                             return taskId;
//                         }
//                         else{
//                             let err = new Error("no such employee exists");
//                             err.status = 400;
//                             throw err;
//                         }
//                     })
//                 })
//             }
//             else{
//                 let err = new Error("no such project or task exists");
//                 err.status = 400;
//                 throw err;
//             }
//         })
//     })
// }


//for member..................


// teamTaskDb.viewCompletedTasksForTeamMember=(empId)=>{
//     return dbModel.getProjectCollection().then((model)=>{
//         return model.find({"tasks.empId":empId, "tasks.status":"Completed"},{_id:0,"tasks.$":1,projectName:1}).then((data)=>{
//             if(data.length===0){
//                 return null;
//             }
//             else{
//                 return data;
//             }
//         })
//     })
// }

teamTaskDb.viewOngoingTasksForTeamMember = (empId) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.find({empId:empId, status:"Ongoing" }, { _id: 0, tasks: 1, projectName: 1, projectId: 1 }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
               
                
                
                var i=0;
                var k=0;
                var j=0;
                var returnArr=[];
                for(k=0;k<data.length;k++){
                    
                    var arr = data[k].tasks;
                    var tasks = [];
                    for(i=0;i<arr.length;i++){
                        for(j=0;j<arr[i].empId.length;j++){
                            if(arr[i].empId[j]===empId){
                                var task = {
                                    tasksId: "",
                                    tasksName: "",
                                    empId: [],
                                    status: "",
                                    timeline: {},
                                    comment: "",
                                    projectId:"",
                                    projectName:""
                                }
                                task.tasksId=arr[i].tasksId;
                                task.tasksName=arr[i].tasksName;
                                task.empId=arr[i].empId;
                                task.status=arr[i].status;
                                task.timeline=arr[i].timeline;
                                task.comment=arr[i].comment;
                                task.projectId=data[k].projectId;
                                task.projectName=data[k].projectName;
                                returnArr.push(task);
                            }
                        }
                       
                       
                    }
                    
                   
                }
               console.log(returnArr);
                return returnArr;
            }
        })
    })
}

teamTaskDb.viewOngoingProjectsForTeamMember = (empId) => {
    return dbModel.getProjectCollection().then((model => {
        return model.find({ empId: empId, status: "Ongoing" }, { projectName: 1, status: 1, percentage: 1, status: 1, timeline: 1, projectId: 1, _id: 0 }).then((projects) => {
            if (projects.length === 0) {
                return null;
            }
            else {
                return projects
            }
        })
    }))
}

teamTaskDb.viewOngoingProjectDetailsForTeamMember = (empId, projectId) => {
    return dbModel.getProjectCollection().then((model => {
        return model.findOne({ empId: empId, projectId: projectId }, { empId: 1, description: 1, tasks: 1, _id: 0 }).then((data) => {
            if (data.length === 0) {
                return null;

            }
            else {
                var arr = data.tasks;
                return dbModel.getUserCollection().then((model1) => {
                    return model1.find({ userId: { $in: data.empId } }, { userName: 1, userId: 1, _id: 0 }).then((data1) => {

                        var i = 0;
                        var j = 0;
                        var z = 0;
                        for (i = 0; i < arr.length; i++) {
                            for (z = 0; z < arr[i].empId.length; z++) {
                                for (j = 0; j < data1.length; j++) {
                                    if (arr[i].empId[z] === data1[j].userId) {
                                        arr[i].empId[z] = data1[j].userName;
                                    }
                                }
                            }

                        }

                        return data;
                    })
                })


            }
        })
    }))
}

teamTaskDb.viewCompletedProjectsForTeamMember = (empId) => {
    return dbModel.getProjectCollection().then((model => {
        return model.find({ empId: empId, status: "Completed" }, { projectName: 1, description: 1, timeline: 1, projectId: 1, _id: 0 }).then((projects) => {
            if (projects.length === 0) {
                return null;
            }
            else {
                return projects
            }
        })
    }))
}

teamTaskDb.viewNotification = (empId) => {
    return dbModel.getNotificationCollection().then((model) => {
        return model.find({ userId: empId }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                return data;
            }
        })
    })
}

teamTaskDb.deleteOneNotification = (empId, notificationId) => {
    return dbModel.getNotificationCollection().then((model) => {
        return model.findOne({ notificationId: notificationId }, { _id: 0, userId: 1 }).then((data) => {
            if (data) {
                if (data.userId.length === 1) {
                    return model.deleteOne({ notificationId: notificationId }).then((output) => {
                        if (output.deletedCount === 1) {
                            return notificationId
                        }
                        else {
                            let err = new Error("notificaton deletion failed");
                            err.status = 400;
                            throw err;
                        }
                    })
                }
                else {
                    return model.updateOne({ notificationId: notificationId }, { $pull: { userId: empId } }).then((output) => {
                        if (output.nModified === 1) {
                            return notificationId
                        }
                        else {
                            let err = new Error("notificaton deletion for user failed");
                            err.status = 400;
                            throw err;
                        }
                    })
                }
            }
            else {
                return null;
            }
        })
    })
}
teamTaskDb.deleteAllNotifications = (empId) => {
    return dbModel.getNotificationCollection().then((model) => {
        return model.find({ userId: empId }, { notificationId: 1, _id: 0 }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                var i = 0;
                for (i = 0; i < data.length; i++) {
                    teamTaskDb.deleteOneNotification(empId, data[i].notificationId);
                }
                return empId;
            }
        })
    })
}

teamTaskDb.viewCompletedProjectDetailsForTeamMember = (empId, projectId) => {
    return dbModel.getProjectCollection().then((model => {
        return model.findOne({ empId: empId, projectId: projectId }, { empId: 1, tasks: 1, _id: 0 }).then((data) => {
            if (data.length === 0) {
                return null;

            }
            else {
                var arr = data.tasks;
                return dbModel.getUserCollection().then((model1) => {
                    return model1.find({ userId: { $in: data.empId } }, { userName: 1, userId: 1, _id: 0 }).then((data1) => {

                        var i = 0;
                        var j = 0;
                        var z = 0;
                        for (i = 0; i < arr.length; i++) {
                            for (z = 0; z < arr[i].empId.length; z++) {
                                for (j = 0; j < data1.length; j++) {
                                    if (arr[i].empId[z] === data1[j].userId) {
                                        arr[i].empId[z] = data1[j].userName;
                                    }
                                }
                            }

                        }

                        return data;
                    })
                })


            }
        })
    }))
}

teamTaskDb.createRequest = (requestCreation) => {
    return dbModel.getRequestCollection().then((model) => {
        return teamTaskDb.generateRequestId().then((requestId) => {
            requestCreation.requestId = requestId;


            if (requestCreation.requestType === "Leave") {
                requestCreation.projectId = "";
                requestCreation.tasksId = "";
                return model.create(requestCreation).then((output) => {
                    if (output) {
                        return requestCreation.requestId;
                    }
                    else {
                        let err = new Error("request creation failed");
                        err.status = 400;
                        throw err;
                    }

                })
            }
            else {
                return dbModel.getProjectCollection().then((model2) => {
                    return model2.findOne({ projectName: requestCreation.projectName }, { projectId: 1, _id: 0 }).then((projectId) => {
                        requestCreation.projectId = projectId.projectId;
                        return model2.findOne({ projectName: requestCreation.projectName, "tasks.tasksName": requestCreation.taskName }, { _id: 0, "tasks.$.tasksId": 1 }).then((tasksId => {

                            requestCreation.tasksId = tasksId.tasks[0].tasksId;
                            return model.create(requestCreation).then((output) => {
                                if (output) {
                                    return requestCreation.requestId;
                                }
                                else {
                                    let err = new Error("request creation failed");
                                    err.status = 400;
                                    throw err;
                                }

                            })
                        }))
                    })
                })
            }



        })
    })
}
teamTaskDb.viewRequestsForTeamMember = (userId) => {
    return dbModel.getRequestCollection().then((model) => {
        return model.find({ userId: userId }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                return data;
            }
        })
    })
}
// teamTaskDb.viewAllOngoingProjectsForTeamMember=(empId)=>{
//     return dbModel.getProjectCollection().then((model)=>{
//         return model.find({empId:empId,status:"Ongoing"},{projectId:1,projectName:1,_id:0}).then((data)=>{
//                 if(data.length===0){
//                     return null;
//                 }
//                 else{
//                     return data;
//                 }
//         })
//     })
//}
teamTaskDb.viewAllTasksForTeamMember = (projectId) => {
    return dbModel.getProjectCollection().then((model) => {
        return model.find({ projectId: projectId }, { "tasks.tasksId": 1, "tasks.tasksName": 1, _id: 0 }).then((data) => {
            if (data.length === 0) {
                return null;
            }
            else {
                return data;
            }
        })
    })
}
module.exports = teamTaskDb;