class ProjectCreation {
    constructor(obj) {
        this.projectId=obj.projectId;
        this.projectName=obj.projectName;
        this.description=obj.description;
        this.empId=obj.empId;
        this.timeline=obj.timeline;
        this.managerId=obj.managerId;
        this.tasks=obj.tasks;
    }
}

module.exports = ProjectCreation;