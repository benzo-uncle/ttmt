let Validator = {};

Validator.validateProjectId = function (projectId) {
    let pattern = new RegExp("^[P][1-9][0-9]{3}$");
    if (!(pattern.test(projectId))) {
        let err = new Error("Error in project Id");
        err.status = 406
        throw err;
    }
}

Validator.validateTaskId = function (taskId) {
    let pattern = new RegExp("^[T][1-9][0-9]{3}$");
    if (!(pattern.test(taskId))) {
        let err = new Error("Error in task Id");
        err.status = 406
        throw err;
    }
}

Validator.validateUserId = function (userId) {
    let pattern = new RegExp("^[U][1-9][0-9]{3}$");
    if (!(pattern.test(userId))) {
        let err = new Error("Error in user Id");
        err.status = 406
        throw err;
    }
}


module.exports = Validator;