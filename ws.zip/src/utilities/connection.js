const { Schema } = require("mongoose");
const Mongoose = require("mongoose")
Mongoose.Promise = global.Promise;
Mongoose.set('useCreateIndex', true)
const url = "mongodb://localhost:27017/TaskManagementDb";

const userSchema = Schema({
    userId: String,
    userName: String,
    emailId: String,
    password: String,
    availability: { type: String, enum: ['Assigned', 'On-Leave', 'Available'] },
    empType: { type: String, enum: ['Manager', 'TeamMember'] },
    rating: Number,
    completedTaskCount: { type: Number, default: 0 },
    projectsId: [String],
}, { collection: "Users" });


const tasksSchema = Schema({
    tasksId: String,
    tasksName: String,
    empId: [String],
    extensions: {},//key-value pairs(key:employee's id,value:Number of Days)
    status: { type: String, enum: ['Ongoing', 'Completed'] },
    tasksRating: Number,
    timeline: {
        startDate: { type: Date, default: new Date() },
        endDate: { type: Date, default: new Date() },
    },
    comment: String
})

const projectSchema = Schema({
    projectId: String,
    projectName: String,
    managerId: String,
    empId: [String],
    percentage: { type: Number, default: 0 },
    status: { type: String, enum: ['Ongoing', 'Completed'] },
    timeline: {
        startDate: { type: Date, default: new Date() },
        endDate: { type: Date, default: new Date() },
    },
    description: String,
    tasks: { type: [tasksSchema], default: [] }
}, { collection: "Projects" })



const requestSchema = Schema({
    requestId: String,
    projectId: String,
    projectName: String,
    userId: String,
    userName: String,
    requestType: { type: String, enum: ["Leave", "TimeExtension", "NewTask", "UpdateStatus"] },
    taskStatus: String,
    requestReason: String,
    taskName: String,
    tasksId: String,
    // date:Date,
    // time:String,
    timeline: {
        startDate: { type: Date, default: new Date() },
        endDate: { type: Date, default: new Date() },
    },
    NoOfDays: Number,
    requestStatus: { type: String, enum: ["Accepted", "Rejected", "Pending"] }
}, { collection: "Request" })

const eventSchema = Schema({
    eventId: String,
    eventName: String,
    createdBy: String,//manager's user id
    projectName: String,
    eventDate: { type: Date, default: new Date() },
    time: String,
    venue: String,
    reason: String,
    members: [String],//employee's user id
    status: { type: String, enum: ["Completed", "Pending", "Upcoming"] }
}, { collection: "Event" })

const notificationSchema = Schema({
    notificationId: String,
    notificationType: { type: String, enum: ["Task Status Request", "Event"] },
    managerId: String,
    projectId: String,
    projectName: String,
    userId: [String],
    eventId: String,
    eventName: String,
    taskId: String,
    taskName: String,
    date: Date,
    time: String,
    venue: String,
}, { collection: "Notification" })


let collection = {};

collection.getUserCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('Users', userSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}
collection.getProjectCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('Projects', projectSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}


collection.getRequestCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('Request', requestSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}

collection.getEventCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('Event', eventSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;;
        throw err;
    })
}

collection.getNotificationCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('Notification', notificationSchema)
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;;
        throw err;
    })
}

module.exports = collection;