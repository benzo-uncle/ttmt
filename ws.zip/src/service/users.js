const db = require('../model/users');
const validator = require('../utilities/validator');


let teamTaskService={};

var userDetail = {}

teamTaskService.password = (userEmailId, password) => {
    return db.userDetails(userEmailId).then((userDetailAll) => {
        if (userDetailAll === null) {
            let err = new Error("Invalid Email ID");
            err.status = 404;
            throw err;
        } else if (userDetailAll.password !== password) {
            let err = new Error("Password Incorrect");
            err.status = 404;
            throw err;
        } else {
            userDetail.userId = userDetailAll.userId
            userDetail.userName = userDetailAll.userName
            userDetail.empType = userDetailAll.empType
            return userDetail;
        }
    })
}
teamTaskService.getManagerId=()=>{
    return db.getManagerId().then((data)=>{
        if(data===null){
            let err = new Error("No manager is there");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.getProjectByProjectId=(projectId)=>{
    return db.getProjectByProjectId(projectId).then((data)=>{
        if(data===null){
            let err = new Error("No project is there");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.getTaskByTaskId=(projectId,tasksId)=>{
    return db.getTaskByTaskId(projectId,tasksId).then((data)=>{
        if(data===null){
            let err = new Error("No task is there");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}


teamTaskService.viewAllEmployees=()=>{
    return db.viewAllEmployees().then((data)=>{
        if(data===null){
            let err = new Error("No employees are there");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.createNotification=(notificationCreation)=>{
    return db.createNotification(notificationCreation).then((notificationId)=>{
        return notificationId;
    })

}
teamTaskService.createProject=(projectCreation)=>{
    return db.createProject(projectCreation).then((projectId)=>{
        return projectId;
    })

}
teamTaskService.updateProject=(projectCreation)=>{
    return db.updateProject(projectCreation).then((projectId)=>{
        return projectId;
    })

}
teamTaskService.deleteProject=(projectId)=>{
    return db.deleteProject(projectId).then((pId)=>{
        return pId;
    })
}
teamTaskService.updateTask=(taskCreation,projectId)=>{
    return db.updateTask(taskCreation,projectId).then((tId)=>{
        return tId;
    })
}
teamTaskService.deleteTask=(projectId,tasksId)=>{
    return db.deleteTask(projectId,tasksId).then((tId)=>{
        return tId;
    })
}
teamTaskService.addNewTask=(taskCreation,projectId)=>{
    return db.addNewTask(taskCreation,projectId).then((tId)=>{
        return tId;
    })
}
teamTaskService.viewAllProjects=()=>{
    return db.viewAllProjects().then((projects)=>{
        if (projects === null) {
            let err = new Error("No Ongoing Projects");
            err.status = 404;
            throw err;
        } else {
            return projects;
        }
    })
}
teamTaskService.viewAllTeamMembersAndAvaialbilityByType=()=>{
    return db.viewAllTeamMembersAndAvaialbilityByType().then((emps)=>{
        if(emps===null){
            let err = new Error("No team members to show");
            err.status = 404;
            throw err;
        }
        else{
            return emps;
        }
    })
}
teamTaskService.updateStatus=(requestCreation)=>{
    return db.updateStatus(requestCreation).then((status)=>{
        return status;
    })
}
teamTaskService.updateProjectTimeline=(projectId,managerId,startDate,endDate)=>{
    return db.updateProjectTimeline(projectId,managerId,startDate,endDate).then((data)=>{
        return data;
    })
}
teamTaskService.updateTaskTimeline=(projectId,managerId,taskId,startDate,endDate)=>{
    return db.updateTaskTimeline(projectId,managerId,taskId,startDate,endDate).then((data)=>{
        return data;
    })
}



teamTaskService.viewOngoingProjects=(managerId)=>{
    validator.validateUserId(managerId);
    return db.viewOngoingProjects(managerId).then((projects)=>{
        if (projects === null) {
            let err = new Error("No Ongoing Projects");
            err.status = 404;
            throw err;
        } else {
            return projects;
        }
    })
}
teamTaskService.viewOngoingProjectDetails=(managerId,projectId)=>{
    validator.validateProjectId(projectId);
    return db.viewOngoingProjectDetails(managerId,projectId).then((data)=>{
        if(data===null){
            let err = new Error("No tasks details available");
            err.status = 404;
            throw err;
        }
        else{
           

           return data;
        }
    })
}

teamTaskService.viewCompletedProjects=(managerId)=>{
    validator.validateUserId(managerId);
    return db.viewCompletedProjects(managerId).then((projects)=>{
        if (projects === null) {
            let err = new Error("No Completed Projects");
            err.status = 404;
            throw err;
        } else {
            return projects;
        }
    })
}
teamTaskService.viewCompletedProjectDetails=(managerId,projectId)=>{
    validator.validateProjectId(projectId);
    return db.viewCompletedProjectDetails(managerId,projectId).then((data)=>{
        if(data===null){
            let err = new Error("No tasks details available");
            err.status = 404;
            throw err;
        }
        else{
           return data;
        }
    })
}

// teamTaskService.assignTask=(projectId,taskCreation)=>{
//     return db.assignTask(projectId,taskCreation).then((taskId)=>{
//         return taskId;
//     })
// }
// teamTaskService.addTeamMemberWithNewTask=(projectId,taskCreation)=>{
//     return db.addTeamMemberWithNewTask(projectId,taskCreation).then((taskId)=>{
//         return taskId;
//     })
// }
// teamTaskService.addTeamMemberToExistingTask=(projectId,taskId,empId)=>{
//     return db.addTeamMemberToExistingTask(projectId,taskId,empId).then((data)=>{
//         return data;
//     })
// }
teamTaskService.getProjectEmpNames=(projectName)=>{
    
    return db.getProjectEmpNames(projectName).then(data=>{
        if(data===null){
            return null;
        }
        else{
            return data;
        }
    })
}

teamTaskService.getEmpDetails=(empId)=>{
    validator.validateUserId(empId);
    return db.getEmpDetails(empId).then((data)=>{
        if(data===null){
            let err = new Error("No emp details available");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}

teamTaskService.downloadReportByUser=(userId)=>{
    return db.downloadReportByUser(userId).then((data)=>{
        if(data===null){
            let err = new Error("invalid user");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.searchEmp=(emp)=>{
    return db.searchEmp(emp).then((data)=>{
        if(data===null){
            let err = new Error("No emp details available");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}


teamTaskService.viewLeaveRequests=()=>{
    return db.viewLeaveRequests().then((data)=>{
        if(data===null){
            let err = new Error("No Leave requests");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}

teamTaskService.viewTimeExtensionRequests=()=>{
    return db.viewTimeExtensionRequests().then((data)=>{
        if(data===null){
            let err = new Error("No Time Extension requests");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}

teamTaskService.viewNewTaskRequests=()=>{
    return db.viewNewTaskRequests().then((data)=>{
        if(data===null){
            let err = new Error("No New Task requests");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.viewStatusUpdateRequest=()=>{
    return db.viewStatusUpdateRequest().then((data)=>{
        if(data===null){
            let err = new Error("No status update requests");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.acceptLeaveRequests=(userId,requestId,requestStatus)=>{
    return db.acceptLeaveRequests(userId,requestId,requestStatus).then((data)=>{
        return data;
    })
}
teamTaskService.acceptTimeExtensionRequests=(projectId,tasksId,requestId,requestStatus,extension)=>{
    return db.acceptTimeExtensionRequests(projectId,tasksId,requestId,requestStatus,extension).then((data)=>{
        return data;
    })
}
teamTaskService.acceptNewTaskRequests=(projectId,taskCreation,requestId,requestStatus)=>{
    return db.acceptNewTaskRequests(projectId,taskCreation,requestId,requestStatus).then((data)=>{
        return data;
    })
}

teamTaskService.acceptStatusUpdateRequests = (projectId, tasksId, requestId, requestStatus,value) => {
    return db.acceptStatusUpdateRequests(projectId, tasksId, requestId, requestStatus,value).then((data) => {
        console.log("service",value);
        return db.updateProjectStatus(projectId).then((result) => {
            if (result === true) {
                
                return db.updateUserRating(requestId,tasksId,projectId,value).then((result2)=>{
                    if (result2===true){
                        return data;
                    }
                })
            }
        })
    })
}

teamTaskService.updateRequestStatus=(requestId,requestStatus)=>{
    return db.updateRequestStatus(requestId,requestStatus).then((status)=>{
        return status;
    })
}
teamTaskService.viewAcceptedRequests=()=>{
    return db.viewAcceptedRequests().then((data)=>{
        if(data===null){
            let err = new Error("No Accepted available");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.createEvent=(eventCreation)=>{
    return db.createEvent(eventCreation).then((eventId)=>{
        return eventId;
    })
}
teamTaskService.updateEvent=(eventCreation)=>{
    return db.updateEvent(eventCreation).then((eventId)=>{
        return eventId;
    })
}
teamTaskService.deleteEvent=(eventId)=>{
    return db.deleteEvent(eventId).then((eventId)=>{
        return eventId;
    })
}
teamTaskService.viewEventByDate=(userId,eventDate)=>{
    return db.viewEventByDate(userId,eventDate).then((events)=>{
        if(events===null){
            let err = new Error("No events..");
            err.status = 404;
            throw err;
        }
        else{
            return events;
        }
    })
}

teamTaskService.viewEventByEventId=(eventId)=>{
    return db.viewEventByEventId(eventId).then((event)=>{
        if(event===null){
            let err = new Error("No event..");
            err.status = 404;
            throw err;
        }
        else{
            return event;
        }
    })
}
//for member.......
// teamTaskService.viewCompletedTasksForTeamMember=(empId)=>{
//     validator.validateUserId(empId);
//     return db.viewCompletedTasksForTeamMember(empId).then((data)=>{
//         if(data===null){
//             let err = new Error("No completed tasks details available");
//             err.status = 404;
//             throw err;
//         }
//         else{
//             return data;
//         }
//     })
// }

teamTaskService.viewOngoingTasksForTeamMember=(empId)=>{
    validator.validateUserId(empId);
    return db.viewOngoingTasksForTeamMember(empId).then((data)=>{
        if(data===null){
            let err = new Error("No ongoing tasks details available");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}

teamTaskService.viewOngoingProjectsForTeamMember=(empId)=>{
    validator.validateUserId(empId);
    return db.viewOngoingProjectsForTeamMember(empId).then((data)=>{
        if(data===null){
            let err = new Error("No Ongoing Projects");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.viewOngoingProjectDetailsForTeamMember=(empId,projectId)=>{
    validator.validateProjectId(projectId);
    return db.viewOngoingProjectDetailsForTeamMember(empId,projectId).then((data)=>{
        if(data===null){
            let err = new Error("No tasks details available");
            err.status = 404;
            throw err;
        }
        else{
           

           return data;
        }
    })
}

teamTaskService.viewCompletedProjectsForTeamMember=(empId)=>{
    validator.validateUserId(empId);
    return db.viewCompletedProjectsForTeamMember(empId).then((projects)=>{
        if (projects === null) {
            let err = new Error("No Completed Projects");
            err.status = 404;
            throw err;
        } else {
            return projects;
        }
    })
}
teamTaskService.viewCompletedProjectDetailsForTeamMember=(empId,projectId)=>{
    validator.validateProjectId(projectId);
    return db.viewCompletedProjectDetailsForTeamMember(empId,projectId).then((data)=>{
        if(data===null){
            let err = new Error("No tasks details available");
            err.status = 404;
            throw err;
        }
        else{
           return data;
        }
    })
}
teamTaskService.createRequest=(requestCreation)=>{
    return db.createRequest(requestCreation).then((requestId)=>{
        return requestId;
    })
}
teamTaskService.viewRequestsForTeamMember=(userId)=>{
    return db.viewRequestsForTeamMember(userId).then((data)=>{
        if(data===null){
            let err = new Error("No Requests avaailable");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.viewNotification=(empId)=>{
    return db.viewNotification(empId).then((data)=>{
        if(data===null){
            let err = new Error("No Notification avaailable");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.deleteOneNotification=(empId,notificationId)=>{
    return db.deleteOneNotification(empId,notificationId).then((data)=>{
        if(data===null){
            let err = new Error("No Notification avaailable for this user");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.deleteAllNotifications=(empId)=>{
    return db.deleteAllNotifications(empId).then((data)=>{
        if(data===null){
            let err = new Error("No Notification avaailable for this user");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
teamTaskService.downloadReportByProject=(projectId)=>{
    return db.downloadReportByProject(projectId).then((data)=>{
        if(data===null){
            let err = new Error("invalid project");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
// teamTaskService.viewAllOngoingProjectsForTeamMember=(empId)=>{
//     return db.viewAllOngoingProjectsForTeamMember(empId).then((data)=>{
//         if(data===null){
//             let err = new Error("No projects avaailable");
//             err.status = 404;
//             throw err;
//         }
//         else{
//             return data;
//         }
//     })
// }
teamTaskService.viewAllTasksForTeamMember=(projectId)=>{
    return db.viewAllTasksForTeamMember(projectId).then((data)=>{
        if(data===null){
            let err = new Error("No tasks in the selected project");
            err.status = 404;
            throw err;
        }
        else{
            return data;
        }
    })
}
module.exports=teamTaskService;