import React from 'react';
import { Button } from 'primereact/button';
import axios from "axios";
import { MySpinner } from '../MySpinner'

const url = 'http://localhost:2040/viewTimeExtensionRequests';
const url1='http://localhost:2040/updateRequestStatus/';
const url2='http://localhost:2040/acceptTimeExtensionRequests/';
// {project name}
// task name
// no of days
// reason 
// members
export class RequestExtension extends React.Component {
    constructor() {
        super();
        this.state = {
            count: 0,
            timeExtensionData:[],
            errorMessage:"",
            successMessage:"",
            updateStatus: false,
            requestId:"",
            requestStatus:""
        };
        this.increment = this.increment.bind(this);
    }
    increment() {
        this.setState((prevState, props) => ({
            count: prevState.count + 1
        }));
    }
    componentDidMount(){
        this.fetchTimeExtensionRequests();
    }
    fetchTimeExtensionRequests=()=>{
        
        axios.get(url)
            .then(response => this.setState({ timeExtensionData: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, timeExtensionData: [] })
                } else {
                    this.setState({ errorMessage: error.message, timeExtensionData: [] })
                }
            })
    }
    handleSubmitAccepted=(requestStatus,requestId,projectId,tasksId,extension)=>{
        this.setState({updateStatus:true,requestId:requestId, requestStatus:requestStatus});
        this.acceptRequestStatus(requestStatus,requestId,projectId,tasksId,extension);
    }
    acceptRequestStatus=(requestStatus,requestId,projectId,tasksId,extension)=>{
        this.setState({ successMessage: "", errorMessage: "" })
        var form={requestStatus:"",
                    extension:0
                };
        form.requestStatus=requestStatus;
        form.extension=extension;
        axios.put(url2+projectId+"/"+tasksId+"/"+ requestId, form)
            .then(response => {console.log("out",response.data.message);
                this.setState({ successMessage: response.data.message, errorMessage: "" });
            this.fetchTimeExtensionRequests();
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }
    handleSubmit=(requestStatus,requestId)=>{
        
        this.setState({updateStatus:true,requestId:requestId, requestStatus:requestStatus});
        this.updaterequestStatus(requestStatus,requestId)
    }
    updaterequestStatus=(requestStatus,requestId)=>{
        this.setState({ successMessage: "", errorMessage: "" })
        var form={requestStatus:""};
        form.requestStatus=requestStatus;
        axios.put(url1 + requestId, form)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" });
               
            this.fetchTimeExtensionRequests();
           
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }
    createTimeExtensionCard=(data)=>{
        return(
            <div className="card m-1">
            <div className="card-body shadow bg-white rounded">
                {/* {this.props.prod.name} */}
                <div className="card-title">
                    <div className="row ">
                        <div className="col-md-12">
                            <span className="text-muted" style={{ fontSize: "16px" }}>Project Name : </span>
                            <span className="blockquote" > {data.projectName} </span>
                        </div>
                    </div>
                </div>
                <div className="card-text">
                    {/* {this.props.prod.price} */}
                    <div className="row">
                        <div className="col-md-7" style={{ float: "left" }}>
                            <div >
                                <span className="text-muted ml-2" style={{ fontSize: "13px" }}>Requested from : </span>
                                <span className="text-success" style={{ fontSize: "16px" }}> {data.userName} </span>
                            </div>

                            <div className="mt-1">
                                <span className="text-muted ml-2" style={{ fontSize: "13px" }}>Task Name : </span>
                                <span style={{ fontSize: "17px" }}> {data.taskName} </span>
                            </div>

                            <div className="text-danger ml-2"  >Extension Requested : {data.NoOfDays} Days</div>
                        </div>
                        <div className="col-md-5"  >
                            <Button label="Accept" className="p-button-raised p-button-success ml-2 mt-3 " icon="pi pi-check" value={data.requestId} onClick={()=>this.handleSubmitAccepted("Accepted",data.requestId,data.projectId,data.tasksId,data.NoOfDays)} />
                            <Button label="Reject" className="p-button-raised p-button-danger ml-2 mt-3" icon="pi pi-times" value={data.requestId} onClick={()=>this.handleSubmit("Rejected",data.requestId)}/>
                        </div>
                        <div className="text-secondary font-italic ml-3 mt-2">Reason : {data.requestReason} </div>
                    </div>
                </div>
            </div>
        </div>
        )
    }
    render() {
       
        return (
            <React.Fragment>
            {this.state.timeExtensionData.length ? this.state.timeExtensionData.map((data)=>( this.createTimeExtensionCard(data))) : <MySpinner/>}


        </React.Fragment>
        )
    }
}