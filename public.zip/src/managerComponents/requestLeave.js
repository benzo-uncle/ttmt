import React from 'react';
import { RequestLeaveCard } from './requestLeaveCard';
import { Button } from 'primereact/button';
import axios from "axios";
import { EOVERFLOW } from 'constants';
import { MySpinner } from '../MySpinner'


const url = 'http://localhost:2040/viewLeaveRequests';
const url1='http://localhost:2040/updateRequestStatus/';
const url2='http://localhost:2040/acceptLeaveRequests/';
export class RequestLeave extends React.Component {
    constructor() {
        super();
        this.state = {
            count: 0,
            leaveData:[],
            errorMessage:"",
            successMessage:"",
            updateStatus: false,
            requestId:"",
            requestStatus:""
        };
        this.increment = this.increment.bind(this);
    }

    increment() {
        this.setState((prevState, props) => ({
            count: prevState.count + 1
        }));
    }
    componentDidMount(){
        this.fetchLeaveRequests();
    }
    fetchLeaveRequests=()=>{
        axios.get(url)
            .then(response => this.setState({ leaveData: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, leaveData: [] })
                } else {
                    this.setState({ errorMessage: error.message, leaveData: [] })
                }
            })
    }
    handleSubmitAccepted=(requestStatus,requestId,userId)=>{
        this.setState({updateStatus:true,requestId:requestId, requestStatus:requestStatus});
        this.acceptRequestStatus(requestStatus,requestId,userId);
    }
    acceptRequestStatus=(requestStatus,requestId,userId)=>{
        this.setState({ successMessage: "", errorMessage: "" })
        var form={requestStatus:""};
        form.requestStatus=requestStatus;
        axios.put(url2+userId+"/"+ requestId, form)
            .then(response => {console.log("out",response.data.message);
                this.setState({ successMessage: response.data.message, errorMessage: "" });
            this.fetchLeaveRequests();
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }
    handleSubmit=(requestStatus,requestId)=>{
    
        this.setState({updateStatus:true,requestId:requestId, requestStatus:requestStatus});
        this.updaterequestStatus(requestStatus,requestId)
    }
    updaterequestStatus=(requestStatus,requestId)=>{
        this.setState({ successMessage: "", errorMessage: "" })
        var form={requestStatus:""};
        form.requestStatus=requestStatus;
        axios.put(url1 + requestId, form)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" });
            this.fetchLeaveRequests();
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }
    createLeaveRequestCard=(leave)=>{
        return(
            <div className="card m-1">
                <div className="card-body shadow bg-white rounded">
                    {/* {this.props.prod.name} */}
                    <div className="card-title">
                        <div className="row ">
                            <div className="col-md-12">
                                <span className="text-muted" >Leave request from : </span>
                                <span className="text-success" style={{ fontSize: "17px" }}>{leave.userName}</span>
                            </div>
                        </div>
                    </div>
                    <div className="card-text">
                        <div className="row">
                            <div className="col-md-7">
                                <div style={{ float: "left" }}>
                                    <span className="text-info m-1" style={{ display: "inline" }}>From : <strong>{new Date(leave.timeline.startDate).toLocaleDateString()}</strong></span>
                                    <span className="text-info m-1" style={{ display: "inline" }}>To : <strong>{new Date(leave.timeline.endDate).toLocaleDateString()}</strong></span>
                                </div><br />
                                <div className="text-danger mt-1 ml-3" >Total Days : {leave.NoOfDays}</div>
                            </div>
                            <div className="col-md-5 "  >
                                <Button label="Accept" className="p-button-raised p-button-success m-1 " icon="pi pi-check" name="Accepted" id="Accepted" value={leave.requestId} onClick={()=>this.handleSubmitAccepted("Accepted",leave.requestId,leave.userId)}  />
                                <Button label="Reject" className="p-button-raised p-button-danger m-1 " icon="pi pi-times" name="Rejected" id="Rejected" value={leave.requestId} onClick={()=>this.handleSubmit("Rejected",leave.requestId)} />
                            </div>
                        </div>
                        <div className="text-secondary font-italic mt-2">Reason : {leave.requestReason}</div>
                    </div>
                </div>
            </div>
        )
    }
    
    render() {
        
        
        
        
        return (
            <React.Fragment>
          
           {this.state.leaveData.length ? this.state.leaveData.map((leave)=>(this.createLeaveRequestCard(leave))): <MySpinner/>}

        </React.Fragment>
        )
    }
}