import React from 'react'
import { CompletedTeamView } from './completedTeamView';
import axios from "axios";

import { connect } from 'react-redux'

const url1 = 'http://localhost:2040/viewCompletedProjectDetails/';

class Completedcard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            btnStatus: false,
            btnLabel: "View Details",
            projectDetailsData: {
                tasks: [],
                status: false
            },
            errorMessage: "",
            userId: this.props.loginDetails.userId
        }
    }
    handleClick = (projectId) => {

        if (this.state.btnStatus === false) {
            this.setState({ btnStatus: true, btnLabel: "Close" })
            this.fetchCompletedProjectDetails(projectId);
        }
        else {
            this.setState({ btnStatus: false, btnLabel: "View Details", projectDetailsData: {} })
        }
    }
    fetchCompletedProjectDetails = (projectId) => {
        axios.get(url1 + this.state.id + "/" + projectId)
            .then(response => {
                this.setState({ projectDetailsData: response.data, errorMessage: "" })
            })
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, projectDetailsData: {} })
                } else {
                    this.setState({ errorMessage: error.message, projectDetailsData: {} })
                }
            })
    }
    render() {

        return (
            <div className="card shadow bg-white rounded">
                <div className="card-header">
                    <div className="row ">
                        <div className="col-md-12">
                            <span className="text-muted" style={{ fontSize: "16px" }}>Project Name : </span>
                            <span className="blockquote" >{this.props.project.projectName}</span>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-9">
                            <div style={{ float: "left" }}>
                                <span className="text-info m-1" style={{ display: "inline" }}>Start Date : <strong>{new Date(this.props.project.timeline.startDate).toLocaleDateString()}</strong></span>
                                <span className="text-info m-1" style={{ display: "inline" }}>End Date : <strong>{new Date(this.props.project.timeline.endDate).toLocaleDateString()}</strong></span>
                            </div>

                        </div>
                        <div className="col-md-3 d-flex justify-content-center">
                            <button value={this.props.project.projectId} name={this.state.btnLabel} id={this.state.btnLabel} onClick={() => this.handleClick(this.props.project.projectId)} className="btn btn-primary"><b>{this.state.btnLabel}</b></button>
                        </div>
                    </div>
                    <div className="row mt-1">
                        <div className="col-md-12">
                            <span className="text-muted font-italic" style={{ fontSize: "16px" }}>Project Description : </span>
                            <span className="text-dark font-italic" >{this.props.project.description}</span>
                        </div>
                    </div>
                </div>
                {this.state.projectDetailsData.tasks ? <CompletedTeamView key={this.props.project.projectId} details={this.state.projectDetailsData} /> : null}
            </div>


        )
    }
}


const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(Completedcard);
