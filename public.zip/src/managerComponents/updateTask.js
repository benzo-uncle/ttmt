import React from 'react';
import axios from "axios";

import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

import UpdateProjectComp from './updateProject';
import UpdateTaskComp from './updateTaskViewComp';
import AddTaskComp from './updateAddTask';

import { connect } from 'react-redux';

const url = 'http://localhost:2040/viewOngoingProjects/';
const url1 = 'http://localhost:2040/getProjectByProjectId/';
const url2 = 'http://localhost:2040/viewAllEmployees';


class Update extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            form: {
                projectName: "",
                managerAction: ""
            },

            formError: {
                projectName: "",
                managerAction: ""
            },

            formValid: {
                projectName: false,
                managerAction: false,
                buttonActive: false
            },
            mainComp: true,
            requestType: "",
            acceptedRequestsData: [],
            errorMessage: "",
            userId: this.props.loginDetails.userId,
            successMessage: "",
            projectsArr: [],
            project: {}
        }
    }

    handleSubmit = event => {
        event.preventDefault();
        this.loadComponent();
    }

    

    getProjectByProjectId = (projectId) => {
        axios.get(url1 + projectId)
            .then(response => this.setState({ project: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, project: [] })
                } else {
                    this.setState({ errorMessage: error.message, project: [] })
                }
            })
    }

    handleChange = event => {
        var form = this.state.form
        if (event.target.name === "projectName") {

            form.projectName = event.target.value;
            this.getProjectByProjectId(event.target.value);

        } else
            if (event.target.name === "managerAction") {
                form.managerAction = event.target.value

            }
        this.setState({ form: form });
        this.validateField(event.target.name, event.target.value);
    }


    validateField = (fieldName, value) => {
        let formValid = this.state.formValid
        switch (fieldName) {
            case "projectName":
                if (value === "") {
                    formValid.projectName = false
                } else {
                    formValid.projectName = true
                }
                break;

            case "managerAction":
                if (value === "") {
                    formValid.managerAction = false
                } else {
                    formValid.managerAction = true
                }
                break;

            default:
                break;
        }

        formValid.buttonActive = formValid.projectName && formValid.managerAction;
        this.setState({ formValid: formValid })
    }

    loadComponent = () => {
        this.setState({ mainComp: false })

    }
    componentDidMount() {
        // this.setState({id:this.props.location.state.userId})
        this.fetchOngoingProjects();
    }
    fetchOngoingProjects = () => {
        axios.get(url + this.state.userId)
            .then(response => this.setState({ projectsArr: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, projectsArr: [] })
                } else {
                    this.setState({ errorMessage: error.message, projectsArr: [] })
                }
            })
    }
    render() {

        console.log(this.state.project)
        var redirect
        switch (this.state.form.managerAction) {

            case "updateProject":
                redirect = <UpdateProjectComp project={this.state.project} />
                break;
            case "updateTask":
                redirect = <UpdateTaskComp project={this.state.project} />
                break;
            case "addTask":
                redirect = <AddTaskComp project={this.state.project} />
                break;

        }


        return (

            <React.Fragment>
             
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="card shadow bg-white rounded">
                                {this.state.mainComp ? <div className="card-header">

                                    <form onSubmit={this.handleSubmit}>
                                        <div className="form-group row">
                                            <div className="col-md-3">
                                                <label className="text-success col-form-label col-form-label-md" for="pname"> <strong>Project Name :</strong> </label>
                                            </div>
                                            <div className="col-md-9">
                                                <select id="pname" name="projectName" className="form-control" onChange={this.handleChange}>
                                                    <option value="" disabled selected>--Choose Project--</option>
                                                    {this.state.projectsArr.length > 0 ?
                                                        this.state.projectsArr.map(project => <option key={project.projectId} value={project.projectId}>{project.projectName}</option>)
                                                        : null}
                                                </select>
                                            </div>
                                        </div>

                                        <div className="form-group row">
                                            <div className="col-md-3">
                                                <label className="text-success col-form-label col-form-label-md" for="maction"> <strong>Manager Action :</strong> </label>
                                            </div>
                                            <div className="col-md-9">
                                                <select id="pname" name="managerAction" onChange={this.handleChange} className="form-control ">
                                                    <option value="" disabled selected>--Choose an Action--</option>
                                                    <option name="projectUpdate" value="updateProject">Update Project</option>
                                                    <option name="taskUpdate" value="updateTask">Update Task</option>
                                                    <option name="taskAdd" value="addTask">Add Task</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div className="form-group row">
                                            <div className="col-md-12 mt-1" style={{ "marginBottom": "-15px" }}>
                                                <button disabled={!this.state.formValid.buttonActive} className="btn btn-warning float-right"><strong>Update</strong></button>
                                            </div>
                                        </div>
                                    </form>
                                </div> : redirect}

                            </div>
                        </div>

                    </div>
                </div>
            </React.Fragment>
        )
    }
}
const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(Update);
