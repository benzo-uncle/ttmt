import React from 'react'
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { Button } from 'primereact/button';
import { ProgressSpinner } from 'primereact/progressspinner';
import Alert from './alert';
import axios from "axios";
import { Rating } from 'primereact/rating';
import { connect } from 'react-redux'
import ReactTooltip from 'react-tooltip'

const url = "http://localhost:2040/createNotification/";

// import StarRatings from 'react-star-rating-component';


class OngoingViewDetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            successMessage: "",
            errorMessage: "",
            id: this.props.loginDetails.userId,
            alertStatus:false
        }
    }

    messageAction = (message, messageType) => {
        var action = {
            type: "ALERT_MESSAGE",
            message: message,
            messageType: messageType
        }
        this.props.dispatch(action);
        this.setState({ messageStatus: false })
    }



    handleClick = (details, projectId, projectName) => {
        console.log("details : ", details, projectId, projectName);
        var time = new Date().toLocaleTimeString();
        var date = new Date().toLocaleDateString();

        var form = {
            projectId: projectId,
            projectName: projectName,
            taskName: details.tasksName,
            taskId: details.tasksId,
            userId: details.empId,
            notificationType: "Task Status Request",
            eventName: "",
            venue: "",
            time: time,
            date: date

        }
        console.log("form", form)
        this.setState({ successMessage: "", errorMessage: "" })
        axios.post(url + this.state.id, form)
            .then(response => {
                this.messageAction(response.data.message,"success")
                this.setState({ alertStatus:true,successMessage: response.data.message, errorMessage: "" });

            }).catch(error => { 
                this.messageAction(error.response.data.message,"danger")
                this.setState({ alertStatus:true,errorMessage: error.response.data.message, successMessage: "" }); });
    }
    render() {

        var tasks = this.props.projectDetailsData.tasks;
        var projectId = this.props.projectDetailsData.projectId;
        var projectName = this.props.projectDetailsData.projectName;
        return (
            <React.Fragment>
                {this.state.alertStatus ? <Alert/>: null}
            <div className="card-body">
                <div className="row ">
                    {this.props.projectDetailsData.status === false ? <ProgressSpinner animationDuration="1s" style={{ width: '50px' }} /> : <div className="col-md-12">
                        <div className="row mb-3">
                            <span className="col-md-2 text-muted font-italic" style={{ fontSize: "14px" }}>Project Description : </span>
                            <span className="col-md-9 text-dark font-italic" style={{ fontSize: "15px", marginLeft: "-0.70em" }}>{this.props.projectDetailsData.description}</span>
                        </div>
                        <div>
                            <table className="table table-hover text-center">
                                <thead className="thead-light">
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Member Name</th>
                                        <th scope="col">Task Name</th>
                                        <th scope="col">Current Status</th>
                                        <th scope="col">Request Status</th>
                                        <th scope="col">Timeline</th>
                                    </tr>

                                </thead>
                                <tbody>
                                    {tasks.map((details, index) => (

                                        <tr>
                                            <th scope="row">{index + 1}</th>
                                            <td>{details.empId}</td>
                                            <td ><a data-tip={details.comment}> {details.tasksName}</a><ReactTooltip place="right" type="info" className="w-25" effect="float" html={true} /></td>
                                            <td>
                                                {details.status === "Ongoing" ? <div><div className="progress">
                                                    <div className="progress-bar progress-bar-striped progress-bar-animated bg-warning" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style={{ width: "50%" }}><b>Ongoing</b></div>
                                                </div></div> : <div><div className="progress progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style={{ width: "100%" }}><b>Completed</b></div>
                                                    </div>}
                                            </td>
                                            <td><Button icon="fa fa-paper-plane" className="p-button-raised  p-button-success " tooltip="Send Request" style={{ width: "5em" }} onClick={() => this.handleClick(details, projectId, projectName)} /></td>
                                            <td>
                                                <span className="text-info" style={{ fontSize: "14px" }}>Start Date : {new Date(details.timeline.startDate).toLocaleDateString()}<br /> End Date : {new Date(details.timeline.endDate).toLocaleDateString()}</span> &nbsp;
                                </td>


                                        </tr>

                                    ))}

                                </tbody>
                            </table>
                        </div>
                    </div>}
                </div>
            </div>
            </React.Fragment>
        )
    }
}
const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(OngoingViewDetails);
