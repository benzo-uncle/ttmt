// import React from "react";
// import ReactExport from "react-data-export";
// import axios from "axios";
// import 'primereact/resources/themes/nova-light/theme.css';
// import 'primereact/resources/primereact.min.css';
// import 'primeicons/primeicons.css';
// import { Button } from 'primereact/button';


// const url='http://localhost:2040/downloadReportByProject'
// const ExcelFile = ReactExport.ExcelFile;
// const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
// const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;

// export class DownloadProjectReport extends React.Component{
//     constructor(props){
//         super(props);
//         this.state={
//             projectDetails:{},
//             errorMessage:""
//         }
//     }

//     componentDidMount(){
//         this.fetchProjectDetails()
//     }
//     fetchProjectDetails =()=>{ 
//         axios.get(url).then(response=>{
//             this.setState({projectDetails:response.data, errorMessage:""})
//         }).catch(error=>{
//             this.setState({errorMessage:error.response.data.message,projectDetails:{}})
//         })
//     }
       

    
   

//     render(){
//         // var projectDetails = this.state.projectDetails;
//         // const dataSet1 = [
//         //     {
//         //         projectId: projectDetails.projectId,
//         //         projectName: projectDetails.projectName,
//         //         managerId: projectDetails.managerId,
//         //         empId: projectDetails.empId      
//         //     }
//         // ];
//         return (
//             console.log(this.state.projectDetails)
//             // <ExcelFile element={<Button icon="pi pi-download" tooltip="Download Project Report" className="p-button-secondary p-button-raised shadow" />}>
//             //     <ExcelSheet data={dataSet1} name="Employees">
//             //         <ExcelColumn label="Name" value="name"></ExcelColumn>
//             //         <ExcelColumn label="Wallet Money" value="amount"></ExcelColumn>
//             //         <ExcelColumn label="Gender" value="gender"></ExcelColumn>
//             //         <ExcelColumn label="Marital Status" value={(col)=> col.is_married?"Married":"Single"}></ExcelColumn>
//             //     </ExcelSheet>
//             //     <ExcelSheet data={dataSet2} name="Leaves">
//             //         <ExcelColumn label="Name" value="name"></ExcelColumn>
//             //         <ExcelColumn label="Total Leaves" value="total"></ExcelColumn>
//             //         <ExcelColumn label="Remaining Leaves" value="remaining"></ExcelColumn>
//             //     </ExcelSheet>
//             // </ExcelFile>
//         )
//     }
// }