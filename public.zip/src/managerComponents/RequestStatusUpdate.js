import React from 'react';
import { Button } from 'primereact/button';
import axios from "axios";
import { ProgressSpinner } from 'primereact/progressspinner';
import { Rating } from 'primereact/rating';
const url = 'http://localhost:2040/viewStatusUpdateRequest';
const url1 = 'http://localhost:2040/updateRequestStatus/';
const url2 = 'http://localhost:2040/acceptStatusUpdateRequests/';
export class RequestStatusUpdate extends React.Component {
    constructor() {
        super();
        this.state = {
            count: 0,
            statusUpdateData: [],
            errorMessage: "",
            successMessage: "",
            updateStatus: false,
            requestId: "",
            requestStatus: "",
            value:"0",
            requestData:{}
        };
        
        this.increment = this.increment.bind(this);
    }

    increment() {
        this.setState((prevState, props) => ({
            count: prevState.count + 1
        }));
    }
    componentDidMount() {
        this.fetchStatusUpdateRequests();
    }
    fetchStatusUpdateRequests = () => {
        axios.get(url)
            .then(response => this.setState({ statusUpdateData: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, statusUpdateData: [] })
                } else {
                    this.setState({ errorMessage: error.message, statusUpdateData: [] })
                }
            })
    }
    handleSubmitAccepted = (requestStatus, requestId, projectId, tasksId) => {
        this.setState({ updateStatus: true, requestId: requestId, requestStatus: requestStatus });
        this.acceptRequestStatus(requestStatus, requestId, projectId, tasksId);
    }
    acceptRequestStatus = (requestStatus, requestId, projectId, tasksId) => {
        this.setState({ successMessage: "", errorMessage: "" })
        var form = { requestStatus: "" , value:""};
        form.value=this.state.value;
        form.requestStatus = requestStatus;
        axios.put(url2 + projectId + "/" + tasksId + "/" + requestId, form)
            .then(response => {
                console.log("out", response.data.message);
                this.setState({ successMessage: response.data.message, errorMessage: "" });
                this.fetchStatusUpdateRequests();
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }
    handleSubmit = (requestStatus, requestId) => {

        this.setState({ updateStatus: true, requestId: requestId, requestStatus: requestStatus });
        this.updaterequestStatus(requestStatus, requestId)
    }
    handleClick = (requestStatus, requestData) => {
        console.log(requestStatus, requestData);
        this.setState({requestData:requestData});

    }
    updaterequestStatus = (requestStatus, requestId) => {
        this.setState({ successMessage: "", errorMessage: "" })
        var form = { requestStatus: "" };
        form.requestStatus = requestStatus;
        axios.put(url1 + requestId, form)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" });
                this.fetchStatusUpdateRequests();
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }


    createStatusUpdateRequestCard = (updateRequest) => {
        return (
            <div className="card m-1">
                <div className="card-body shadow bg-white rounded">
                    <div className="card-title">
                        <div className="row ">
                            <div className="col-md-12">
                                <span className="text-muted" >Task request from : </span>
                                <span className="text-success" style={{ fontSize: "17px" }}>{updateRequest.userName}</span>
                            </div>
                        </div>
                    </div>
                    <div className="card-text">
                        <div className="row">
                            <div className="col-md-7">
                                <div>
                                    <span className="text-muted ml-2" style={{ fontSize: "14px" }}>Project Name : </span>
                                    <span style={{ fontSize: "17px" }}>{updateRequest.projectName}</span>
                                </div>
                                <div>
                                    <span className="text-muted ml-2" style={{ fontSize: "14px" }}>Task Name : </span>
                                    <span style={{ fontSize: "17px" }}>{updateRequest.taskName}</span>
                                </div>
                            </div>
                            <div className="col-md-5"  >
                                <Button label="Accept" className="p-button-raised p-button-success m-1 " icon="pi pi-check" name="Accepted" id="Accepted" value={updateRequest.requestId} data-toggle="modal" data-target="#rating" onClick={() => this.handleClick("Accepted", updateRequest)} />
                                <div className="modal fade" id="rating" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div className="modal-dialog modal-dialog-centered" role="document">
                                        <div className="modal-content">
                                            <div className="modal-header">
                                                <h5 className="modal-title" id="exampleModalLabel"><b>Rating</b></h5>
                                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div className="modal-body">
                                                <form><center>
                                                    <Rating value={this.state.value} cancel={false} onChange={(e) => this.setState({ value: e.value })} />
                                                </center></form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="button" class="btn btn-primary" onClick={() => this.handleSubmitAccepted("Accepted", this.state.requestData.requestId, this.state.requestData.projectId, this.state.requestData.tasksId)}  >Done</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <Button label="Reject" className="p-button-raised p-button-danger m-1 " icon="pi pi-times" name="Rejected" id="Rejected" value={updateRequest.requestId} onClick={() => this.handleSubmit("Rejected", updateRequest.requestId)} />
                            </div>
                        </div>
                        <div className="text-secondary font-italic mt-2">Comment : {updateRequest.taskStatus} </div>
                    </div>
                </div>
            </div>
        )
    }
    render() {
        return (
            <React.Fragment>
                {this.state.statusUpdateData.length ? this.state.statusUpdateData.map((updateRequest) => (this.createStatusUpdateRequestCard(updateRequest))) : <ProgressSpinner style={{ display: 'flex', height: '60vh' }} strokeWidth="3" animationDuration="1s" />}
            </React.Fragment>
        )
    }
}