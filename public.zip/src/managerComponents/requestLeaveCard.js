import React from 'react'
import Redirect from "react-router-dom/Redirect";
import { Button } from 'primereact/button';
import axios from "axios";
import { EOVERFLOW } from 'constants';
const url = 'http://localhost:2040/viewLeaveRequests';
const url1='http://localhost:2040/updateRequestStatus/';

export class RequestLeaveCard extends React.Component{
    constructor() {
        super();
        this.state = {
            
            errorMessage:"",
            successMessage:"",
            updateStatus: false,
            requestId:"",
            requestStatus:""
        };
       
    }

    handleSubmit=(requestStatus,requestId)=>{
       
        this.setState({updateStatus:true,requestId:requestId, requestStatus:requestStatus});
        this.updaterequestStatus(requestStatus,requestId)
    }
    updaterequestStatus=(requestStatus,requestId)=>{
        this.setState({ successMessage: "", errorMessage: "" })
        var form={requestStatus:""};
        form.requestStatus=requestStatus;
        axios.put(url1 + requestId, form)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" });
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }
render(){
    
  
    return(
        <div className="card m-1">
                <div className="card-body shadow bg-white rounded">
                    {/* {this.props.prod.name} */}
                    <div className="card-title">
                        <div className="row ">
                            <div className="col-md-12">
                                <span className="text-muted" >Leave request from : </span>
                                <span className="text-success" style={{ fontSize: "17px" }}>{this.props.leave.userName}</span>
                            </div>
                        </div>
                    </div>
                    <div className="card-text">
                        <div className="row">
                            <div className="col-md-7">
                                <div style={{ float: "left" }}>
                                    <span className="text-info m-1" style={{ display: "inline" }}>From : <strong>{new Date(this.props.leave.timeline.startDate).toLocaleDateString()}</strong></span>
                                    <span className="text-info m-1" style={{ display: "inline" }}>To : <strong>{new Date(this.props.leave.timeline.endDate).toLocaleDateString()}</strong></span>
                                </div><br />
                                <div className="text-danger mt-1 ml-3" >Total Days : {this.props.leave.NoOfDays}</div>
                            </div>
                            <div className="col-md-5 "  >
                                <Button label="Accept" className="p-button-raised p-button-success m-1 " icon="pi pi-check" name="Accepted" id="Accepted" value={this.props.leave.requestId} onClick={()=>this.handleSubmit("Accepted",this.props.leave.requestId)} />
                                <Button label="Reject" className="p-button-raised p-button-danger m-1 " icon="pi pi-times" name="Rejected" id="Rejected" value={this.props.leave.requestId} onClick={()=>this.handleSubmit("Rejected",this.props.leave.requestId)} />
                            </div>
                        </div>
                        <div className="text-secondary font-italic mt-2">Reason : {this.props.leave.requestReason}</div>
                    </div>
                    {this.state.successMessage}
                    {this.state.errorMessage}
                    
                </div>
            </div>
    )
}
}