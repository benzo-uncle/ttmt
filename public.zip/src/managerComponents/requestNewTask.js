import React from 'react';
import { Button } from 'primereact/button';
import axios from "axios";
import { MySpinner } from '../MySpinner'

const url = 'http://localhost:2040/viewNewTaskRequests';
const url1 = 'http://localhost:2040/updateRequestStatus/';
const url2 = 'http://localhost:2040/acceptNewTaskRequests/';
// tm name
//reason 
//taskname
export class RequestNewTask extends React.Component {
    constructor() {
        super();
        this.state = {
            count: 0,
            newTaskData: [],
            errorMessage: "",
            successMessage: "",
            updateStatus: false,
            requestId: "",
            requestStatus: "",
            requestData:{},
            comment:"",
            startDate:"",
            endDate:"",
            
            
        };
        this.increment = this.increment.bind(this);
    }
    increment() {
        this.setState((prevState, props) => ({
            count: prevState.count + 1
        }));
    }
    componentDidMount() {
        this.fetchnewTaskRequests();
    }

    


    fetchnewTaskRequests = () => {
        axios.get(url)
            .then(response => this.setState({ newTaskData: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, newTaskData: [] })
                } else {
                    this.setState({ errorMessage: error.message, newTaskData: [] })
                }
            })
    }
    handleSubmit = (requestStatus, requestId) => {
        this.setState({updateStatus:true,requestId:requestId, requestStatus:requestStatus});
        this.updaterequestStatus(requestStatus,requestId)

    }
    handleClick = (requestStatus, requestData) => {
        console.log(requestStatus, requestData);
        this.setState({requestData:requestData});

    }

    handleSubmitAccepted=(requestStatus,requestId,projectId,userId)=>{
        this.setState({updateStatus:true,requestId:requestId, requestStatus:requestStatus});
        this.acceptRequestStatus(requestStatus,requestId,projectId,userId);
    }
    acceptRequestStatus=(requestStatus,requestId,projectId,userId)=>{
        this.setState({ successMessage: "", errorMessage: "" })
        var empId=[];
        empId.push(this.state.requestData.userId);
        var form={
            tasksName:this.state.requestData.taskName,
            timeline: {
                startDate: this.state.startDate,
                endDate: this.state.endDate
            },
            comment:this.state.comment,
            empId:empId
        }
        console.log("form..",form);
        console.log(projectId,userId,requestId);
        axios.put(url2+projectId+"/"+userId+"/"+ requestId, form)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" });
            this.fetchnewTaskRequests();
            }).catch(error => {
                this.setState({errorMessage: error.response.data.message, successMessage: "" }); });
    }
    updaterequestStatus = (requestStatus, requestId) => {
        this.setState({ successMessage: "", errorMessage: "" })
        var form = { requestStatus: "" };
        form.requestStatus = requestStatus;
        axios.put(url1 + requestId, form)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" });
                this.fetchnewTaskRequests();
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }
    handleChange=(event)=>{
        const target = event.target;
        const value = target.value;
        const name = target.name;
        this.setState({ [name]: value });
    }
    createNewTaskCard = (data) => {
        return (
            <React.Fragment>
                <div className="card m-1">
                    <div className="card-body shadow bg-white rounded">
                        {/* {this.props.prod.name} */}
                        <div className="card-title">
                            <div className="row ">
                                <div className="col-md-12">
                                    <span className="text-muted" >Task request from : </span>
                                    <span className="text-success" style={{ fontSize: "17px" }}>{data.userName}</span>
                                </div>
                            </div>
                        </div>
                        <div className="card-text">
                            <div className="row">
                                <div className="col-md-7">
                                    <div>
                                        <span className="text-muted ml-2" style={{ fontSize: "14px" }}>Project Name : </span>
                                        <span style={{ fontSize: "17px" }}> {data.projectName}</span>
                                    </div>
                                    <div>
                                        <span className="text-muted ml-2" style={{ fontSize: "14px" }}>Task Name : </span>
                                        <span style={{ fontSize: "17px" }}> {data.taskName} </span>
                                    </div>
                                </div>
                                <div className="col-md-5"  >
                                    <Button label="Accept" className="p-button-raised p-button-success m-1 " icon="pi pi-check" name="Accepted" id="Accepted" value={data.requestId} data-toggle="modal" data-target="#newTaskForm" onClick={() => this.handleClick("Accepted", data)} />
                                    <Button label="Reject" className="p-button-raised p-button-danger m-1 " icon="pi pi-times" name="Rejected" id="Rejected" value={data.requestId} onClick={() => this.handleSubmit("Rejected", data.requestId)} />
                                </div>
                            </div>
                            <div className="text-secondary font-italic mt-2">Reason : {data.requestReason} </div>
                        </div>
                    </div>
                </div>
                <div className="modal fade" id="newTaskForm" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-centered" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title text-primary" id="exampleModalLabel">Assigning New Task on Request</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <form>

                                    <div className="form-group row">
                                        <div className="col-md-4">
                                            <label className="text-success col-form-label col-form-label-sm" for="pname"> <strong>Project Name:</strong> </label>
                                        </div>
                                        <div className="col-md-8">
                                            <input type="text" className="form-control form-control-sm" disabled onChange="" name="projectName" id="pname" value={this.state.requestData.projectName}></input>
                                            {/* <span className="text-danger">{this.state.projectFormError.projectName}</span> */}
                                        </div>
                                    </div>

                                    <div className="form-group row">
                                        <div className="col-md-4">
                                            <label className="text-success col-form-label col-form-label-sm" for="tname"> <strong>Task Name:</strong> </label>
                                        </div>
                                        <div className="col-md-8">
                                            <input type="text" className="form-control form-control-sm" disabled onChange="" name="taskName" id="tname" value={this.state.requestData.taskName}></input>
                                            {/* <span className="text-danger">{this.state.projectFormError.projectName}</span> */}
                                        </div>
                                    </div>

                                    <div className="form-group row mt-1">
                                        <div className="col-md-4">
                                            <label className="text-success col-form-label col-form-label-sm"  for="stask"><strong>Start Date:</strong></label>
                                        </div>
                                        <div className="col-md-8">
                                            <input type="date" className="form-control form-control-sm" value={this.state.startDate} name="startDate" onChange={this.handleChange} id="stask"></input>
                                            {/* <span className="text text-danger">{this.state.projectFormError.startDate}</span> */}
                                        </div>
                                    </div>
                                    <div className="form-group row mt-1">
                                        <div className="col-md-4">
                                            <label className="text-success col-form-label col-form-label-sm" for="etask"><strong>End Date:</strong></label>

                                        </div>
                                        <div className="col-md-8">
                                            <input type="date" className="form-control form-control-sm" value={this.state.endDate} name="endDate" onChange={this.handleChange} id="etask"></input>
                                            {/* <span className="text text-danger">{this.state.projectFormError.endDate}</span> */}
                                        </div> </div>

                                    <div className="form-group row mt-1">

                                        <div className="col-md-4">
                                            <label className="text-success col-form-label col-form-label-sm" for="taskdesc"><strong>Task Description:</strong></label>
                                        </div>
                                        <div className="col-md-8">
                                            <input type="text" className="form-control form-control-sm" id="taskdesc" placeholder="Enter Task Description" value={this.state.comment} name="comment" onChange={this.handleChange}></input>
                                        </div>
                                        {/* <span className="text text-danger">{this.state.projectFormError.projectDescription}</span> */}
                                    </div>

                                </form>
                            </div>
                            <div class="modal-footer">
                            <span className="text-success font-weight-bold message">
                                    {this.state.successMessage}
                                </span>
                                <span className="text-danger font-weight-bold message">
                                    {this.state.errorMessage}
                                </span>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary" onClick={()=>this.handleSubmitAccepted("Accepted",this.state.requestData.requestId,this.state.requestData.projectId,this.state.requestData.userId)} >Done</button>
                            </div>
                        </div>
                    </div>
                </div>

            </React.Fragment>

        )
    }
    render() {
        console.log("req id", this.state.requestData)
        return (
            <React.Fragment>
                {this.state.newTaskData.length ? this.state.newTaskData.map((data) => (this.createNewTaskCard(data))) : <MySpinner/>}


            </React.Fragment>
        )
    }
}