import React from 'react';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { MultiSelect } from 'primereact/multiselect';
import { Button } from '../../node_modules/primereact/button';
import Alert from './alert';
import axios from "axios";
import { connect } from 'react-redux'


const url = 'http://localhost:2040/viewAllEmployees';
const url1 = 'http://localhost:2040/createProject/';

class CreateTaskView extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            projectForm: {
                projectName: "",
                projectDescription: "",
                startDate: "",
                endDate: "",
            },
            taskForm: {
                taskName: "",
                taskDescription: "",
                taskStart: "",
                taskEnd: ""
            },

            projectFormError: {
                projectName: "",
                projectDescription: "",
                startDate: "",
                endDate: "",

            },

            taskFormError: {
                taskName: "",
                taskDescription: "",
                taskStart: "",
                taskEnd: ""
            },

            formValid: {
                projectName: false,
                projectDescription: false,
                startDate: false,
                endDate: false,
                taskName: false,
                taskDescription: false,
                taskStart: false,
                taskEnd: false,
                buttonActive: false
            },

            successMessage: "",
            errorMessage: "",
            alertStatus: false,
            membersArr: [],
            userId: this.props.loginDetails.userId
        }

        this.state.filterText = "";
        this.state.products = [
            {
                id: 1,
                taskStartDate: '',
                taskEndDate: '',
                taskName: '',
                description: '',
                name: '',
                members: []
            }


        ];


    }
    componentDidMount() {
        this.fetchAllEmployee();
    }

    messageAction = (message, messageType) => {
        var action = {
            type: "ALERT_MESSAGE",
            message: message,
            messageType: messageType
        }
        this.props.dispatch(action);
        this.setState({ messageStatus: false })
    }


    fetchAllEmployee = () => {
        axios.get(url)
            .then(response => this.setState({ membersArr: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, membersArr: [] })
                } else {
                    this.setState({ errorMessage: error.message, membersArr: [] })
                }
            })
    }



    handleChange = (event) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const { projectForm } = this.state;
        this.setState({
            projectForm: { ...projectForm, [name]: value }
        });
        this.validateField(name, value)
    }

    validateField = (fieldName, value) => {
        let projectError = this.state.projectFormError;
        let taskError = this.state.taskFormError;
        let formValid = this.state.formValid;


        switch (fieldName) {

            case "projectName":
                const projectNameRegEx = /^[A-z][A-z0-9 ][.]*[A-z0-9 ]+$/
                if (value === "") {
                    projectError.projectName = " Field required "
                    formValid.projectName = false;
                } else
                    if (!(value.match(projectNameRegEx))) {
                        projectError.projectName = "Please enter a valid project name"
                        formValid.projectName = false;
                    } else {
                        projectError.projectName = ""
                        formValid.projectName = true;
                    }
                break;

            case "projectDescription":
                if (value === "") {
                    projectError.projectDescription = " Field required "
                    formValid.projectDescription = false;
                } else {
                    projectError.projectDescription = ""
                    formValid.projectDescription = true;
                }
                break;

            case "startDate":
                if (value === "") {
                    projectError.startDate = " Field required "
                    formValid.startDate = false;
                } else
                    if (new Date(value).getDate() < new Date().getDate()) {
                        projectError.startDate = "Start date cannot be less than today's date."
                        formValid.startDate = false;
                    }
                    else {
                        projectError.startDate = ""
                        formValid.startDate = true;
                    }
                break;

            case "endDate":
                var startDate = this.state.projectForm.startDate
                if (value === "") {
                    projectError.endDate = " Field required "
                    formValid.endDate = false;
                } else
                    if (new Date(value).getDate() < new Date(startDate).getDate()) {
                        projectError.endDate = "End date cannot be less than start date."
                        formValid.endDate = false;
                    }
                    else {
                        projectError.endDate = ""
                        formValid.endDate = true;
                    }
                break;

            case "taskName":
                const taskNameRegEx = /^[A-z][A-z0-9][.]*[A-z0-9]+$/
                if (value === "") {
                    taskError.taskName = " Field required "
                    formValid.taskName = false;
                } else
                    if (!(value.match(taskNameRegEx))) {
                        taskError.taskName = "Please enter a valid task name"
                        formValid.taskName = false;
                    } else {
                        taskError.taskName = ""
                        formValid.taskName = true;
                    }
                break;

            case "taskDescription":
                if (value === "") {
                    taskError.taskDescription = " Field required "
                    formValid.taskDescription = false;
                } else {
                    taskError.taskDescription = ""
                    formValid.taskDescription = true;
                }
                break;

            case "taskStart":
                var startDate = this.state.projectForm.startDate
                if (value === "") {
                    taskError.taskStart = " Field required "
                    formValid.taskStart = false;
                } else
                    if ((new Date(value).getDate() < new Date().getDate()) && (new Date(value).getDate() < new Date(startDate).getDate())) {
                        taskError.taskStart = "Please enter a valid task start date."
                        formValid.taskStart = false;
                    }
                    else {
                        taskError.taskStart = ""
                        formValid.taskStart = true;
                    }
                break;

            case "taskEnd":
                var startDate = this.state.projectForm.startDate
                var taskStart = this.state.taskForm.taskStart
                var endDate = this.state.projectForm.endDate
                if (value === "") {

                    taskError.taskEnd = " Field required "
                    formValid.taskEnd = false;
                } else
                    if ((new Date(value).getDate() < new Date(taskStart).getDate()) && (new Date(value).getDate() > new Date(endDate).getDate())) {
                        taskError.taskEnd = " Please enter a valid task end date."
                        formValid.taskEnd = false;
                    }
                    else {
                        taskError.taskEnd = ""
                        formValid.taskEnd = true;
                    }
                break;

            default:
                break;

        }
        formValid.buttonActive = this.state.formValid.projectName && this.state.formValid.projectDescription && this.state.formValid.startDate && this.state.formValid.endDate && this.state.formValid.taskName && this.state.formValid.taskDescription && this.state.formValid.taskStart && this.state.formValid.taskEnd;
        this.setState({ projectFormError: projectError, taskFormError: taskError, formValid: formValid, successMessage: "" })
    }



    handleSubmit = event => {
        event.preventDefault();

        this.createProject();

    };

    createProject = () => {
        const tasks = this.state.products.map((task) => {
            return ({
                tasksName: task.taskName,
                empId: task.members,
                status: "Ongoing",
                comment: task.description,
                timeline: {
                    startDate: task.taskStartDate,
                    endDate: task.taskEndDate
                }
            }
            )

        })
        var empId = [];
        this.state.products.forEach((task) => {
            task.members.forEach((id) => {
                // if (empId.indexOf(id) === -1) {
                //     empId.push(id);
                // }
                empId.push(id);
            })
        })



        var form = {
            projectName: this.state.projectForm.projectName,
            description: this.state.projectForm.projectDescription,
            empId: empId,
            timeline: {
                startDate: this.state.projectForm.startDate,
                endDate: this.state.projectForm.endDate
            },
            tasks: tasks,



        }
        console.log("create project just before axios", form);

        this.setState({ successMessage: "", errorMessage: "" })
        axios.post(url1 + this.state.userId, form)
            .then(response => {
                this.messageAction(response.data.message, "success");
                this.setState({ alertStatus: true, successMessage: response.data.message, errorMessage: "" });

            }).catch(error => {
                this.messageAction(error.response.data.message, "danger");
                this.setState({ alertStatus: true, errorMessage: error.response.data.message, successMessage: "" });
            });



    }



    handleUserInput(filterText) {
        this.setState({ filterText: filterText });
    };

    handleRowDel(product) {
        var index = this.state.products.indexOf(product);
        this.state.products.splice(index, 1);
        this.setState(this.state.products);
    };

    handleAddEvent(evt) {
        var id = (+ new Date() + Math.floor(Math.random() * 999999)).toString(36);
        var product = {
            id: id,
            name: "",
            taskName: "",
            taskStartDate: "",
            taskEndDate: "",
            description: "",
            members: []
        }
        this.state.products.push(product);
        this.setState(this.state.products);
    }

    handleProductTable(evt) {
        var item = {
            id: evt.target.id,
            name: evt.target.name,
            value: evt.target.value
        };
        var products = this.state.products.slice();
        var newProducts = products.map(function (product) {

            for (var key in product) {
                if (key == item.name && product.id == item.id) {
                    product[key] = item.value;

                }
            }
            return product;
        });
        this.setState({ products: newProducts });
    };

    render() {
        return (
            <React.Fragment>
                {this.state.alertStatus ? <Alert /> : null}
                <form onSubmit={this.handleSubmit}>
                    <div className="card shadow bg-white rounded">
                        <div className="card-header">
                            <div className="row">
                                <div className="col-md-2">
                                    <label className="text-success col-form-label col-form-label-sm" for="pname"> <strong>Project Name :</strong> </label>
                                </div>
                                <div className="col-md-9">
                                    <input required type="text" className="form-control form-control-sm" value={this.state.projectForm.projectName} onChange={this.handleChange} name="projectName" id="pname" placeholder="Enter Project Name"></input>
                                    <span className="text-danger"><small>{this.state.projectFormError.projectName}</small></span>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-md-2">
                                    <label className="text-success col-form-label col-form-label-sm" for="sdate"><strong>Start Date :</strong></label>
                                </div>
                                <div className="col-md-3">
                                    <input required type="date" value={this.state.projectForm.startDate} onChange={this.handleChange} className="form-control form-control-sm" name="startDate" id="sdate"></input>
                                    <span className="text text-danger"><small>{this.state.projectFormError.startDate}</small></span>
                                </div>
                                <div className="col-md-2">
                                    <label className="text-success col-form-label col-form-label-sm float-right" for="edate"><strong>End Date :</strong></label>

                                </div>
                                <div className="col-md-3">
                                    <input required type="date" className="form-control form-control-sm" name="endDate" id="edate" value={this.state.projectForm.endDate} onChange={this.handleChange}></input>
                                    <span className="text text-danger"><small>{this.state.projectFormError.endDate}</small></span>
                                </div>

                            </div>

                            <div className="row">

                                <div className="col-md-2">
                                    <label className="text-info col-form-label col-form-label-sm" for="pdesc">Project Description :</label>
                                </div>
                                <div className="col-md-9">
                                    <input required type="text" className="form-control form-control-sm" name="projectDescription" id="pdesc" placeholder="Enter Project Description" value={this.state.projectForm.projectDescription} onChange={this.handleChange}></input>
                                </div>
                                <span className="text text-danger"><small>{this.state.projectFormError.projectDescription}</small></span>
                            </div>
                        </div>
                        <div className="card-body p-0 ml-1 mr-1">
                            <div className="row mt-1">
                                <div className="col-md-6">
                                    <i className="ml-3" style={{ fontSize: 15 }}>Add Team Members :</i>
                                </div>
                            </div>
                            <div className="mt-2">
                                <ProductTable members={this.state.membersArr} onProductTableUpdate={this.handleProductTable.bind(this)} onRowAdd={this.handleAddEvent.bind(this)} onRowDel={this.handleRowDel.bind(this)} products={this.state.products} filterText={this.state.filterText} />
                            </div>
                        </div>





                        {/* <span className="text-success font-weight-bold message">
                                                {this.state.successMessage}
                                            </span>
                                            <span className="text-danger font-weight-bold message">
                                                {this.state.errorMessage}
                                            </span> */}
                    </div>

                </form>
            </React.Fragment >
        )
    }
}




class ProductTable extends React.Component {
    constructor() {
        super();

    }
    render() {
        var members = this.props.members
        var onProductTableUpdate = this.props.onProductTableUpdate;
        var rowDel = this.props.onRowDel;
        var filterText = this.props.filterText;
        var product = this.props.products.map(function (product) {
            if (product.name.indexOf(filterText) === -1) {
                return;
            }
            return (<ProductRow members={members} onProductTableUpdate={onProductTableUpdate} product={product} onDelEvent={rowDel.bind(this)} key={product.id} />)
        });

        return (
            <div>
                <table className="table table-hover">
                    <thead className="text-center">
                        <tr >
                            <th scope="col" style={{ fontSize: 14 }}>Member Name</th>
                            <th scope="col" style={{ fontSize: 14 }}>Task Name</th>
                            <th scope="col" style={{ fontSize: 14 }}>Description</th>
                            <th scope="col" style={{ fontSize: 14 }}>Task Start Date</th>
                            <th scope="col" style={{ fontSize: 14 }}>Task End Date</th>
                            <th scope="col" style={{ fontSize: 14 }}>Remove</th>
                        </tr>
                    </thead>

                    <tbody>

                        {product}

                    </tbody>

                </table>

                <div className="row mb-3">
                    <div className="col-md-4">

                        <Button type="button" label="Add Task" icon="pi pi-plus" onClick={this.props.onRowAdd} className="ml-3 p-button-secondary p-button-raised shadow" />
                    </div>
                    <div className="col-md-4">
                        <center>
                            <Button type="submit" label="Create Project" icon="pi pi-bookmark" className="p-button p-button-success p-button-raised shadow mx-auto" />
                        </center>
                    </div>
                </div>
            </div>
        );

    }

}

class ProductRow extends React.Component {
    onDelEvent() {
        this.props.onDelEvent(this.props.product);

    }
    render() {
        console.log("mem2", this.props.members)
        var members = this.props.members


        return (
            <tr className="eachRow">
                <EditableMultiCell members={members} onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
                    type: "members",
                    value: this.props.product.members,
                    id: this.props.product.id
                }} />
                <EditableCell onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
                    type: "taskName",
                    value: this.props.product.taskName,
                    id: this.props.product.id
                }} />
                <EditableCell onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
                    type: "description",
                    value: this.props.product.description,
                    id: this.props.product.id
                }} />
                <EditableDate onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
                    type: "taskStartDate",
                    value: this.props.product.taskStartDate,
                    id: this.props.product.id
                }} />
                <EditableDate onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
                    type: "taskEndDate",
                    value: this.props.product.taskEndDate,
                    id: this.props.product.id
                }} />
                <td className="del-cell f-flex justify-content-center">
                    <Button icon="pi pi-times" onClick={this.onDelEvent.bind(this)} className="p-button-danger p-button-raised ml-2" />
                </td>
            </tr>
        );

    }

}


class EditableMultiCell extends React.Component {

    constructor() {
        super();
        this.state = {
            selectMembers: [],
            errorMessage: ""
        };

    }
    result(params) {
        console.log(params);
    }


    handleChangeForMulti = (e) => {
        this.setState({ selectMembers: e.value });

    }


    render() {
        const membersarr = this.props.members.map((member) => {
            return { label: member.userName, value: member.userId }
        })
        console.log("selectMembers", this.state.selectMembers);

        var string = '';
        this.state.selectMembers.forEach(element => {
            string = string + element + ',';
        });
        return (
            <td>

                <MultiSelect value={this.props.cellData.value} options={membersarr} onChange={this.props.onProductTableUpdate}
                    style={{ minWidth: '10em' }} filter={true} id={this.props.cellData.id} name={this.props.cellData.type} className="form-control form-control-sm" />

            </td>
        );

    }

}



class EditableCell extends React.Component {

    render() {

        return (
            <td>
                <input required type='text' className="form-control form-control-sm" name={this.props.cellData.type} id={this.props.cellData.id} value={this.props.cellData.value} onChange={this.props.onProductTableUpdate} />
            </td>
        );

    }

}

class EditableDate extends React.Component {

    render() {
        return (
            <td>
                <input required type='Date' className="form-control form-control-sm" name={this.props.cellData.type} id={this.props.cellData.id} value={this.props.cellData.value} onChange={this.props.onProductTableUpdate} />
            </td>
        );

    }

}

const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(CreateTaskView);