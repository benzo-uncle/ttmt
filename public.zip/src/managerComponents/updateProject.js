import React from 'react';
import axios from "axios";
import Alert from './alert';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

import { connect } from 'react-redux'

const url = 'http://localhost:2040/updateProject/';
const url1 = 'http://localhost:2040/deleteProject/';
const url2 = 'http://localhost:2040/viewAllEmployees';



class UpdateProjectComp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            updateForm: {
                projectNameUpdate: this.props.project.projectName,
                startDateUpdate: this.props.project.timeline.startDate.split("T")[0],
                endDateUpdate: this.props.project.timeline.endDate.split("T")[0],
                projectDescriptionUpdate: this.props.project.description
            },
            updateFormError: {
                projectNameUpdate: "",
                startDateUpdate: "",
                endDateUpdate: "",
                projectDescriptionUpdate: ""
            },
            updateFormValid: {
                projectNameUpdate: false,
                startDateUpdate: false,
                endDateUpdate: false,
                projectDescriptionUpdate: false,
                buttonActive: false,
            },
            successMessage: "",
            userId: this.props.loginDetails.userId,
            project: this.props.project,
            errorMessage: "",
            alertStatus:false
        }
    }

    handleSubmitUpdate = event => {
        event.preventDefault();
        this.updateProject();
    }
    handleSubmitDelete = event => {
        event.preventDefault();
        this.deleteProject();
    }

    messageAction = (message, messageType) => {
        var action = {
            type: "ALERT_MESSAGE",
            message: message,
            messageType: messageType
        }
        this.props.dispatch(action);
        this.setState({ messageStatus: false })
    }

    updateProject = () => {
        var form = {
            projectId: this.props.project.projectId,
            projectName: this.state.updateForm.projectNameUpdate,
            description: this.state.updateForm.projectDescriptionUpdate,
            timeline: {
                startDate: this.state.updateForm.startDateUpdate,
                endDate: this.state.updateForm.endDateUpdate
            }
        }
        this.setState({ successMessage: "", errorMessage: "" })
        axios.put(url + this.state.userId + "/" + this.props.project.projectId, form)
            .then(response => {
                this.messageAction(response.data.message, "success")
                this.setState({ alertStatus:true, successMessage: response.data.message, errorMessage: "" });
            }).catch(error => { 
                this.messageAction(error.response.data.message, "danger")
                this.setState({ alertStatus:true, errorMessage: error.response.data.message, successMessage: "" }); });
    }

    deleteProject = () => {
        this.setState({ successMessage: "", errorMessage: "" })
        axios.delete(url1 + this.props.project.projectId)
            .then(response => {
                this.messageAction(response.data.message, "warn")
                this.setState({ alertStatus:true, successMessage: response.data.message, errorMessage: "" });
            }).catch(error => { 
                this.messageAction(error.response.data.message, "danger")
                this.setState({ alertStatus:true,errorMessage: error.response.data.message, successMessage: "" }); });
    }
    handleChange = event => {
        var updateForm = this.state.updateForm
        if (event.target.name === "projectNameUpdate") {
            updateForm.projectNameUpdate = event.target.value
        } else
            if (event.target.name === "startDateUpdate") {
                updateForm.startDateUpdate = event.target.value
            } else
                if (event.target.name === "endDateUpdate") {
                    updateForm.endDateUpdate = event.target.value
                } else
                    if (event.target.name === "projectDescriptionUpdate") {
                        updateForm.projectDescriptionUpdate = event.target.value
                    }
        this.setState({ updateForm: updateForm });
        this.validateField(event.target.name, event.target.value);
    }

    validateField = (fieldName, value) => {
        var updateFormError = this.state.updateFormError
        var updateFormValid = this.state.updateFormValid
        switch (fieldName) {
            case "projectNameUpdate":
                const projectNameRegEx = /^[A-z][A-z0-9][.]*[A-z0-9 ]+$/
                if (value === "") {
                    updateFormError.projectNameUpdate = " Field required "
                    updateFormValid.projectNameUpdate = false;
                } else
                    if (!(value.match(projectNameRegEx))) {
                        updateFormError.projectNameUpdate = "Please enter a valid project name"
                        updateFormValid.projectNameUpdate = false;
                    } else {
                        updateFormError.projectNameUpdate = ""
                        updateFormValid.projectNameUpdate = true;
                    }
                break;

            case "startDateUpdate":
                if (value === "") {
                    updateFormError.startDateUpdate = " Field required "
                    updateFormValid.startDateUpdate = false;
                } else
                    if (new Date(value).getDate() < new Date().getDate()) {
                        updateFormError.startDateUpdate = "Start date cannot be less than today's date."
                        updateFormValid.startDateUpdate = false;
                    }
                    else {
                        updateFormError.startDateUpdate = ""
                        updateFormValid.startDateUpdate = true;
                    }
                break;

            case "endDateUpdate":
                var startDateUpdate = this.state.updateForm.startDateUpdate
                if (value === "") {
                    updateFormError.endDateUpdate = " Field required "
                    updateFormValid.endDateUpdate = false;
                } else
                    if (new Date(value).getDate() < new Date(startDateUpdate).getDate()) {
                        updateFormError.endDateUpdate = "End date cannot be less than start date."
                        updateFormValid.endDateUpdate = false;
                    }
                    else {
                        updateFormError.endDateUpdate = ""
                        updateFormValid.endDateUpdate = true;
                    }
                break;

            case "projectDescriptionUpdate":
                if (value === "") {
                    updateFormError.projectDescriptionUpdate = " Field required "
                    updateFormValid.projectDescriptionUpdate = false;
                } else {
                    updateFormError.projectDescriptionUpdate = ""
                    updateFormValid.projectDescriptionUpdate = true;
                }
                break;
            default:
                break;

        }
        updateFormValid.buttonActive = updateFormValid.projectNameUpdate || updateFormValid.startDateUpdate || updateFormValid.endDateUpdate || updateFormValid.projectDescriptionUpdate
        this.setState({ updateFormValid: updateFormValid, updateFormError: updateFormError, successMessage: "" })
    }
    render() {
        
        return (
            <React.Fragment>
                {this.state.alertStatus ? <Alert/>: null}
                <div className="card-body bg-light">
                    <form >
                        <div className="form-group row">
                            <div className="col-md-3">
                                <label className="text-success col-form-label col-form-label-sm" for="pnameupdate"> <strong>Project Name:</strong> </label>
                            </div>
                            <div className="col-md-9">
                                <input type="text" className="form-control form-control-sm" value={this.state.updateForm.projectNameUpdate} onChange={this.handleChange} name="projectNameUpdate" id="pnameupdate" placeholder="Enter Project Name"></input>
                                <span className="text-danger"><small>{this.state.updateFormError.projectNameUpdate}</small></span>
                            </div>
                        </div>


                        <div className="form-group row mt-1">
                            <div className="col-md-3">
                                <label className="text-success col-form-label col-form-label-sm" for="sdateupdate"><strong>Start Date:</strong></label>
                            </div>
                            <div className="col-md-3">
                                <input type="date" value={this.state.updateForm.startDateUpdate} onChange={this.handleChange} className="form-control form-control-sm " name="startDateUpdate" id="sdateupdate"></input>
                                <span className="text text-danger"><small>{this.state.updateFormError.startDateUpdate}</small></span>
                            </div>
                            <div className="col-md-3">
                                <label style={{ paddingRight: "-10px" }} className="text-success col-form-label col-form-label-sm float-right" for="edateupdate"><strong>End Date:</strong></label>

                            </div>
                            <div className="col-md-3">
                                <input type="date" className="form-control form-control-sm" name="endDateUpdate" id="edateupdate" value={this.state.updateForm.endDateUpdate} onChange={this.handleChange}></input>
                                <span className="text text-danger"><small>{this.state.updateFormError.endDateUpdate}</small></span>
                            </div>

                        </div>

                        <div className="form-group row mt-1">

                            <div className="col-md-3">
                                <label className="text-success col-form-label col-form-label-sm" for="pdescupdate"><strong>Project Description:</strong></label>
                            </div>
                            <div className="col-md-9">
                                <input type="text" className="form-control form-control-sm" name="projectDescriptionUpdate" id="pdescupdate" placeholder="Enter Project Description" value={this.state.updateForm.projectDescriptionUpdate} onChange={this.handleChange}></input>
                            </div>
                            <span className="text text-danger"><small>{this.state.updateFormError.projectDescriptionUpdate}</small></span>
                        </div>

                        <div className="form-group row ">
                            <div className="col-md-12 mt-2">


                                <button type="button" className="btn btn-sm btn-rounded btn-danger float-right "  data-toggle="modal" data-target="#deleteProjectConfirm"  >Delete Project</button>
                                <button disabled={!this.state.updateFormValid.buttonActive} className="btn btn-rounded btn-sm btn-success mr-2 float-right" onClick={this.handleSubmitUpdate}>Update Project</button>
                            </div>
                            {/* <div>
                                <span className="text text-success"><small>{this.state.successMessage}</small></span>
                                <span className="text text-danger"><small>{this.state.errorMessage}</small></span>

                            </div> */}
                        </div>
                    </form>
                </div>
                <div className="modal fade" id="deleteProjectConfirm" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-centered" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title text-info" id="exampleModalLabel"><strong>Confirm</strong></h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <div className="text text-primary"><strong>Are you sure you want to delete this project?</strong></div>
                            </div>
                            <div class="modal-footer">
                      
                              
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                                <button type="button" class="btn btn-primary" onClick={this.handleSubmitDelete} data-dismiss="modal">Yes</button>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        )
    }
}
const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(UpdateProjectComp);
