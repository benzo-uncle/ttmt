import React from 'react'
import Calendar from 'react-calendar'
import { Button } from 'primereact/button';
import { InputSwitch } from 'primereact/inputswitch';
import { MultiSelect } from 'primereact/multiselect';
import ReactTooltip from 'react-tooltip'
import Alert from './alert';
import axios from 'axios';

import { connect } from 'react-redux'
const url = 'http://localhost:2040/viewOngoingProjects/';
const url3 = 'http://localhost:2040/getProjectEmpNames/';
const url4 = 'http://localhost:2040/viewEventByEventId/';
const url2 = 'http://localhost:2040/viewEventByDate/';
const url1 = 'http://localhost:2040/createEvent/';
const url5 = 'http://localhost:2040/updateEvent/';
const url6 = 'http://localhost:2040/deleteEvent/';

class LeftPane extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            date: new Date(),
            checked: false,
            managerId: this.props.loginDetails.userId,
            members: [],
            projectsArr: [],
            membersArr: [],
            projectName: "",
            eventName: "",
            eventId: "",
            venue: "",
            time: "",
            reason: "",
            successMessage: "",
            successMessageCreateEvent: "",
            successMessageUpdateEvent: "",
            successMessageDeleteEvent: "",
            errorMessage: "",
            errorMessageCreateEvent: "",
            errorMessageUpdateEvent: "",
            errorMessageDeleteEvent: "",
            errorMessageNoEventOnThatDate: "",
            eventsArr: [],
            status: false,
            alertStatus: false,
            formValidation: {
                projectName: false,
                eventName: false,
                venue: false,
                time: false,
                buttonValid: false,
                members: false
            }
        };

    }

    formatDate(date) {
        var monthNames = [
            "January", "February", "March",
            "April", "May", "June", "July",
            "August", "September", "October",
            "November", "December"
        ];

        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();

        return day + ' ' + monthNames[monthIndex] + ' ' + year;
    }


    messageAction = (message, messageType) => {
        var action = {
            type: "ALERT_MESSAGE",
            message: message,
            messageType: messageType
        }
        this.props.dispatch(action);
        this.setState({ messageStatus: false })
    }

    createEvent = () => {
        var dateString = this.state.date.getMonth() + 1 + "-" + this.state.date.getDate() + "-" + this.state.date.getFullYear()
        var form = {
            eventName: this.state.eventName,
            createdBy: this.state.managerId,
            projectName: this.state.projectName,
            eventDate: dateString,
            time: this.state.time,
            venue: this.state.venue,
            reason: this.state.reason,
            members: this.state.members,

        }
        this.setState({ successMessageCreateEvent: "", errorMessageCreateEvent: "" })
        axios.post(url1 + this.state.managerId, form)
            .then(response => {
                this.messageAction(response.data.message, "success")
                this.setState({ alertStatus: true, errorMessage: [], eventId: "", eventName: "", projectName: "", time: "", venue: "", reason: "", members: [] });
            }).catch(error => {
                this.messageAction(error.response.data.message, "danger")
                this.setState({alertStatus:true, errorMessageCreateEvent: error.response.data.message, successMessage: "" });
            });
    }

    updateEvent = () => {
        var dateString = this.state.date.getMonth() + 1 + "-" + this.state.date.getDate() + "-" + this.state.date.getFullYear()
        var form = {
            eventId: this.state.eventId,
            eventName: this.state.eventName,
            createdBy: this.state.managerId,
            projectName: this.state.projectName,
            eventDate: dateString,
            time: this.state.time,
            venue: this.state.venue,
            reason: this.state.reason,
            members: this.state.members,

        }
        this.setState({ successMessageUpdateEvent: "", errorMessageUpdateEvent: "" })
        axios.put(url5 + this.state.managerId + "/" + this.state.eventId, form)
            .then(response => {
                this.messageAction(response.data.message, "warn")
                this.setState({ errorMessageUpdateEvent: "", eventId: "", eventName: "", projectName: "", time: "", venue: "", reason: "", members: [], alertStatus: true });
            }).catch(error => {
                this.messageAction(error.response.data.message, "danger")
                this.setState({ alertStatus: true, errorMessageUpdateEvent: error.response.data.message, successMessageUpdateEvent: "" });
            });
    }

    deleteEvent = () => {
        this.setState({ successMessageDeleteEvent: "", errorMessageDeleteEvent: "" })
        axios.delete(url6 + this.state.eventId)
            .then(response => {
                this.messageAction(response.data.message, "info")
                this.setState({ alertStatus: true, successMessageDeleteEvent: response.data.message, errorMessage: [], eventId: "", eventName: "", managerId: "", projectName: "", time: "", venue: "", reason: "", members: [] });
            }).catch(error => {
                this.messageAction(error.response.data.message, "danger")
                this.setState({ alertStatus: true, errorMessageDeleteEvent: error.response.data.message, successMessage: "" });
            });
    }

    handleSubmitForCreate = (event) => {
        event.preventDefault();
        this.createEvent();
    }
    handleSubmitforUpdate = (event) => {
        event.preventDefault();
        this.updateEvent();
    }
    handleSubmitforDelete = (event) => {
        event.preventDefault();
        this.deleteEvent();
    }
    componentDidMount() {
        this.fetchOngoingProjects();
        this.fetchEvents(this.state.date.toDateString());

    }

    fetchProjectMembers = () => {
        axios.get(url3 + this.state.projectName)
            .then(response => this.setState({ membersArr: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, membersArr: "" })
                } else {
                    this.setState({ errorMessage: error.message, membersArr: "" })
                }
            })
        this.setState({ status: true })

    }
    fetchOngoingProjects = () => {
        axios.get(url + this.state.managerId)
            .then(response => this.setState({ projectsArr: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, projectsArr: "" })
                } else {
                    this.setState({ errorMessage: error.message, projectsArr: "" })
                }
            })
    }
    fetchEvents = (eDate) => {
        axios.get(url2 + eDate + "/" + this.state.managerId)
            .then(response => this.setState({ eventsArr: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessageNoEventOnThatDate: error.response.data.message, eventsArr: "" })
                } else {
                    this.setState({ errorMessageNoEventOnThatDate: error.message, eventsArr: "" })
                }
            })
    }

    handleChange = (event) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        this.setState({ [name]: value });
        if (name === "projectName") {
            this.setState({ projectName: value, members: [], status: false, membersArr: [] })
        }
        this.validation(name, value);
    }

    validation = (fieldName, value) => {
        var formValid = this.state.formValidation;
        if (fieldName === "projectName") {
            if (value === "") {
                formValid.projectName = false;
            }
            else {
                formValid.projectName = true;
            }
        }
        if (fieldName === "eventName") {
            if (value === "") {
                formValid.eventName = false;
            }
            else {
                formValid.eventName = true;
            }
        }
        else if (fieldName === "venue") {
            if (value === "") {
                formValid.venue = false;
            }
            else {
                formValid.venue = true;
            }
        }
        else if (fieldName === "time") {
            if (value === "00:00") {
                formValid.time = false;
            }
            else {
                formValid.time = true;
            }
        }
        formValid.buttonValid = formValid.eventName && formValid.venue && formValid.time && formValid.projectName && formValid.members
        this.setState({ formValidation: formValid });

    }

    handleChangeEvent = (event) => {
        const target = event.target;
        const value = target.value;
        this.setState({ eventId: value });
        this.fetchEventbyEventId(value);

    }
    fetchEventbyEventId = (eventId) => {
        axios.get(url4 + eventId)
            .then(response => this.setState({ eventId: response.data.eventId, eventName: response.data.eventName, managerId: response.data.createdBy, projectName: response.data.projectName, time: response.data.time, venue: response.data.venue, reason: response.data.reason, members: response.data.members, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, eventId: "", eventName: "", managerId: "", projectName: "", time: "", venue: "", reason: "", members: [] })
                } else {
                    this.setState({ errorMessage: error.message, eventId: "", eventName: "", managerId: "", projectName: "", time: "", venue: "", reason: "", members: [] })
                }
            })
    }


    handleChangeMulti = (event) => {
        var selectedMembers = [];
        const target = event.target;
        const value = target.value;
        selectedMembers = value
        // console.log(selectedMembers)
        this.setState({ members: selectedMembers })

        if (selectedMembers.length === this.state.membersArr.length) {
            this.setState({ checked: true });
        }
        else {
            this.setState({ checked: false })
        }
        this.Multivalidation(selectedMembers);
    }

    Multivalidation = (members) => {
        var formValid = this.state.formValidation;
        if (members.length === 0) {
            formValid.members = false;
        }
        else {
            formValid.members = true;
        }
        formValid.buttonValid = formValid.projectName && formValid.eventName && formValid.time && formValid.venue && formValid.members
        this.setState({ formValidation: formValid })
    }

    handleChangeSwitch = () => {

        if (this.state.checked === false) {
            var members = this.state.membersArr.map((member) => member.userId)
            this.setState({ members: members, checked: true })
        } else {
            this.setState({ checked: false })
        }
    }

    switchDisabler = () => {
        if (this.state.membersArr.length > 0) {
            return false;
        } else {
            return true;
        }
    }


    onChange = date => {
        this.setState({ date })
        this.setState({ eventsArr: [] })
        this.fetchEvents(date.toDateString());
    }

    // notifier = () => {
    //     if (this.state.successMessageUpdateEvent.length > 0 && this.state.messageStatus) {

    //         var string = this.state.successMessageUpdateEvent;

    //         setTimeout(() => this.setState({ messageStatus: "" }), 7000)
    //         // this.setState({ successMessageUpdateEvent: "" })
    //         // this.setState({ messageStatus: "" })

    //         var notify = <Alert message={string} type={"info"} />
    //     }
    //     return notify
    // }

    render() {


        if (this.state.projectName !== "" && this.state.status === false) {
            this.fetchProjectMembers();
        }

        const membersarr = this.state.membersArr.map((member) => {
            return { label: member.userName, value: member.userId }
        })

        return (
            <div>

                {/* {this.notifier()} */}

                {this.state.alertStatus ? <Alert/>: null}
                {/* {this.state.successMessageUpdateEvent.length > 0 ? <Alert message={this.state.successMessageUpdateEvent} type={"info"} /> : null}

                {this.state.errorMessageUpdateEvent.length > 0 ? <Alert message={this.state.errorMessageUpdateEvent} type={"danger"} /> : null} */}



                <div className="row mt-2">
                    <div className="col-md-12">
                        <Calendar onChange={this.onChange} value={this.state.date} className="card shadow border-0 bg-white rounded " />
                    </div>
                </div>
                <div className="row mt-1">
                    <div className="col-md-12">
                        <div className="card mt-1 shadow bg-white rounded" style={{ height: "14em" }}>
                            <div className="card-header text-success d-flex justify-content-center" style={{ backgroundColor: "#FFFACD", fontSize: "1.15em" }}>
                                Events on date :  {this.formatDate(this.state.date)}
                            </div>
                            <div className="card-body" style={{ paddingLeft: "0.5em", paddingRight: ".5em", paddingBottom: "0em", paddingTop: "0.3em", overflowY: "auto", backgroundColor: "#ffffe6" }}>
                                <ul className="list-group list-group-flush">
                                    {this.state.eventsArr.length > 0 ?
                                        this.state.eventsArr.map(event =>
                                            <li className="list-group-item list-group-item-action" style={{ paddingLeft: "0.5em", paddingRight: ".5em", paddingBottom: "0.3em", paddingTop: "0em", backgroundColor: "#ffffe6" }}>
                                                <a data-tip={event.reason + "<br/>  Invited Members are: " + event.members}>
                                                    <div className="row">
                                                        <div className="col-md-11 m-0 text-capitalize " style={{ fontSize: "0.85em", color: "#829356" }}>{event.projectName}</div>
                                                    </div>
                                                    <div className="row" style={{ marginTop: "-0.3em" }}>
                                                        <div className="col-md-1"></div>
                                                        <div className="col-md-8 p-0 text-capitalize" style={{ fontSize: "1em", color: "#107896" }}>{event.eventName}</div>
                                                        <div className="col-md-2 p-0 text-right" style={{ fontSize: "0.75em", color: "#c02f1d" }}><strong>{event.time}</strong></div>
                                                    </div>
                                                    <div className="row" style={{ marginTop: "-0.2em" }}>
                                                        <div className="col-md-1"></div>
                                                        <div className="col-md-10 p-0" style={{ fontSize: "0.75em", color: "#c02f1d" }}>Venue : {event.venue}</div>

                                                    </div>
                                                </a> <ReactTooltip place="right" type="info" effect="float" className="w-25" html={true} />
                                            </li>)
                                        : null}

                                </ul>
                                {this.state.eventsArr.length > 0 ? null : <div className="text-center text-secondary" style={{ marginTop: "3.5em", backgroundColor: "#ffffe6" }}><h3>No Events to Display</h3></div>}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row mt-2">
                    <div className="col-md-6 d-flex justify-content-center">
                        <Button label="Create Event" className="p-button-raised p-button-success " icon="pi pi-calendar-plus" data-toggle="modal" data-target="#exampleModalCenter1" />
                    </div>
                    <div className="col-md-6 d-flex justify-content-center">
                        <Button label="Update Event" className="p-button-raised p-button-secondary" icon="pi pi-replay" data-toggle="modal" data-target="#exampleModalCenter2" />
                    </div>
                </div>





                <div className="modal fade" id="exampleModalCenter1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-centered modal-lg" role="document">
                        <div className="modal-content">
                            <div className="modal-header bg-light ">
                                <h5 className="modal-title text-success" id="exampleModalLongTitle">Create Event for {this.formatDate(this.state.date)}</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <form>
                                    <div className="row form-group">
                                        <label for="projectName" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Project Name :</strong></label>
                                        <select name="projectName" value={this.state.projectName} className="col-sm-4 form-control form-control-sm" id="projectName" onChange={this.handleChange} >
                                            <option value="" selected>--SELECT--</option>
                                            {this.state.projectsArr.length > 0 ?
                                                this.state.projectsArr.map(project => <option key={project.projectId} value={project.projectName}>{project.projectName}</option>)
                                                : null}
                                        </select>
                                        <label for="eventName" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Event Name :</strong></label>
                                        <input type='text' name="eventName" value={this.state.eventName} className="col-sm-3 form-control form-control-sm" id="eventName" placeholder="Enter Event Name" onChange={this.handleChange} />
                                    </div>
                                    <div className="row form-group">
                                        <label for="time" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Time : </strong></label>
                                        <input type="time" name="time" value={this.state.time} className="col-sm-2 form-control form-control-sm" id="time" onChange={this.handleChange} />
                                        <div className="col-sm-2"></div>
                                        <label for="venue" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Venue : </strong></label>
                                        <input type="text" name="venue" value={this.state.venue} className="col-sm-2 form-control form-control-sm" id="venue" onChange={this.handleChange} placeholder="Enter Venue" />
                                    </div>

                                    <div className="row form-group">
                                        <label for="reason" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Reason : </strong></label>
                                        <input type="text" name="reason" value={this.state.reason} className="col-sm-9 form-control form-control-sm" id="reason" onChange={this.handleChange} placeholder="Enter Reason" />

                                    </div>

                                    <div className="row form-group mb-0">
                                        <label for="members" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Select Members :</strong></label>
                                        <div>
                                            <MultiSelect options={membersarr} onChange={this.handleChangeMulti} value={this.state.members}
                                                style={{ minWidth: '10em' }} className="form-control form-control-sm" />
                                        </div>
                                        <div className="col-sm-2">
                                            <InputSwitch checked={this.state.checked} disabled={this.switchDisabler()} onChange={this.handleChangeSwitch} />
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div className="modal-footer">

                                <span className="text-success font-weight-bold message">
                                    {this.state.successMessage}
                                </span>
                                <span className="text-danger font-weight-bold message">
                                    {this.state.errorMessage}
                                </span>
                                <Button className="float-right" type="submit" name="submitButton" label="Save" className="close" data-dismiss="modal" icon="pi pi-save" disabled={!this.state.formValidation.buttonValid} onClick={this.handleSubmitForCreate} className="p-button p-button-success shadow" />
                            </div>
                        </div>
                    </div>
                </div>


                <div className="modal fade" id="exampleModalCenter2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-centered modal-lg" role="document">
                        <div className="modal-content">
                            <div className="modal-header ">
                                <h5 className="modal-title text-success" id="exampleModalLongTitle">Update Event for {this.formatDate(this.state.date)}</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <form>
                                    <div className="row form-group">
                                        <label for="eventName" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Event Name :</strong></label>
                                        <select name="eventName" value={this.state.eventId} className="col-sm-4 form-control form-control-sm" id="eventName" onChange={this.handleChangeEvent} >
                                            <option value="" selected>--SELECT--</option>
                                            {this.state.eventsArr.length > 0 ?
                                                this.state.eventsArr.map(event => <option key={event.eventId} value={event.eventId}>{event.eventName}</option>)
                                                : null}
                                        </select>
                                        <label for="projectName" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Project Name :</strong></label>
                                        <select name="projectName" value={this.state.projectName} className="col-sm-3 form-control form-control-sm" id="projectName" onChange={this.handleChange} >
                                            <option value="" selected>--SELECT--</option>
                                            {this.state.projectsArr.length > 0 ?
                                                this.state.projectsArr.map(project => <option key={project.projectId} value={project.projectName}>{project.projectName}</option>)
                                                : null}
                                        </select>
                                    </div>
                                    <div className="row form-group">
                                        <label for="time" className="col-sm-2 col-form-label col-form-label-sm text-info "><strong>Time : </strong></label>
                                        <input type="time" name="time" value={this.state.time} className="col-sm-2 form-control form-control-sm" id="time" onChange={this.handleChange} />
                                        <div className="col-sm-2"></div>
                                        <label for="venue" className="col-sm-2 col-form-label col-form-label-sm text-info "><strong>Venue : </strong></label>
                                        <input type="text" name="venue" value={this.state.venue} className="col-sm-2 form-control form-control-sm" id="venue" onChange={this.handleChange} />
                                    </div>

                                    <div className="row form-group">
                                        <label for="reason" className="col-sm-2 col-form-label col-form-label-sm text-info "><strong>Reason : </strong></label>
                                        <input type="text" name="reason" value={this.state.reason} className="col-sm-9 form-control form-control-sm" id="reason" onChange={this.handleChange} />

                                    </div>

                                    <div className="row form-group mb-0">
                                        <label for="members" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Select Members :</strong></label>
                                        <div>
                                            <MultiSelect options={membersarr} onChange={this.handleChangeMulti} value={this.state.members}
                                                style={{ minWidth: '10em' }} className="form-control form-control-sm" />
                                        </div>
                                        <div className="col-sm-2">
                                            <InputSwitch checked={this.state.checked} disabled={this.switchDisabler()} onChange={this.handleChangeSwitch} />
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div className="modal-footer">
                                <span className="text-success font-weight-bold message">
                                    {this.state.successMessage}
                                </span>
                                <span className="text-danger font-weight-bold message">
                                    {this.state.errorMessage}
                                </span>
                                <Button type="submit" name="submitButton" label="Save" icon="fa fa-pencil-square-o" className="close" data-dismiss="modal" onClick={this.handleSubmitforUpdate} className="p-button p-button-info shadow" />
                                <Button type="submit" name="submitButton" label="Delete" icon="fa fa-times" className="close" data-dismiss="modal" onClick={this.handleSubmitforDelete} className="p-button-danger shadow" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        loginDetails: state.loginDetails,
        leftPaneMessages: state.leftPaneMessages
    }
}

export default connect(mapStateToProps)(LeftPane);
