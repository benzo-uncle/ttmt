import React from "react";
import ReactExport from "react-data-export";
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { Button } from 'primereact/button';

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;






export class DownloadTaskReport extends React.Component{
    render(){
        return (
            <ExcelFile element={<Button icon="pi pi-download" className="p-button-raised  p-button-secondary" title="Download Report" />}>
                <ExcelSheet data={dataSet1} name="Employees">
                    <ExcelColumn label="Name" value="name"></ExcelColumn>
                    <ExcelColumn label="Wallet Money" value="amount"></ExcelColumn>
                    <ExcelColumn label="Gender" value="gender"></ExcelColumn>
                    <ExcelColumn label="Marital Status" value={(col)=> col.is_married?"Married":"Single"}></ExcelColumn>
                </ExcelSheet>
                <ExcelSheet data={dataSet2} name="Leaves">
                <ExcelColumn label="Name" value="name"></ExcelColumn>
                <ExcelColumn label="Total Leaves" value="total"></ExcelColumn>
                <ExcelColumn label="Remaining Leaves" value="remaining"></ExcelColumn>
                </ExcelSheet>
            
            </ExcelFile>
        )
    }
}