import React from 'react';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import {MySpinner} from '../MySpinner'
import Completedcard from './completedProjectCard';
import axios from "axios";
import {Calendar} from 'primereact/calendar';
import { ProgressSpinner } from 'primereact/progressspinner';
import { connect } from 'react-redux'

const url = 'http://localhost:2040/viewCompletedProjects/';

class Completed extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            btnLabelColor: "white",
            buttonLabel: "View Details",
            buttonStatus: false,
            btnColor: "forestgreen",
            projectData: [],
            projectDetailsData: {

                tasks: [],

            },
            projectData1: [],
            projectName: "",
            errorMessage: "",
            userId: this.props.loginDetails.userId,
            dates2:[]
        }
    }

    componentDidMount() {
        this.fetchCompletedProjects();
    }
    fetchCompletedProjects = () => {
        axios.get(url + this.state.userId)
            .then(response => this.setState({ projectData: response.data, projectData1: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, projectData: [] })
                } else {
                    this.setState({ errorMessage: error.message, projectData: [] })
                }
            })
    }

    handelChange=(event)=>{
        const target = event.target;
        const value = target.value;
        if(target.name==="searchCompletedProject"){
        this.setState({projectName:value})
    var  value1=value.toLowerCase()
        var Regex = new RegExp(value1);
var arr=[]

this.state.projectData.map((project)=>{
            
                if(project.projectName.toLowerCase().match(Regex)){
                    console.log("ander aaya bhai")
                arr.push(project)          
                    
                }
            
        })
        this.setState({projectData1:arr})
    }
    else{
        var date=new Date(value[0])
        this.setState({dates2:value})
        var startDate=new Date(value[0])
        var endDate=new Date(value[1])

        var arr=[]

    this.state.projectData.map((project)=>{
                
                    if(new Date(project.timeline.startDate)>=startDate && new Date(project.timeline.endDate)<=(endDate)){
                        console.log("ander aaya bhai")
                    arr.push(project)          
                        
                    }
                
            })
            this.setState({projectData1:arr})
        
        
    }}
    render() {
        return (
            <React.Fragment>
                <div className="row" style={{ marginBottom: "-0.5em", marginLeft: "-0.9em" }}>
                    <div className="col-sm-8 form-group ">
                        <input type="text" className="form-control form-control-sm" placeholder="Search for Completed Project" name="searchCompletedProject" value={this.state.projectName} onChange={this.handelChange} />
                    </div>
                    <div className="col-sm-4 form-group ">
                    <Calendar value={this.state.dates2} placeholder="Staring and End Date" onChange={this.handelChange} name="dates2" selectionMode="range" readonlyInput={true} />
                    </div>
                </div>
                {this.state.projectData1.length ? this.state.projectData1.map((data)=><Completedcard key={data.projectId} project={data}/>) :<MySpinner/>}

            </React.Fragment>
        )
    }
}

const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(Completed);
