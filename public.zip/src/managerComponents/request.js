import React, { Component } from 'react';
import { TabView, TabPanel } from 'primereact/tabview';
import { RequestLeave } from './requestLeave';
import { RequestExtension } from './requestExtension';
import { RequestNewTask } from './requestNewTask';
import { RequestStatusUpdate} from './RequestStatusUpdate';

export class Request extends Component {

    constructor() {
        super();
        this.state = {
            activeIndex: 3
        }
    }

    render() {
        return (
            <React.Fragment>
                {/* Controlled */}
                <div className="content-section implementation " style={{ marginTop: "-20px" }}>

                    <TabView activeIndex={this.state.activeIndex} onTabChange={(e) => this.setState({ activeIndex: e.index })}>
                        <TabPanel header="Leave Request" leftIcon="pi pi-user-minus">
                            <div style={{ height: "68vh", overflowY: "auto" }} ><RequestLeave /></div>

                        </TabPanel>
                        <TabPanel header="Task Time Extension" leftIcon="pi pi-calendar-plus">
                            <div style={{ height: "68vh", overflowY: "auto" }}><RequestExtension /></div>

                        </TabPanel>
                        <TabPanel header="New Task Request" leftIcon="pi pi-plus-circle" >
                            <div style={{ height: "68vh", overflowY: "auto" }}><RequestNewTask /></div>

                        </TabPanel>

                        <TabPanel header="Status Update Request" leftIcon="pi pi-check-circle" >
                            <div style={{ height: "68vh", overflowY: "auto" }}><RequestStatusUpdate /></div>

                        </TabPanel>
                    </TabView>
                </div>
            </React.Fragment>
        )
    }
}