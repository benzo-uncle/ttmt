import React, { Component } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { connect } from 'react-redux'


class Alert extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: this.props.leftPaneMessages.message,
      messageType: this.props.leftPaneMessages.messageType ,
      notify: null
    }
  }

  notifyFunction = () => {
    if (this.state.notify) {
      return (this.state.notify())
    }
  }

  componentDidMount = () => {

    var notify;
    switch (this.state.messageType) {

      case "success":
        notify = () => { toast.success(this.state.message) };
        this.setState({ notify: notify })
        break;

      case "danger":
        notify = () => { toast.error(this.state.message) };
        this.setState({ notify: notify })
        break;

      case "warn":
        notify = () => { toast.warn(this.state.message) };
        this.setState({ notify: notify })
        break;

      case "info":
        notify = () => { toast.info(this.state.message) };
        this.setState({ notify: notify })
        break;

      default:
        notify = null;
        break;
    }

  }

  render() {

    return (
      <div>
        <ToastContainer
          enableMultiContainer
          position={toast.POSITION.TOP_RIGHT}
        />

        {this.notifyFunction()}

      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {  leftPaneMessages: state.leftPaneMessages }
}

export default connect(mapStateToProps)(Alert);
