
import React from 'react';
import axios from "axios";
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import Alert from './alert';
import { connect } from 'react-redux';
import { MultiSelect } from 'primereact/multiselect';
const url = 'http://localhost:2040/viewAllEmployees';
const url1 = 'http://localhost:2040/addNewTask/';




class AddTaskComp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            form: {
                projectName: this.props.project.projectName,
                taskName: "",
                taskStart: "",
                taskEnd: "",
                taskDescription: "",
                members: [],

            },
            formError: {
                taskName: "",
                taskStart: "",
                taskEnd: "",
            },
            formValid: {
                taskName: "",
                taskStart: "",
                taskEnd: "",
                buttonActive: ""
            },
            checked: false,
            userId: this.props.loginDetails.userId,
            project: this.props.project,
            errorMessage: "",
            successMessage: "",
            membersArr: [],
            alertStatus:false
        }
    }

    messageAction = (message, messageType) => {
        var action = {
            type: "ALERT_MESSAGE",
            message: message,
            messageType: messageType
        }
        this.props.dispatch(action);
        this.setState({ messageStatus: false })
    }

    handleSubmit = event => {
        event.preventDefault();
        this.addNewTask();
    }
    addNewTask = () => {
        var form = {
            tasksName: this.state.form.taskName,
            comment: this.state.form.taskDescription,
            timeline: {
                startDate: this.state.form.taskStart,
                endDate: this.state.form.taskEnd
            },
            empId: this.state.form.members
        }
        this.setState({ successMessage: "", errorMessage: "" })
        axios.put(url1 + this.state.userId + "/" + this.props.project.projectId, form)
            .then(response => {
                this.messageAction(response.data.message, "success")
                this.setState({ alertStatus:true,successMessage: response.data.message, errorMessage: "" });
            }).catch(error => { 
                this.messageAction(error.response.data.message, "danger")
                this.setState({ alertStatus:true, errorMessage: error.response.data.message, successMessage: "" }); });
    }

    handleChange = event => {
        var form = this.state.form
        if (event.target.name === "taskName") {
            form.taskName = event.target.value
        } else
            if (event.target.name === "taskStart") {
                form.taskStart = event.target.value
            } else
                if (event.target.name === "taskEnd") {
                    form.taskEnd = event.target.value
                } else
                    if (event.target.name === "taskDescription") {
                        form.taskDescription = event.target.value
                    } else
                        if (event.target.name === "members") {
                            form.members = event.target.value
                        }

        this.setState({ form: form });
        this.validateField(event.target.name, event.target.value)

    }

    validateField = (fieldName, value) => {
        var formError = this.state.formError;
        var formValid = this.state.formValid;
        switch (fieldName) {
            case "taskName":
                if (value === "") {
                    formError.taskName = "Field Required"
                    formValid.taskName = false;
                } else {
                    formError.taskName = ""
                    formValid.taskName = true;
                }
            case "taskStart":
                if (value === "") {
                    formError.taskStart = "Field Required"
                    formValid.taskStart = false;
                } else {
                    formError.taskStart = ""
                    formValid.taskStart = true;
                }

            case "taskEnd":
                var taskStart = this.state.form.taskStart
                if (value === "") {
                    formError.taskEnd = "Field Required"
                    formValid.taskEnd = false;
                } else
                    if (new Date(value).getDate() < new Date(taskStart).getDate()) {
                        formError.taskEnd = "Task ending date cannot be before the starting date";
                        formValid.taskEnd = false;
                    }

                    else {
                        formError.taskEnd = ""
                        formValid.taskEnd = true;
                    }


        }
        formValid.buttonActive = formValid.taskName && formValid.taskStart && formValid.taskEnd
        this.setState({
            formValid: formValid,
            formError: formError,
            successMessage: ""
        })
    }
    handleChangeMulti = (event) => {
        var form = this.state.form
        var selectedMembers = [];
        const target = event.target;
        const value = target.value;
        selectedMembers = value
        form.members = selectedMembers;
        // console.log(selectedMembers)
        this.setState({ form: form })


    }
    componentDidMount() {
        this.fetchAllEmployee();
    }
    fetchAllEmployee = () => {
        axios.get(url)
            .then(response => this.setState({ membersArr: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, membersArr: [] })
                } else {
                    this.setState({ errorMessage: error.message, membersArr: [] })
                }
            })
    }

    render() {
        const membersarr = this.state.membersArr.map((member) => {
            return { label: member.userName, value: member.userId }
        })
        return (
            <React.Fragment>
                {this.state.alertStatus ? <Alert/>: null}
                <div className="card-body">
                    <form>
                        <div className="form-group row">
                            <div className="col-md-3">
                                <label className="text-success col-form-label col-form-label-sm" for="pname"> <strong>Project Name:</strong> </label>
                            </div>
                            <div className="col-md-9">
                                <input type="text" className="form-control form-control-sm" disabled value={this.state.form.projectName} onChange={this.handleChange} name="projectName" id="pname" placeholder="Enter Project Name"></input>

                            </div>
                        </div>
                        <div className="form-group row">
                            <div className="col-md-3 mt-1">
                                <label for="tname" className="text text-success col-form-label-sm"><strong>Task Name:</strong></label>
                            </div>
                            <div className="col-md-9 mt-1">
                                <input className="form-control form-control-sm" placeholder="Enter task name" name="taskName" id="tname" onChange={this.handleChange} value={this.state.form.taskName}></input>
                                <span className="text text-danger"><small>{this.state.formError.taskName}</small></span>
                            </div>
                        </div>
                        <div className="form-group row">
                            <div className="col-md-3">
                                <label className="text-success col-form-label col-form-label-sm" for="stask"><strong>Start Date:</strong></label>
                            </div>
                            <div className="col-md-3">
                                <input type="date" value={this.state.form.taskStart} onChange={this.handleChange} className="form-control form-control-sm" name="taskStart" id="stask"></input>
                                <span className="text text-danger"><small>{this.state.formError.taskStart}</small></span>
                            </div>
                            <div className="col-md-3">
                                <label className="text-success col-form-label col-form-label-sm float-right" for="etask"><strong>End Date:</strong></label>

                            </div>
                            <div className="col-md-3">
                                <input type="date" className="form-control form-control-sm" name="taskEnd" id="etask" value={this.state.form.taskEnd} onChange={this.handleChange}></input>
                                <span className="text text-danger"><small>{this.state.formError.taskEnd}</small></span>
                            </div>
                        </div>
                        <div className="form-group row">
                            <div className="col-md-3 mt-1">
                                <label for="tdesc" className="text text-success col-form-label col-form-label-sm"><strong>Task Description:</strong></label>
                            </div>
                            <div className="col-md-9 mt-1">
                                <input className="form-control form-control-sm" name="taskDescription" id="tdesc" placeholder="Enter Task Description" onChange={this.handleChange} value={this.state.form.taskDescription}></input>
                            </div>
                        </div>
                        <div className="form-group row">
                            <div className="col-md-3 mt-1">
                                <label className="text text-success col-form-label-sm" for="memb"><strong>Members:</strong></label>
                            </div>
                            <div className="col-md-9 mt-1">
                                <MultiSelect className="form-control form-control-sm" name="members" id="memb" options={membersarr} onChange={this.handleChangeMulti} value={this.state.form.members} ></MultiSelect>
                            </div>

                        </div>
                        <div className="form-group row">
                            <div className="col-md-12 mt-1">
                                <button className="btn btn-success btn-sm float-right" disabled={!this.state.formValid.buttonActive} onClick={this.handleSubmit}><strong>Add New Task</strong></button>
                            </div>
                        </div>
                    </form>
                </div>
            </React.Fragment>
        )
    }
}

const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(AddTaskComp);
