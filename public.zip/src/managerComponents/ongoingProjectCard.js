import React from 'react'
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import OngoingViewDetails from './ongoingViewDetails';
import axios from "axios";
import ReactToExcel from 'react-html-table-to-excel';
import { connect } from 'react-redux'
import { Button } from 'primereact/button';


const url1 = 'http://localhost:2040/viewOngoingProjectDetails/';
const url2 = 'http://localhost:2040/downloadReportByProject/'

class Ongoingcard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            buttonLabel: "View Details",
            btnStatus: false,
            projectDetailsData: {
                projectId: "",
                projectName: "",
                description: "",
                tasks: [],
                status: false,
            },
            downloadData:{
                projectName: "",
                description: "",
                timeline:{},
                tasks: [],
            },
            errorMessage: "",
            id: this.props.loginDetails.userId,

        }
    }
    handleClick = (event) => {
        if (this.state.buttonLabel === "View Details") {
            this.setState({ buttonLabel: "Close", btnStatus: true });
            this.fetchOngoingProjectDetails(event.target.value);
        }
        else {
            this.setState({ buttonLabel: "View Details", btnStatus: false });
        }
    }
    fetchOngoingProjectDetails = (projectId) => {
        axios.get(url1 + this.state.id + "/" + projectId)
            .then(response => {
                this.setState({ projectDetailsData: response.data, errorMessage: "" })
            })
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, projectDetailsData: {} })
                } else {
                    this.setState({ errorMessage: error.message, projectDetailsData: {} })
                }
            })
    }
   
    fetchDownloadReport=(projectId)=>{
        axios.get(url2 + projectId)
        .then(response => {
            this.setState({ downloadData: response.data, errorMessage: "" })
        })
        .catch(error => {
            if (error.status === 404) {
                this.setState({ errorMessage: error.response.data.message, downloadData: {} })
            } else {
                this.setState({ errorMessage: error.message, downloadData: {} })
            }
        })
    }
    // download=(projectId)=>{
    //     axios.get(url2+projectId)
    //     .then((response) => {
    //     //   var blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    //     //   fileSaver.saveAs(blob, 'fixi.xlsx');

    // //     var blob = new Blob([response.data.projectId+"\n"+response.data.projectName], {type: "text/plain;charset=utf-8"});
    // // fileSaver.saveAs(blob, "hello world.txt");

    //     //     var result = ["Item 1", "Item 3"];
    //     // const myJsonString = JSON.stringify(response.data);
    //     // console.log(response.data);
    //     // const blob = new Blob([response.data.projectId], {
    //     // type: "application/vnd.ms-excel;charset=utf-8"
    //     // });
    //     // fileSaver.saveAs(blob, "Report.xls");
    //     });
    // }
    render() {

        return (
            <React.Fragment>

                <div className="card shadow bg-white rounded mb-1">
                    <div className="card-header">
                        <div className="row ">
                            <div className="col-md-11">
                                <span className="text-muted" style={{ fontSize: "16px" }}>Project Name : </span>
                                <span className="blockquote" >{this.props.project.projectName}</span>
                            </div>
                            <div className="col-md-1">
                                {/* <DownloadProjectReport/><br /> */}
                                <Button icon="pi pi-download" tooltip="Download Project Report" className="p-button-secondary p-button-raised shadow" data-toggle="modal" data-target="#excelDownload" onClick={()=>this.fetchDownloadReport(this.props.project.projectId)} /><br />
                            </div>
                            <div className="modal fade" id="excelDownload" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div className="modal-dialog modal-lg modal-dialog-scrollable modal-dialog-centered"   role="document">
                                    <div className="modal-content">
                                        <div className="modal-header">
                                            <h5 className="modal-title" id="exampleModalLabel">Update Status</h5>
                                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div className="modal-body" >
                                            <div className="Table">
                                                <table id="table-to-xls">
                                                    <tr>
                                                        <th>Project Name</th>
                                                        <th />
                                                        <th>Project Description</th>
                                                        <th />
                                                        <th>Start Date</th>
                                                        <th />
                                                        <th>End Date</th>
                                                    </tr>
                                                    
                                                    <tr>
                                                        <td>{this.state.downloadData.projectName}</td>
                                                        <td />
                                                        <td>{this.state.downloadData.description}</td>
                                                        <td />
                                                        <td>{new Date(this.state.downloadData.timeline.startDate).toLocaleDateString()}</td>
                                                        <td />
                                                        <td>{new Date(this.state.downloadData.timeline.endDate).toLocaleDateString()}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Task Name</th>
                                                        <th />
                                                        <th>Task Description</th>
                                                        <th />
                                                        <th>Start Date</th>
                                                        <th />
                                                        <th>End Date</th>
                                                        <th />
                                                        <th colspan="5">Members</th>
                                                    </tr>
                                                    {this.state.downloadData.tasks.length?this.state.downloadData.tasks.map((task)=>{
                                                        return(
                                                            <tr>
                                                        <td>{task.tasksName}</td>
                                                        <td />
                                                        <td>{task.comment}</td>
                                                        <td />
                                                        <td>{new Date(task.timeline.startDate).toLocaleDateString()}</td>
                                                        <td />
                                                        <td>{new Date(task.timeline.endDate).toLocaleDateString()}</td>
                                                        <td />
                                                        {task.empName.length?task.empName.map((empName)=>{
                                                            return(
                                                                <td>{empName}</td>
                                                            )
                                                        }):null}
                                                       
                                                    </tr>
                                                        )
                                                    }):null}
                                                   
                                                    
                                                    
                                                    
                                                </table>
                                                <ReactToExcel
                                                    className="btn btn-success"
                                                    table="table-to-xls"
                                                    filename="excelfile"
                                                    sheet="sheet..1"
                                                    buttonText="Download"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-9">
                                <div style={{ float: "left" }}>
                                    <span className="text-info m-1" style={{ display: "inline" }}>Start Date : <strong>{new Date(this.props.project.timeline.startDate).toLocaleDateString()}</strong></span>
                                    <span className="text-info m-1" style={{ display: "inline" }}>End Date : <strong>{new Date(this.props.project.timeline.endDate).toLocaleDateString()}</strong></span>
                                </div>
                                <div style={{ float: "right" }}>
                                    <span className="text-danger mt-1 mr-4" >Days Remaining: {new Date(new Date(this.props.project.timeline.endDate) - new Date()).getDate()} </span>
                                </div>
                            </div>
                            <div className="col-md-3 d-flex justify-content-center">
                                <button className="btn btn-primary shadow" value={this.props.project.projectId} name={this.state.buttonLabel} id={this.state.buttonLabel} onClick={this.handleClick}>{this.state.buttonLabel}</button>
                            </div>
                        </div>
                        <div className="row mt-1">
                            <div className="col-md-2">
                                <div className="text-muted" style={{ fontSize: "16px" }}>Status : </div>
                            </div>
                            <div className="col-md-8" style={{ marginLeft: "-6.2em", marginTop: ".34em" }}>
                                <div className="progress">
                                    <div className="progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style={{ width: this.props.project.percentage + "%", color: "black" }}>{this.props.project.percentage}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {this.state.btnStatus ? <OngoingViewDetails key={this.props.project.projectId} projectDetailsData={this.state.projectDetailsData} /> : null}
                </div>
            </React.Fragment>
        )
    }
}

const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(Ongoingcard);