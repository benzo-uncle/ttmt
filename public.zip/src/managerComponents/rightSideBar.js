import React, { Component } from 'react';
import { Sidebar } from 'primereact/sidebar';
import { Button } from 'primereact/button';
import { InputText } from "primereact/inputtext";
import axios from "axios";
import ReactToExcel from 'react-html-table-to-excel';
import { connect } from 'react-redux'
import { Rating } from 'primereact/rating';

const url = 'http://localhost:2040/searchEmp/';
const url2= 'http://localhost:2040/downloadReportByUser/'
class SidebarRight extends Component {

    constructor() {
        super();
        this.state = {
            visibleLeft: false,
            errorMessage: "",
            searchData: [],
            downloadData:[]
        };
    }

    handleChange = (event) => {
        if (event.target.value === "") {
            setTimeout(() => { this.setState({ searchData: [] }); }, 2000)
        }
        else {
            this.searchEmp(event.target.value);
        }

    }
    searchEmp = (emp) => {
        axios.get(url + emp)
            .then(response => {
                console.log("response", response.data);
                this.setState({ searchData: response.data, errorMessage: "" })
            })
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, searchData: [] })
                } else {
                    this.setState({ errorMessage: error.message, searchData: [] })
                }
            })
    }
    fetchDownloadReport=(userId)=>{
        axios.get(url2 + userId)
        .then(response => {
            this.setState({ downloadData: response.data, errorMessage: "" })
        })
        .catch(error => {
            if (error.status === 404) {
                this.setState({ errorMessage: error.response.data.message, downloadData: [] })
            } else {
                this.setState({ errorMessage: error.message, downloadData: [] })
            }
        })
    }
    render() {
        return (
            <div>


                <Sidebar className="sidebar bg-dark" visible={this.state.visibleRight} position="right" baseZIndex={10} onHide={(e) => this.setState({ visibleRight: false })}>

                    <div className="row mt-n1 ml-2">
                        <h4>Employee Directory</h4>

                    </div>

                    <div className="row">
                        <div className="col-md-12 d-flex justify-content-center mt-2">
                            <InputText placeholder="Employee Name" onChange={this.handleChange} style={{ width: "90%" }} />
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-md-12" style={{ overflowY: "auto", maxHeight: "87vh" }}>


                            {this.state.searchData.length ? this.state.searchData.map((data) => {
                                return (
                                    <div className="row mb-3 mt-3">
                                        <div className="col-md-12">
                                            <div className="card shadow border border-success" style={{ border: "0", paddingTop: "0.45em" }}>
                                                <div className="card-body p-0">

                                                    <div className="row">
                                                        <div className="col-md-7 text-capitalize " style={{ fontSize: "1.2em", color: "#097054", marginLeft: "0.50em" }}>{data.userName}</div>
                                                        <div className="col-md-4 form-inline" style={{ fontSize: "0.68em", color: "#c02f1d", marginLeft: "1.5em" }}>
                                                            ({data.rating}/5)<Rating value={data.rating} cancel={false} stars={1} />
                                                        </div>
                                                    </div>
                                                    <div className="row">
                                                        {data.availability === "Available" ?
                                                            <div className="col-md-8 text-capitalize text-success" style={{ fontSize: "0.90em", color: "#097054", marginLeft: "1em" }}>{data.availability}</div>
                                                            : data.availability === "Assigned" ?
                                                                <div className="col-md-8 text-capitalize text-info" style={{ fontSize: "0.90em", color: "#097054", marginLeft: "1em" }}>{data.availability}</div> :
                                                                <div className="col-md-8 text-capitalize text-danger" style={{ fontSize: "0.90em", color: "#097054", marginLeft: "1em" }}>{data.availability}</div>}


                                                    </div>
                                                    {data.projects.length ? data.projects.map((project) => {
                                                        return (
                                                            <div className="row" style={{ marginTop: "0.2em" }}>

                                                                <div className="col-md-7 text-capitalize " style={{ fontSize: "0.90em", color: "#1a75ff", marginLeft: "0.85em" }}>{project.projectName}</div>
                                                                <div className="col-md-4 " style={{ fontSize: "0.68em", color: "#c02f1d" }}><strong>{project.status}</strong></div>
                                                            </div>
                                                        )
                                                    }) : null}

                                                    <div className="row" style={{ marginTop: "0.5em", marginBottom: "0.4em" }}>

                                                        <div className="col-md-12 d-flex justify-content-center">
                                                            <Button icon="pi pi-download" tooltip="Download Employee Report" data-toggle="modal" data-target="#userReport" className="p-button-secondary p-button-raised shadow " style={{ width: "8em", height: "1.4em" }} onClick={()=>this.fetchDownloadReport(data.userId)}/>
                                                        </div>
                                                        <div className="modal fade" id="userReport" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                            <div className="modal-dialog modal-lg modal-dialog-scrollable modal-dialog-centered" role="document">
                                                                <div className="modal-content">
                                                                    <div className="modal-header">
                                                                        <h5 className="modal-title" id="exampleModalLabel">Update Status</h5>
                                                                        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div className="modal-body" >
                                                                        <div className="Table">
                                                                            <table id="table-to-xls">
                                                                                <tr>
                                                                                    <th>Task Name</th>
                                                                                    <th />
                                                                                    <th>Task Description</th>
                                                                                    <th />
                                                                                    <th>Start Date</th>
                                                                                    <th />
                                                                                    <th>End Date</th>
                                                                                    <th/>
                                                                                    <th>Task Status</th>
                                                                                    <th/>
                                                                                    <th>Members</th>
                                                                                    <th/>
                                                                                    <th>Project Name</th>
                                                                                    <th />
                                                                                    <th>Project Description</th>
                                                                                    <th />
                                                                                </tr>
                                                                                {this.state.downloadData.length?this.state.downloadData.map((task)=>{
                                                                                    return(
                                                                                        <tr>
                                                                                    <td>{task.tasksName}</td>
                                                                                    <td/>
                                                                                    <td>{task.comment}</td>
                                                                                    <td/>
                                                                                    <td>{new Date(task.timeline.startDate).toLocaleDateString()}</td>
                                                                                    <td/>
                                                                                    <td>{new Date(task.timeline.endDate).toLocaleDateString()}</td>
                                                                                    <td/>
                                                                                    <td>{task.status}</td>
                                                                                    <td/>
                                                                                    
                                                                                    <td>{task.empNames.length?task.empNames.map((empName)=>{
                                                                                        return(
                                                                                            <span>{empName +", "}</span>
                                                                                        )
                                                                                    }):null}</td>
                                                                                    <td/>
                                                                                    <td>{task.projectName}</td>
                                                                                    <td/>
                                                                                    <td>{task.description}</td>
                                                                                </tr>
                                                                                    )
                                                                                }):null}
                                                                                
                                                                            </table>
                                                                            <ReactToExcel
                                                                                className="btn btn-success"
                                                                                table="table-to-xls"
                                                                                filename="excelfile"
                                                                                sheet="sheet..1"
                                                                                buttonText="Download"
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )
                            }) : null}



                        </div>
                    </div>


                </Sidebar>

                <Button className="p-button-secondary shadow p-button-raised" tooltip="Search For Employee" icon="fa fa-address-book-o" onClick={(e) => this.setState({ visibleRight: true })} />




            </div>
        )
    }
}

export default connect()(SidebarRight)