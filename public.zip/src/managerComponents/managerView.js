import React from 'react';
import { BrowserRouter, Link, Route, Switch, Redirect } from 'react-router-dom';
import { Request } from './request';
import { Button } from 'primereact/button';
import 'font-awesome/css/font-awesome.min.css';
import Ongoing from './ongoing';
import CreateTaskView from './CreateTaskView';
import Update from './updateTask';
import Completed from './completed';
import SidebarRight from './rightSideBar';
import LeftPane from './leftPane';
import { connect } from 'react-redux'

class ManagerView extends React.Component {


  handleClick = () => {
    var header = document.getElementById("navs");
    var nav = header.getElementsByClassName("nav-link");
    for (var i = 0; i < nav.length; i++) {
      nav[i].addEventListener("click", function () {
        var current = document.getElementsByClassName("active");

        // If there's no active class
        if (current.length > 0) {
          current[0].className = current[0].className.replace(" active", "");
        }

        // Add the active class to the current/clicked button
        this.className += " active";
      });
    }

  }

  greet = () => {
    var greeting;
    var time = new Date().getHours();
    if (time >= 17 && time <= 23) {
      greeting = "Good Evening,";
    } else if (time >= 12 && time < 17) {
      greeting = "Good Afternoon,";
    } else if (time >= 0 && time < 12) {
      greeting = "Good Morning,";
    }
    return greeting
  }


  logoutAction = () => {
    var action = {
      type: "LOGOUT",

    }
    this.props.dispatch(action);
  }

  render() {
    return (
      <React.Fragment>
        <BrowserRouter>
          <nav className="navbar navbar-expand-lg navbar-dark bg-info">
            <Link to={'/'} className="navbar-brand" >Team Task Management</Link>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse " id="navbarNav">
              <ul className="navbar-nav ml-auto">

                <li className="nav-item mt-1 mr-4 text-white">
                  {this.greet()} {this.props.loginDetails.userName}
                </li>

                <li className="nav-item mr-1">
                  <SidebarRight />
                </li>
                <li className="nav-item">

                  <a href={"/login/"}><Button label="Logout" icon="pi pi-power-off" className="p-button-warning" onClick={() => this.logoutAction} style={{ marginLeft: 4 }} /></a>
                </li>

              </ul>
            </div>
          </nav>

          <div className='container-fluid'>
            <div className='row mt-1' >

              <div className="col-md-3" >
                <LeftPane />
              </div>


              <div className="col-md-9" style={{ marginTop: "2px" }}>


                <div className="row">
                  <div className="col-md-12">
                    <div className="card shadow bg-white rounded" style={{ marginLeft: "-12px", marginRight: "-8px"}}>
                      <div className="card-header" >
                        <ul className="nav nav-tabs card-header-tabs" id="navs">
                          <li className="nav-item col text-center">
                            <Link to={'/ongoing'} className="nav-link " onClick={this.handleClick} style={{color:"black"}}><i className="fa fa-history" aria-hidden="true"></i><strong>&nbsp;On-Going</strong></Link>

                          </li>
                          <li className="nav-item col  text-center">
                            <Link to={'/createtask'} className="nav-link" onClick={this.handleClick} style={{color:"black"}}><i class="fa fa-pencil" aria-hidden="true"></i><strong>&nbsp;Create Project</strong></Link>
                          </li>
                          <li className="nav-item col text-center">
                            <Link to={'/updatelink'} className="nav-link" onClick={this.handleClick} style={{color:"black"}}><i className="fa fa-pencil-square-o" aria-hidden="true"></i><strong>&nbsp;Update Project</strong></Link>
                          </li>
                          <li className="nav-item col  text-center">
                            <Link to={'/request'} className="nav-link" onClick={this.handleClick} style={{color:"black"}}><i class="fa fa-users" aria-hidden="true"></i><strong>&nbsp;Requests</strong></Link>
                          </li>
                          <li className="nav-item col text-center">
                            <Link to={'/completed'} className="nav-link" onClick={this.handleClick} style={{color:"black"}}><i class="fa fa-check-circle" aria-hidden="true"></i><strong>&nbsp;Completed</strong></Link>
                          </li>
                        </ul>
                      </div>

                      <div class="card-body" style={{ overflowY: "auto", height: "81vh" }}>
                        <Switch>
                          <Route exact path="/managerView" render={() => (
                            <Redirect to={{
                              pathname: '/ongoing',
                            }}
                            />
                          )} />
                          <Route exact path="/ongoing" component={Ongoing} />
                          <Route path="/createtask" component={CreateTaskView} />
                          <Route path="/updatelink" component={Update} />
                          <Route exact path="/request" component={Request} />
                          <Route path="/completed" component={Completed} />
                        </Switch>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </BrowserRouter>
      </React.Fragment >
    )
  }
}

const mapStateToProps = (state) => {
  return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(ManagerView);
