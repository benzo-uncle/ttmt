import React from 'react';
import axios from "axios";
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import Alert from './alert';
import { MultiSelect } from 'primereact/multiselect';
import { connect } from 'react-redux'

const url = 'http://localhost:2040/getTaskByTaskId/';
const url1 = 'http://localhost:2040/viewAllEmployees';
const url2 = 'http://localhost:2040/updateTask/';
const url3 = 'http://localhost:2040/deleteTask/';
class UpdateTaskComp extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            form: {
                projectName: this.props.project.projectName,
                taskName: "",
                changedTaskName: "",
                taskStart: "",
                taskEnd: "",
                taskDescription: "",
                members: [],
                
            },
            formError: {
                taskName:"",
                changedTaskName: "",
                taskStart: "",
                taskEnd: "",
                taskDescription: "",
                members: []

            },
            formValid: {
                
                taskStart: false,
                taskEnd: false,
                buttonActive: false
            },
            products: [
                {
                    id: 1,
                    name: '',
                    members: [],
                    membersLength:""
                }],
            membersArr:[],
            userId:this.props.loginDetails.userId,
            project:this.props.project,
            errorMessage:"",
            successMessage:"",
            task:{},
            alertStatus:false
        }
    }
   
    messageAction = (message, messageType) => {
        var action = {
            type: "ALERT_MESSAGE",
            message: message,
            messageType: messageType
        }
        this.props.dispatch(action);
        this.setState({ messageStatus: false })
    }

    handleSubmitUpdate = event => {
        event.preventDefault();
        this.updateTask();
    }
    handleSubmitDelete = event => {
        event.preventDefault();
        this.deleteTask();
    }
    updateTask=()=>{
        var form={
            tasksId:this.state.task.tasks[0].tasksId,
            tasksName:this.state.form.changedTaskName,
            comment:this.state.form.taskDescription,
            timeline:{
                startDate:this.state.form.taskStart,
                endDate:this.state.form.taskEnd
            },
            empId:this.state.form.members
        }
        this.setState({ successMessage: "", errorMessage: "" })
        axios.put(url2 + this.state.userId + "/" + this.props.project.projectId, form)
            .then(response => {
                this.messageAction(response.data.message, "success")
                this.setState({ alertStatus:true,successMessage: response.data.message, errorMessage: "" });
            }).catch(error => { 
                    this.messageAction(error.response.data.message, "danger")
                    this.setState({ alertStatus:true,errorMessage: error.response.data.message, successMessage: "" }); });
    }
    deleteTask=()=>{
        this.setState({ successMessage: "", errorMessage: "" })
        axios.delete(url3 + this.props.project.projectId+"/"+this.state.task.tasks[0].tasksId)
            .then(response => {
                this.messageAction(response.data.message, "warn")
                this.setState({ alertStatus:true,successMessage: response.data.message, errorMessage: "" });
            }).catch(error => { 
                this.messageAction(error.response.data.message, "danger")
                this.setState({ alertStatus:true, errorMessage: error.response.data.message, successMessage: "" }); });
    }
    fetchTaskByTaskId=(tasksId)=>{
        console.log("inside fetch");
        var form = this.state.form
        axios.get(url+this.props.project.projectId+"/"+tasksId)
        .then(response => {
            console.log("response",response.data.tasks);
            form.changedTaskName=response.data.tasks[0].tasksName;
            form.taskDescription=response.data.tasks[0].comment;
            form.taskStart=response.data.tasks[0].timeline.startDate.split("T")[0];
            form.taskEnd=response.data.tasks[0].timeline.endDate.split("T")[0];
            form.members=response.data.tasks[0].empId;
            this.setState({ task: response.data,form:form, errorMessage: "" })
        })
        .catch(error => {
            if (error.status === 404) {
                this.setState({ errorMessage: error.response.data.message, task: {} })
            } else {
                this.setState({ errorMessage: error.message, task: {} })
            }
        })
    }
    handleChange=event=>{
        var form = this.state.form
        if (event.target.name === "taskName"){
            form.taskName = event.target.value;
            this.fetchTaskByTaskId(event.target.value);
        } else
            if (event.target.name === "changedTaskName"){
                form.changedTaskName = event.target.value
            } else
                if (event.target.name === "taskStart"){
                    form.taskStart = event.target.value
                } else
                    if (event.target.name ==="taskEnd"){
                        form.taskEnd = event.target.value
                    } else  
                        if (event.target.name === "taskDescription"){
                            form.taskDescription = event.target.value
                        } else
                            if (event.target.name === "members"){
                                form.members = event.target.value
                            }
    
                this.setState({form:form});
                this.validateField(event.target.name, event.target.value)
    
}
handleChangeMulti = (event) => {
    var form = this.state.form
    var selectedMembers = [];
    const target = event.target;
    const value = target.value;
    selectedMembers = value
    form.members=selectedMembers;
    // console.log(selectedMembers)
    this.setState({ form: form })

   
}
    validateField=(fieldName,value)=>{
        var formError = this.state.formError;
        var formValid = this.state.formValid;
        switch (fieldName){
            
            case "taskStart":
                if (value === "") {
                    formError.taskStart = "Field Required"
                    formValid.taskStart = false;
                } else {
                    formError.taskStart = ""
                    formValid.taskStart = true;
                }

            case "taskEnd":
            var taskStart = this.state.form.taskStart
                if (value === "") {
                    formError.taskEnd = "Field Required"
                    formValid.taskEnd = false;
                } else 
                    if (new Date(value).getDate()< new Date(taskStart).getDate()){
                        formError.taskEnd ="Task ending date cannot be before the starting date";
                        formValid.taskEnd = false;
                    }
                
                else {
                    formError.taskEnd = ""
                    formValid.taskEnd = true;
                }

            
        }
        formValid.buttonActive= formValid.taskStart || formValid.taskEnd
        this.setState({
            formValid : formValid,
            formError : formError,
            successMessage:""
        })
    }



    componentDidMount() {
        this.fetchAllEmployee();
    }
    fetchAllEmployee = () => {
        axios.get(url1)
            .then(response => this.setState({ membersArr: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, membersArr: [] })
                } else {
                    this.setState({ errorMessage: error.message, membersArr: [] })
                }
            })
    } 
             
    handleChangeSelect = event => {

        var form = this.state.form
        var prod= this.state.products
        form.members = ["Ayushi", "Khushali", "Rahul"];
        form.newMembers=form.members+prod.members;
        // form.lengthMembers=form.members.length();
        this.setState({
            form: form
        })
        console.log(form.newMembers);
        
    }

    handleMemberChange = (event) => {
        var form = this.state.form
        if (event.target.name === "newMember") {
            form.newMember = event.target.value
            form.newMembers.push(form.newMember);
        }
        this.setState({ form: form });
    }

    handleRowDel(product) {
        var index = this.state.products.indexOf(product);
        this.state.products.splice(index, 1);
        this.setState(this.state.products);
    };

    handleAddEvent(evt) {
        evt.preventDefault();
        var length=Number(this.state.form.newMembers.length)
        var id = (+ new Date() + Math.floor(Math.random() * 999999)).toString(36);
        var product = {
            id: id,
            name: "",
            members: [],
            membersLength:length
        }
        this.state.products.push(product);
        this.setState(this.state.products);
        console.log(this.state.products);
        
    }

    handleProductTable(evt) {
        var item = {
            id: evt.target.id,
            name: evt.target.name,
            value: evt.target.value
        };
        var products = this.state.products.slice();
        var newProducts = products.map(function (product) {

            for (var key in product) {
                if (key == item.name && product.id == item.id) {
                    product[key] = item.value;

                }
            }
            return product;
        });
        this.setState({ products: newProducts });
     
    };

    render() {
        console.log("form",this.state.form)
        const membersarr = this.state.membersArr.map((member) => {
            return { label: member.userName, value: member.userId }
        })
        return (
            <React.Fragment>
                   {this.state.alertStatus ? <Alert/>: null}
                <div className="card-body">
                    <form onSubmit={this.handleSubmit}>
                        <div className="form-group row">
                            <div className="col-md-3">
                                <label className="text-success col-form-label col-form-label-sm" for="pname"> <strong>Project Name:</strong> </label>
                            </div>
                            <div className="col-md-9">
                                <input type="text" className="form-control form-control-sm" disabled value={this.state.form.projectName} onChange={this.handleChange} name="projectName" id="pname" placeholder="Enter Project Name"></input>
                               
                            </div>
                        </div>
                        <div className="form-group row">
                            <div className="col-md-3">
                                <label className="text-success col-form-label col-form-label-sm" for="tname"> <strong>Task Name:</strong> </label>
                            </div>
                            <div className="col-md-9">
                                <select id="tname" name="taskName" onChange={this.handleChange} className="form-control form-control-sm ">
                                    <option value="" disabled selected>--Choose a Task--</option>
                                    {this.state.project.tasks.length > 0 ?
                                                this.state.project.tasks.map(task => <option key={task.tasksId} value={task.tasksId}>{task.tasksName}</option>)
                                                : null}
                                </select>
                            
                            </div>
                        </div>
                        <div className="form-group row mt-1">
                        <div className="col-md-3">
                        <label className="text-success col-form-label col-form-label-sm" for="changetname"><strong>Change Task Name:</strong></label>
                        </div>
                        <div className="col-md-9">
                        <input className="form-control form-control-sm" name="changedTaskName" placeholder="Enter the changed task name" value={this.state.form.changedTaskName} onChange={this.handleChange}></input>
                        </div>
                        </div>

                        <div className="form-group row mt-1">

                            <div className="col-md-3">
                                <label className="text-success col-form-label col-form-label-sm" for="taskdesc"><strong>Task Description:</strong></label>
                            </div>
                            <div className="col-md-9">
                                <input type="text" className="form-control form-control-sm" name="taskDescription" id="taskdesc" placeholder="Enter Task Description" value={this.state.form.taskDescription} onChange={this.handleChange}></input>
                            </div>
                            
                        </div>

                        <div className="form-group row mt-1">
                            <div className="col-md-3">
                                <label className="text-success col-form-label col-form-label-sm" for="stask"><strong>Start Date:</strong></label>
                            </div>
                            <div className="col-md-3">
                                <input type="date" value={this.state.form.taskStart} onChange={this.handleChange} className="form-control form-control-sm" name="taskStart" id="stask"></input>
                                <span className="text text-danger"><small>{this.state.formError.taskStart}</small></span>
                            </div>
                            <div className="col-md-3">
                                <label className="text-success col-form-label col-form-label-sm float-right" for="etask"><strong>End Date:</strong></label>

                            </div>
                            <div className="col-md-3">
                                <input type="date" className="form-control form-control-sm" name="taskEnd" id="etask" value={this.state.form.taskEnd} onChange={this.handleChange}></input>
                                <span className="text text-danger"><small>{this.state.formError.taskEnd}</small></span>
                            </div>
                        </div>
                     
                            <div>
                                <div className="row" >
                                    <div className="col-md-3">
                                        <label className="text text-success col-form-label-sm" for="memb"><strong>Members:</strong></label>
                                    </div>
                                    <div className="col-md-9">
                                        <MultiSelect className="form-control form-control-sm" name="members" id ="memb" options={membersarr} onChange={this.handleChangeMulti} value={this.state.form.members} ></MultiSelect>
                                    </div>
                                   
                                </div>
                                {/* <Button label="Add Task" icon="pi pi-plus" onClick={this.props.onRowAdd} className="p-button-secondary p-button-raised ml-3" /> */}
                            </div>
                       <div className="row form-group">
                       <div className="col-md-12 mt-3">
                       <button type="button" className ="btn btn-sm btn-danger float-right" data-toggle="modal" data-target="#deleteTaskConfirm"  >Delete Task</button>
                       <button type="submit" className ="btn btn-sm btn-success float-right mr-1" onClick={this.handleSubmitUpdate}>Update Task</button> &nbsp;
                      
                       </div>
                       {/* <div>
                                <span className="text text-success"><small>{this.state.successMessage}</small></span>
                                <span className="text text-danger"><small>{this.state.errorMessage}</small></span>

                            </div> */}
                        </div>
                    </form>
                </div>
                
                <div className="modal fade" id="deleteTaskConfirm" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-centered" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title text-info" id="exampleModalLabel"><strong>Confirm</strong></h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <div className="text text-primary"><strong>Are you sure you want to delete this task?</strong></div>
                            </div>
                            <div class="modal-footer">
                      
                              
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                                <button type="button" class="btn btn-primary" onClick={this.handleSubmitDelete} data-dismiss="modal">Yes</button>
                            </div>
                        </div>
                    </div>
                </div>


           
            </React.Fragment>
        )
    }

}

const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
  }
  
export default connect(mapStateToProps)(UpdateTaskComp);
  