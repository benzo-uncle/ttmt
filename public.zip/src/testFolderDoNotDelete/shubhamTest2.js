import React, { Component } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Button } from 'primereact/button';


export class Test3 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: this.props.message,
      type: this.props.type,
      notify: null
    }
  }

  notifyFunction = () => {
    if (this.state.notify) {
      return (this.state.notify())
    }
  }

  componentDidMount = () => {
   
    var notify;
    switch (this.state.type) {

      case "success":
        notify = () => {toast.success(this.state.message)};
        this.setState({ notify: notify })
        break;

      case "danger":
        notify = () => {toast.error(this.state.message)};
        this.setState({ notify: notify })
        break;

      case "warn":
        notify = () => { toast.warn(this.state.message) };
        this.setState({ notify: notify })
        break;

      case "info":
        notify = () =>{ toast.info(this.state.message)};
        this.setState({ notify: notify })
        break;

      default:
        notify = null;
        break;
    }

  }

  render() {

    return (
      <div>
        <ToastContainer
          enableMultiContainer
          position={toast.POSITION.TOP_RIGHT}
        />

        {this.notifyFunction()}

      </div>
    );
  }
}
