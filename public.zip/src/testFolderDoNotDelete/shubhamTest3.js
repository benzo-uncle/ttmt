import React, { Component } from 'react'
import { Test3 } from './shubhamTest2';

export default class Test4 extends Component {
    constructor() {
        super()

        this.state = {
            message: "Hi BOB @ ana",
            type: "info"
        }
    }

    render() {
        return (
            <div>
                <Test3 message={this.state.message} type={this.state.type} />
            </div>
        )
    }
}
