// import React from "react";
// import ReactExport from "react-data-export";

// const ExcelFile = ReactExport.ExcelFile;
// const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
// const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;

// const dataSet1 =[
//     {
//         name:"Johnson",
//         amount:30000,
//         gender:'M',
//         is_married:true
//     },
//     {
//         name:'Jack',
//         amount:35000,
//         gender:'M',
//         is_married:false,
//     }, 
//     {
//         name:'Monika',
//         amount:25000,
//         gender:'F',
//         is_married:false,
//     }, 
//     {
//         name:'Jonathan',
//         amount:60000,
//         gender:'M',
//         is_married:true,
//     }, 
// ];

// var dataSet2 = [
//     {
//         name:'Johnson',
//         total: 25,
//         remaining: 16,
//     },
//     {
//         name:'Jonathan',
//         total: 25,
//         remaining: 7
//     }
// ]

// export class Download extends React.Component{
//     render(){
//         return (
//             <ExcelFile element={<button>Download</button>}>
//                 <ExcelSheet data={dataSet1} name="Employees">
//                     <ExcelColumn label="Name" value="name"></ExcelColumn>
//                     <ExcelColumn label="Wallet Money" value="amount"></ExcelColumn>
//                     <ExcelColumn label="Gender" value="gender"></ExcelColumn>
//                     <ExcelColumn label="Marital Status" value={(col)=> col.is_married?"Married":"Single"}></ExcelColumn>
//                 </ExcelSheet>
//                 <ExcelSheet data={dataSet2} name="Leaves">
//                     <ExcelColumn label="Name" value="name"></ExcelColumn>
//                     <ExcelColumn label="Total Leaves" value="total"></ExcelColumn>
//                     <ExcelColumn label="Remaining Leaves" value="remaining"></ExcelColumn>
//                 </ExcelSheet>
//             </ExcelFile>
//         )
//     }

// }


// import * as FileSaver from 'file-saver';

// import * as XLSX from 'xlsx';

 

// const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';

// const EXCEL_EXTENSION = '.xlsx';

 

 

// export class ExcelService {

 

//     constructor() { }

 

//  exportAsExcelFile(json, excelFileName) {

 

//         const worksheet= XLSX.utils.json_to_sheet(json);

//         console.log('worksheet', worksheet);

//         const workbook= { Sheets: { 'data': worksheet }, SheetNames: ['data'] };

//         const excelBuffer= XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });

//         //const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });

//         this.saveAsExcelFile(excelBuffer, excelFileName);

//     }

 

//     saveAsExcelFile(buffer, fileName) {

//         const data= new Blob([buffer], {

//             type: EXCEL_TYPE

//         });

//         FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);

//     }

 

// }