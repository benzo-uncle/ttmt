import React, { Component } from 'react';
// import logo from './logo.svg';
// import './App.css';
import { BrowserRouter, Link, Route, Switch, Redirect } from 'react-router-dom';
import ManagerView from './managerComponents/managerView';
import TeamView from './teamMemberComponents/teamView';
import LoginForm from './loginform';
import { connect } from 'react-redux';

class App extends Component {

  render() {
    return (
      <React.Fragment>
        <BrowserRouter>
          <Switch>
            <Route exact path="/" render={() => (<Redirect to="/login" />)} />
            <Route exact path="/login" component={LoginForm} />
            <Route exact path="/managerView" component={ManagerView} />
            <Route exact path="/teamView" component={TeamView} />
          </Switch>
        </BrowserRouter>
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(App);
