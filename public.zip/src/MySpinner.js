import React from 'react'
import { ProgressSpinner } from 'primereact/progressspinner';
 export class MySpinner extends React.Component{
    constructor(){
        super();
        this.state={
            counter:0
        }
    }
     myFunc=()=>{
    
        this.setState({counter:this.state.counter+1})
    }
    
    render(){
        {setInterval(this.myFunc,1000)}
        return(<div>
            
            {this.state.counter<6? <ProgressSpinner style={{ display: 'flex', height: '60vh' }} strokeWidth="3" animationDuration="1s" />:<div className="text-center text-secondary" style={{ marginBottom: "4em",marginTop:"10em" }}><h1>No Data Found</h1></div>}     
        </div>
        )
    }
}
