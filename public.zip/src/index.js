import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import * as serviceWorker from './serviceWorker';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import '../node_modules/jquery/dist/jquery.js'
import '../node_modules/popper.js/dist/popper.js'
import '../node_modules/bootstrap/dist/js/bootstrap.min.js'
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import 'font-awesome/css/font-awesome.min.css';
import App from './App';
import store from './globalState/shopStore';
import { Provider } from 'react-redux'
import { ManagerView } from './managerComponents/managerView';
import { TeamView } from './teamMemberComponents/teamView';

ReactDOM.render(<Provider store={store}><App/></Provider>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
    