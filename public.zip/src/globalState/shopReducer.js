var initialState = {
    loginDetails: {
        userId: "",
        userName: "",
        empType: ""
    },
    leftPaneMessages: {
        message: "",
        messageType: ""
    }
}

function changeState(state = initialState, action) {
    var type = action.type
    var stateCopy = Object.assign({}, state);

    switch (type) {
        case "LOGIN":
            stateCopy.loginDetails.userId = action.userId;
            stateCopy.loginDetails.userName = action.userName;
            stateCopy.loginDetails.empType = action.empType;
            return (stateCopy)

        case "LOGOUT":
            stateCopy.loginDetails.userId = "";
            stateCopy.loginDetails.userName = "";
            stateCopy.loginDetails.empType = "";
            return (stateCopy)

        case "ALERT_MESSAGE":
            stateCopy.leftPaneMessages.message = action.message;
            stateCopy.leftPaneMessages.messageType = action.messageType;
            return (stateCopy)

        default:
            return (stateCopy)
    }
}

export default changeState;