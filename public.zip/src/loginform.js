import React from 'react';
import axios from 'axios';
import { InputText } from 'primereact/inputtext';
import { ProgressBar } from 'primereact/progressbar';
import { Redirect } from 'react-router-dom';
import { connect } from 'react-redux'

import Background from './resources/img/backgroundLogin.png'


class LoginForm extends React.Component {

    constructor() {
        super();
        this.state = {
            value1: null,
            formData: {
                emailId: "",
                password: ""
            },
            formErrorMessage: {
                emailId: "",
                password: ""
            },
            formValid: {
                emailId: false,
                password: false,
                buttonActive: false
            },
            serverResponse: "",
            errorMessage: "",
            loader: false
        }
    }

    handleChange = (event) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const { formData } = this.state;
        this.setState({ formData: { ...formData, [name]: value } });
        this.validateField(name, value)

    }


    validateField = (fieldName, value) => {
        let fieldValidationErrors = this.state.formErrorMessage;
        let formValid = this.state.formValid;

        switch (fieldName) {
            case "emailId":
                if (value === "") {
                    fieldValidationErrors.emailId = "email address cannot be empty";
                    formValid.emailId = false;
                // } else if (!/[@]+(infosys.com)$/.test(value)) {
                //     fieldValidationErrors.emailId = "Invalid email format";
                //     formValid.emailId = false;
                } else {
                    fieldValidationErrors.emailId = "";
                    formValid.emailId = true;
                }
                break;

            case "password":
                if (value === "") {
                    fieldValidationErrors.password = "password cannot be empty";
                    formValid.password = false;
                } else {
                    fieldValidationErrors.password = "";
                    formValid.password = true;
                }
                break;

            default:
                break;
        }

        formValid.buttonActive = formValid.emailId
            && formValid.password

        this.setState({ formErrorMessage: fieldValidationErrors, formValid: formValid, serverResponse: "", errorMessage: "", loader: false })

    }

    loginAction = (data) => {
        var action = {
            type: "LOGIN",
            userId: data.userId,
            userName: data.userName,
            empType: data.empType
        }
        this.props.dispatch(action);
    }

    login = (event) => {
        event.preventDefault();
        this.setState({ serverResponse: "", errorMessage: "" })

        const { formData } = this.state;



        axios.post("http://localhost:2040/login/", formData)
            .then(response => {
                console.log(response.data.message);
                this.loginAction(response.data.message)
                this.setState({ serverResponse: response.data.message, errorMessage: "", loader: false });

            }).catch(error => {
                if (error.response) {
                    this.setState({ errorMessage: error.response.data.message, serverResponse: "", loader: false });
                } else {
                    this.setState({ errorMessage: "server error", serverResponse: "", loader: false });
                }
            });

    }

    redirect = () => {
        var redirect = null
        if (this.props.loginDetails.userId !== "") {
            if (this.props.loginDetails.empType === "Manager") {
                redirect =<Redirect to="/managerView" />
            } else if (this.state.serverResponse.empType === "TeamMember") {
                redirect = <Redirect to="/teamView" />
            }
        }
        return redirect;
    }

    render() {

        return (
            <div className="container-fluid" style={{ backgroundImage: `url(${Background})`, backgroundSize: "cover", overflow: 'hidden', height: "100vh" }}>
                <div className="row m-5">
                    <div className="card col-md-5 mx-auto shadow-lg border rounded text-center">
                        <div className="card-header bg-white mt-2">
                            <h4 className="text-secondary" >Log in to TTMT</h4>
                        </div>
                        <div className="card-body" >
                            <form onSubmit={this.login} >

                                <div className="form-group row d-flex justify-content-center">
                                    <div className="">

                                        <span className="p-float-label">
                                            <InputText
                                                id="emailId"
                                                name="emailId"
                                                type="text"
                                                size="32"
                                                value={this.state.formData.emailId}
                                                onChange={(event) => {
                                                    const target = event.target;
                                                    const value = target.value;
                                                    const name = target.name;
                                                    const { formData } = this.state;
                                                    this.setState({ formData: { ...formData, [name]: value } });
                                                }}

                                                onBlur={(e) => {
                                                    const value = e.target.value;
                                                    const name = e.target.name;
                                                    this.validateField(name, value)
                                                }}
                                                onFocus={(e) => {
                                                    let fieldValidationErrors = this.state.formErrorMessage;
                                                    fieldValidationErrors.emailId = "";
                                                    this.setState({ formErrorMessage: fieldValidationErrors })
                                                }}

                                                className="form-control" />

                                            <label htmlFor="emailId" className="text-center">username@infosys.com</label>
                                        </span>

                                        <div className="text-danger" style={{ fontSize: "0.9em" }}>
                                            {this.state.formErrorMessage.emailId}
                                        </div>
                                    </div>
                                </div>


                                <div className="form-group row d-flex justify-content-center">
                                    <div className="">

                                        <span className="p-float-label">
                                            <InputText
                                                id="password"
                                                name="password"
                                                type="password"
                                                size="32"
                                                value={this.state.formData.password}
                                                onChange={this.handleChange}

                                                onBlur={(e) => {
                                                    const value = e.target.value;
                                                    const name = e.target.name;
                                                    this.validateField(name, value)
                                                }}

                                                onFocus={(e) => {
                                                    let fieldValidationErrors = this.state.formErrorMessage;
                                                    fieldValidationErrors.password = "";
                                                    this.setState({ formErrorMessage: fieldValidationErrors })
                                                }}

                                                className="form-control" />

                                            <label htmlFor="emailId" className="text-center">password</label>
                                        </span>

                                        <div className="text-danger" style={{ fontSize: "0.9em" }}>
                                            {this.state.formErrorMessage.password}
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" disabled={!this.state.formValid.buttonActive} onClick={() => this.setState({ loader: true })} className="btn btn-primary mt-2 btn-block col-sm-8 mx-auto form-group">Login</button>

                            </form>
                            <div className="card-footer text-muted bg-white text-secondary" style={{ fontSize: "13px" }} >
                                Copyright &copy; 2019 Infosys Limited
                            </div>

                            {this.state.serverResponse ? <span className="text-success">Welcome! {this.state.serverResponse.userName} {this.redirect()}  </span> : this.state.loader ? <ProgressBar mode="indeterminate" style={{ height: '6px' }}></ProgressBar> : null}
                            <span className="text-danger">{this.state.errorMessage}</span>

                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
  }
  

export default connect(mapStateToProps)(LoginForm)