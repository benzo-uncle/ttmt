import React from 'react'
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { Button } from 'primereact/button';
import ReactTooltip from 'react-tooltip'
import { ProgressSpinner } from 'primereact/progressspinner';

export class OngoingViewDetails extends React.Component {
    render() {
        var tasks = this.props.projectDetailsData.tasks;
        return (<div className="card-body">
            <div className="row ">
                {this.props.projectDetailsData.status === false ? <ProgressSpinner animationDuration="1s" style={{ width: '50px' }} /> : <div className="col-md-12">
                    <div className="row mb-3">
                        <span className="col-md-2 text-muted font-italic" style={{ fontSize: "14px" }}>Project Description : </span>
                        <span className="col-md-9 text-dark font-italic" style={{ fontSize: "15px", marginLeft: "-0.70em" }}>{this.props.projectDetailsData.description}</span>

                    </div>
                    <div>
                        <table className="table table-hover text-center">
                            <thead className="thead-light">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Member Name</th>
                                    <th scope="col">Task Name</th>
                                    <th scope="col">Task Status</th>
                                    <th scope="col">Timeline</th>
                                </tr>

                            </thead>
                            <tbody>
                                {tasks.map((details, index) => (
                                    <tr>
                                        <th scope="row">{index + 1}</th>
                                        <td>{details.empId}</td>
                                        <td ><a data-tip={details.comment}> {details.tasksName}</a><ReactTooltip place="right" type="info" className="w-25" effect="float" html={true} /></td>
                                        <td>
                                            {details.status === "Ongoing" ? <div><div className="progress">
                                                <div className="progress-bar progress-bar-striped progress-bar-animated bg-warning" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style={{ width: "50%" }}><b>Ongoing</b></div>
                                            </div></div> : <div><div className="progress progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style={{ width: "100%" }}><b>Completed</b></div>
                                                </div>}
                                        </td>
                                        <td>
                                            <span className="text-info" style={{ fontSize: "14px" }}>Start Date : {new Date(details.timeline.startDate).toLocaleDateString()}<br /> End Date : {new Date(details.timeline.endDate).toLocaleDateString()}</span> &nbsp;
                                </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>}
            </div>
        </div>)
    }
} 
