import React from 'react';
import { BrowserRouter, Link, Route, Switch, Redirect } from 'react-router-dom';
import Leftpane from './leftPane';
import Ongoing from './ongoing';
import CreateRequest from './createRequest';
import ViewRequest from './viewRequestStatus';
import Tasks from './viewTasks';
import Completed from './completed';
import { Button } from 'primereact/button';
import NotificationBadge from 'react-notification-badge';
import { Effect } from 'react-notification-badge';
import axios from "axios";
import { connect } from 'react-redux';
const url = "http://localhost:2040/viewNotification/";
const url1 = "http://localhost:2040/deleteOneNotification/";
const url2 = "http://localhost:2040/deleteAllNotifications/";




class TeamView extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            count: 0,
            notificationData: [],
            errorMessage: "",
            id: this.props.loginDetails.userId,
            successMessage: ""
        }
    }
    deleteAllNotifications = () => {
        this.setState({ successMessage: "", errorMessage: "" })
        axios.delete(url2 + this.state.id)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" });
                setTimeout(() => {

                    this.fetchNotifications()
                    this.setState({ count: 0 })
                }, 1000);
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }
    deleteOneNotification = (notificationId) => {
        console.log("notification", notificationId)
        this.setState({ successMessage: "", errorMessage: "" })
        axios.delete(url1 + this.state.id + "/" + notificationId)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" });
                this.fetchNotifications();
                this.setState({ count: 0 })
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }
    handleClick = () => {
        var header = document.getElementById("navs");
        var nav = header.getElementsByClassName("nav-link");
        for (var i = 0; i < nav.length; i++) {
            nav[i].addEventListener("click", function () {
                var current = document.getElementsByClassName("active");

                // If there's no active class
                if (current.length > 0) {
                    current[0].className = current[0].className.replace(" active", "");
                }

                // Add the active class to the current/clicked button
                this.className += " active";
            });
        }

    }
    handleNotification = () => {
        this.setState({ count: 0 });
    }
    componentDidMount() {
        this.fetchNotifications();
    }
    fetchNotifications = () => {
        axios.get(url + this.state.id)
            .then(response => this.setState({ notificationData: response.data, count: response.data.length, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, notificationData: [] })
                } else {
                    this.setState({ errorMessage: error.message, notificationData: [] })
                }
            })
    }
    generateNotificationCard = (notification) => {
        if (notification.notificationType === "Task Status Request") {
            return (
                <tr>
                    <td>
                        <div className="card">
                            <div className="card-body no-padding no-gutter mt-n3 mb-n3">
                                <div className="row no-padding no-gutter text-info">
                                    <div className="col-sm-10"><small>Status request has arrived on <span className="text-danger"><i><strong>{new Date(notification.date).toLocaleDateString()} at {notification.time}</strong></i></span> for the task <b>{notification.taskName}</b> of the project <b>{notification.projectName}</b></small></div>
                                    <div className="col-sm-2">
                                        <button type="button" style={{ marginLeft: "18px", marginTop: "-20px", fontSize: "18px", backgroundColor: "white", border: "0px" }} onClick={() => this.deleteOneNotification(notification.notificationId)}>
                                            <span><b>&times;</b>
                                            </span>
                                        </button>
                                        <div style={{ marginTop: "5px", marginLeft: "-20px" }}>
                                            <div className="dot-task text-dark" style={{ paddingLeft: "15px", fontSize: "35px" }}><b>S</b></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            )
        }
        else {
            return (
                <tr >
                    <td>
                        <div className="card">
                            <div className="card-body no-padding no-gutter mt-n3 mb-n3">
                                <div className="row no-padding no-gutter text-info">
                                    <div className="col-sm-10"><small>There is an upcoming event on <span className="text-danger"><i><strong>{new Date(notification.date).toLocaleDateString()} at {notification.time} in {notification.venue}</strong></i></span> for the project <b>{notification.projectName}</b></small></div>
                                    <div className="col-sm-2">
                                        <button style={{ marginLeft: "18px", marginTop: "-20px", fontSize: "18px", backgroundColor: "white", border: "0px" }}>
                                            <span><b>&times;</b>
                                            </span>
                                        </button>
                                        <div style={{ marginTop: "5px", marginLeft: "-20px" }}>
                                            <div className="dot-task text-dark" style={{ paddingLeft: "15px", fontSize: "35px" }}><b>E</b></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            )
        }
    }

    greet = () => {
        var greeting;
        var time = new Date().getHours();
        if (time >= 17 && time <= 23) {
            greeting = "Good Evening,";
        } else if (time >= 12 && time < 17) {
            greeting = "Good Afternoon,";
        } else if (time >= 0 && time < 12) {
            greeting = "Good Morning,";
        }
        return greeting
    }


    render() {
        return (
            <React.Fragment>
                <BrowserRouter>
                    <nav className="navbar navbar-expand-lg navbar-dark bg-info">
                        <Link to={'/'} className="navbar-brand" >Team Task Management</Link>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav ml-auto">
                                <li className="nav-item mt-2 mr-4 text-white">
                                    {this.greet()} {this.props.loginDetails.userName}
                                </li>
                                <li className="nav-item dropdown">
                                    <a className="nav-link text-light" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <NotificationBadge count={this.state.count} style={{ marginTop: "-0.85em", marginRight: "-0.5em" }} effect={Effect.SCALE} />
                                        <i className="fa fa-bell p-0 m-0" style={{ color: "black", fontSize: "1.3em", marginTop: "-1.05em", marginBottom: "-1.05em" }} onClick={() => this.handleNotification()}></i>
                                    </a>
                                    <form>
                                        <ul className="dropdown-menu dropdown-menu-right border-dark" role="menu">
                                            <li className="notification-box mb-n3" style={{ overflowY: "auto" }}>
                                                <div>
                                                    <div className="table-responsive">
                                                        <table className=" table table-hover table-sm border-dark" >
                                                            <tbody >
                                                                {this.state.notificationData.length > 0 ? this.state.notificationData.map((notification) => this.generateNotificationCard(notification)) :
                                                                    <div className="text-center text-info"> <b> No New Notifications</b> </div>
                                                                }
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </li>
                                            <li className="footer ">
                                                {this.state.notificationData.length > 0 ? <button type="button" className="btn btn-danger btn-sm fixed mt-3" style={{ float: "right" }} onClick={() => this.deleteAllNotifications()}>Delete all</button> : null}

                                            </li>
                                        </ul>
                                    </form>
                                </li>
                                <li className="nav-item">

                                    <a href={"/login/"}><Button label="Logout" icon="pi pi-power-off" className="p-button-warning mt-1" onClick={() => this.logoutAction} style={{ marginLeft: "8px" }} /></a>

                                </li>
                            </ul>
                        </div>
                    </nav>

                    <div className='container-fluid' >
                        <div className='row mt-1' >
                            <div className="col-md-3" >
                                <Leftpane />
                            </div>
                            <div className="col-md-9" style={{ marginTop: "2px" }}>


                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="card shadow bg-white rounded" style={{ marginLeft: "-12px", marginRight: "-8px" }} >
                                            <div className="card-header">
                                                <ul className="nav nav-tabs card-header-tabs" id="navs">
                                                    <li className="nav-item col-md-2 text-center">
                                                        <Link to={'/ongoing'} className="nav-link" onClick={this.handleClick} style={{ color: "black" }}><i className="fa fa-history" aria-hidden="true"></i><strong>&nbsp;On-Going</strong></Link>
                                                    </li>
                                                    <li className="nav-item col-md-3  text-center">
                                                        <Link to={'/createRequest'} className="nav-link" onClick={this.handleClick} style={{ color: "black" }}><i class="fa fa-user-plus" aria-hidden="true"></i><strong>&nbsp;Create Request</strong></Link>
                                                    </li>
                                                    <li className="nav-item col-md-3 text-center">
                                                        <Link to={'/viewStatusofRequest'} className="nav-link" onClick={this.handleClick} style={{ color: "black" }}><i class="fa fa-hourglass-half" aria-hidden="true"></i><strong>&nbsp;Request's Status</strong></Link>
                                                    </li>
                                                    <li className="nav-item col-md-2  text-center">
                                                        <Link to={'/viewTasks'} className="nav-link" onClick={this.handleClick} style={{ color: "black" }}><i class="fa fa-tasks" aria-hidden="true"></i><strong>&nbsp;Tasks</strong></Link>
                                                    </li>
                                                    <li className="nav-item col-md-2 text-center">
                                                        <Link to={'/completed'} className="nav-link" onClick={this.handleClick} style={{ color: "black" }}><i class="fa fa-check-circle" aria-hidden="true"></i><strong>&nbsp;Completed</strong></Link>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="card-body" style={{ overflowY: "auto", height: "81vh" }}>
                                                <Switch>
                                                    <Route exact path="/teamView" render={() => (<Redirect to="/ongoing" />)} />
                                                    <Route exact path="/ongoing" component={Ongoing} />
                                                    <Route path="/createRequest" component={CreateRequest} />
                                                    <Route path="/viewStatusofRequest" component={ViewRequest} />
                                                    <Route exact path="/viewTasks" component={Tasks} />
                                                    <Route path="/completed" component={Completed} />
                                                </Switch>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </BrowserRouter>
            </React.Fragment >
        )
    }
}

const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(TeamView)