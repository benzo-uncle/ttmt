import React from 'react';
import axios from "axios";
import { connect } from 'react-redux';

const url = 'http://localhost:2040/getEmpDetails/';
const url1 = 'http://localhost:2040/createRequest/';
const url2 = 'http://localhost:2040/viewOngoingProjectsForTeamMember/';
const url3 = 'http://localhost:2040/viewOngoingProjects/';
const url4 = 'http://localhost:2040/viewAllTasksForTeamMember/';
const url5 = 'http://localhost:2040/getManagerId';
class CreateRequest extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            enable: {
                projectName: true,
                taskname: true,
                startDate: true,
                endDate: true,
                extension: true
            },
            formValue: {
                reasonType: "",
                projectName: "",
                taskName: "",
                startDate: "",
                endDate: "",
                extension: "",
                reason: ""
            },
            formErrorMessage: {
                reasonType: "",
                projectName: "",
                taskName: "",
                startDate: "",
                endDate: "",
                extension: "",
                reason: ""
            },
            formValidation: {
                reasonType: false,
                projectName: false,
                taskName: false,
                startDate: false,
                endDate: false,
                extension: false,
                reason: false,
                button: false
            },
            successMessage: "",
            errorMessage: "",

            id: this.props.loginDetails.userId,
            userName: "",
            projectsArr: [],
            tasksArr: [],
            display:false,
            managerId:""
        }
    }
    componentDidMount() {
        this.getEmpDetails();
        this.getManagerId();
    }

  getManagerId=()=>{
    axios.get(url5)
    .then(response => this.setState({ managerId: response.data.userId, errorMessage: "" }))
    .catch(error => {
        if (error.status === 404) {
            this.setState({ errorMessage: error.response.data.message, userName: "" })
        } else {
            this.setState({ errorMessage: error.message, userName: "" })
        }
    })
  }

    getEmpDetails = () => {
        axios.get(url + this.state.id)
            .then(response => this.setState({ userName: response.data[0].userName, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, userName: "" })
                } else {
                    this.setState({ errorMessage: error.message, userName: "" })
                }
            })
    }
    createRequest = () => {
        var form = {
            projectName: this.state.formValue.projectName,
            userName: this.state.userName,
            taskName: this.state.formValue.taskName,
            requestReason: this.state.formValue.reason,
            timeline: {
                startDate: this.state.formValue.startDate,
                endDate: this.state.formValue.endDate
            },
            NoOfDays: this.state.formValue.extension,
            requestType: this.state.formValue.reasonType


        }

        this.setState({ successMessage: "", errorMessage: "" })
        axios.post(url1 + this.state.id, form)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" });

            }).catch(error => {
                this.setState({ errorMessage: error.response.data.message, successMessage: "" });
            });
    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.createRequest();
    }
    handleClick = (event) => {
        this.setState(Object.assign(this.state.enable, { projectName: true, taskname: true, startDate: true, endDate: true, extension: true }))
        this.setState(Object.assign(this.state.formValue, { reasonType: event.target.value }))
        this.setState(Object.assign(this.state.formErrorMessage, { reasonType: "", projectName: "", taskName: "", startDate: "", endDate: "", extension: "", reason: "" }))
        var typeOfRequest = event.target.value;

        if (typeOfRequest === "Leave") {
            this.setState(Object.assign(this.state.enable, { projectName: false, taskname: false, extension: false }))
            this.setState(Object.assign(this.state.formValue, { projectName: "", taskName: "", extension: "" }))
        }
        else if (typeOfRequest === "TimeExtension") {
            this.setState(Object.assign(this.state.enable, { startDate: false, endDate: false }))
            this.setState(Object.assign(this.state.formValue, { startDate: "", endDate: "" }))
            this.setState({ display: true })
            this.fetchOngoingProjectsForTeamMember();
        }
        else if (typeOfRequest === "NewTask") {
            this.setState(Object.assign(this.state.enable, { startDate: false, endDate: false, extension: false }))
            this.setState(Object.assign(this.state.formValue, { startDate: "", endDate: "", extension: "" }))
            this.setState({ display: false })
            this.fetchOngoingProjects();
        }
    }
    fetchOngoingProjectsForTeamMember = () => {
        axios.get(url2 + this.state.id)
            .then(response => this.setState({ projectsArr: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, projectsArr: "" })
                } else {
                    this.setState({ errorMessage: error.message, projectsArr: "" })
                }
            })
    }
    fetchOngoingProjects = () => {
        axios.get(url3 + this.state.managerId)
            .then(response => this.setState({ projectsArr: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, projectsArr: "" })
                } else {
                    this.setState({ errorMessage: error.message, projectsArr: "" })
                }
            })
    }
    fetchTasks = (projectId) => {

        axios.get(url4 + projectId)
            .then(response => {
                this.setState({ tasksArr: response.data, errorMessage: "" });

            })
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, tasksArr: "" })
                } else {
                    this.setState({ errorMessage: error.message, tasksArr: "" })
                }
            })
    }
    handleChange = (event) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const { formValue } = this.state;
        this.setState({ formValue: { ...formValue, [name]: value } });

        this.validateField(name, value);
    }

    validateField = (fieldName, value) => {
        var formError = this.state.formErrorMessage;
        var formValid = this.state.formValidation;
        if (fieldName === "projectName") {
            if (value === "") {
                formError.projectName = "Please Enter Project Name";
                formValid.projectName = false;
            }

            else {
                formError.projectName = "";
                formValid.projectName = true;

                var i = 0;
                var projectId;
                for (i = 0; i < this.state.projectsArr.length; i++) {
                    if (value === this.state.projectsArr[i].projectName) {
                        projectId = this.state.projectsArr[i].projectId
                    }
                }

                this.fetchTasks(projectId)
            }

        }
        else if (fieldName === "taskName") {
            if (value === "") {
                formError.taskName = "Please Enter Task Name";
                formValid.taskName = false;
            }
            else if (!(value.match(/^[A-z 0-9]{3,}$/))) {
                formError.taskName = "Please Enter Valid Task Name";
                formValid.taskName = false;
            }
            else {
                formError.taskName = "";
                formValid.taskName = true;
            }

        }
        else if (fieldName === "startDate") {
            let sDate = new Date(value).setUTCHours(0, 0, 0, 0);
            let today = new Date().setUTCHours(0, 0, 0, 0);
            if (value === "") {
                formError.startDate = "Please Enter Date";
                formValid.startDate = false;
            }
            else if (sDate < today) {
                formError.startDate = "Please Enter Valid Date";
                formValid.startDate = false;
            }
            else {
                formError.startDate = "";
                formValid.startDate = true;
            }

        }
        else if (fieldName === "endDate") {
            let eDate = new Date(value).setUTCHours(0, 0, 0, 0);
            let sDate = new Date(this.state.formValue.startDate).setUTCHours(0, 0, 0, 0);
            if (value === "") {
                formError.endDate = "Please Enter Date";
                formValid.endDate = false;
            }
            else if (eDate < sDate) {
                formError.endDate = "Please Enter Valid Date";
                formValid.endDate = false;
            }
            else {
                formError.endDate = "";
                formValid.endDate = true;
            }

        }
        else if (fieldName === "extension") {
            if (value === "") {
                formError.extension = "Please Enter Number of Days for Extension";
                formValid.extension = false;
            }
            else if (value === 0) {
                formError.extension = "Please Enter Valis Number of Days";
                formValid.extension = false;
            }
            else {
                formError.extension = "";
                formValid.extension = true;
            }

        }
        else if (fieldName === "reason") {
            if (value === "") {
                formError.reason = "Please Enter Reason";
                formValid.reason = false;
            }
            else {
                formError.reason = "";
                formValid.reason = true;
            }

        }
        if (this.state.formValue.reasonType === "") {
            formError.reasonType = "Please Select Respective Reason for the Request";
            formValid.reasonType = false;
        }
        else if (this.state.formValue.reasonType === "Leave") {
            formError.reasonType = " ";
            formValid.reasonType = true;
            formValid.button = formValid.startDate && formValid.endDate && formValid.reason;
        }
        else if (this.state.formValue.reasonType === "TimeExtension") {
            formError.reasonType = " ";
            formValid.reasonType = true;
            formValid.button = formValid.projectName && formValid.taskName && formValid.extension && formValid.reason;
        }
        else if (this.state.formValue.reasonType === "NewTask") {
            formError.reasonType = " ";
            formValid.reasonType = true;
            formValid.button = formValid.projectName && formValid.taskName && formValid.reason;
        }

        this.setState({ formErrorMessage: formError, formValidation: formValid });
    }

    render() {
        return (
            <React.Fragment>

                <form className="container-fluid" onSubmit={this.handleSubmit}>
                    <div className="card">
                        <div className="card-body">
                            <div className="form-group row">
                                <label htmlFor="username" className="col-sm-2 col-form-label text-info"><b>Request From:</b></label>
                                <div className="col-sm-8">
                                    <input type="text" name="username" value={this.state.userName} className="form-control form-control-sm border border-dark" id="username" placeholder={this.state.userName} disabled></input>
                                </div>
                            </div>
                            <div className="form-group row">
                                <label htmlFor="requestType" class="col-sm-2 col-form-label text-info"><b>Request Type:</b></label>
                                <div className="col-sm-8">
                                    <select onClick={this.handleClick} name="requestType" className="form-control-sm border border-dark">
                                        <option value="" selected>--SELECT--</option>
                                        <option value="Leave">Leave Request</option>
                                        <option value="TimeExtension">Time Extension</option>
                                        <option value="NewTask">Task Request</option>
                                    </select>
                                    <br />
                                    <span className="text-danger">{this.state.formErrorMessage.reasonType}</span>
                                </div>
                            </div>

                            <div className="form-group row" style={{ marginTop: "-15px" }}>
                                <label htmlFor="projectName" className="col-sm-2 col-form-label text-info"><b>Project Name:</b></label>
                                <div className="col-sm-8">
                                    <select name="projectName" value={this.state.formValue.projectName} className="form-control border border-dark" onChange={this.handleChange} id="projectName" disabled={!this.state.enable.projectName}>
                                        <option value="" selected>--SELECT--</option>
                                        {this.state.projectsArr.length > 0 ?
                                            this.state.projectsArr.map(project => <option key={project.projectId} value={project.projectName}>{project.projectName}</option>)
                                            : null}
                                    </select>
                                    <br />
                                    <span className="text-danger">{this.state.formErrorMessage.projectName}</span>
                                </div>
                            </div>
                            <div className="form-group row" style={{ marginTop: "-40px" }}>
                                <label htmlFor="taskName" className="col-sm-2 col-form-label text-info"><b>Task Name:</b></label>
                                <div className="col-sm-8">
                                    {this.state.display ? <select name="taskName" value={this.state.formValue.taskName} className="form-control border border-dark" onChange={this.handleChange} id="taskName" disabled={!this.state.enable.taskname}>
                                        <option value="" selected>--SELECT--</option>
                                        {this.state.tasksArr.length > 0 ?
                                            this.state.tasksArr[0].tasks.map(task => <option key={task.tasksId} value={task.taskName}>{task.tasksName}</option>)
                                            : null}
                                    </select> : <input type="text" name="taskName" onChange={this.handleChange} value={this.state.formValue.taskName} className="form-control form-control-sm border border-dark" id="taskName" placeholder="Enter Task Name" disabled={!this.state.enable.taskname}></input>}
                                    <span className="text-danger">{this.state.formErrorMessage.taskName}</span>
                                </div>
                            </div>
                            <div className="form-group row" style={{ marginTop: "-20px" }}>
                                <label htmlFor="startDate" className="col-sm-2 col-form-label text-info"><b>Start Date:</b></label>
                                <div className="col-sm-3">
                                    <input type="date" name="startDate" onChange={this.handleChange} value={this.state.formValue.startDate} className="form-control form-control-sm border border-dark" id="startDate" disabled={!this.state.enable.startDate}></input>
                                    <span className="text-danger">{this.state.formErrorMessage.startDate}</span>
                                </div>
                                <label htmlFor="endDate" className="col-sm-2 col-form-label text-info"><b>End Date:</b></label>
                                <div className="col-sm-3" style={{ marginLeft: "-50px" }}>
                                    <input type="date" name="endDate" onChange={this.handleChange} value={this.state.formValue.endDate} className="form-control form-control-sm border border-dark" id="endDate" disabled={!this.state.enable.endDate}></input>
                                    <span className="text-danger">{this.state.formErrorMessage.endDate}</span>
                                </div>
                            </div>
                            <div className="form-group row" style={{ marginTop: "-20px" }}>
                                <label htmlFor="extension" className="col-sm-2 col-form-label text-info"><b>Extension Required:</b></label>
                                <div className="col-sm-8">
                                    <input type="Number" name="extension" onChange={this.handleChange} value={this.state.formValue.extension} className="form-control form-control-sm border border-dark" id="extension" placeholder="Enter Number of Days" disabled={!this.state.enable.extension}></input>
                                    <span className="text-danger">{this.state.formErrorMessage.extension}</span>
                                </div>
                            </div>
                            <div className="form-group row" style={{ marginTop: "-20px" }}>
                                <label htmlFor="reason" className="col-sm-2 col-form-label text-info"><b>Reason:</b></label>
                                <div className="col-sm-8">
                                    <input type="text" name="reason" onChange={this.handleChange} value={this.state.formValue.reason} className="form-control form-control-sm border border-dark" id="reason" placeholder="Enter Reason" required></input>
                                    <span className="text-danger">{this.state.formErrorMessage.reason}</span>
                                </div>
                            </div>
                            <center style={{ marginTop: "-25px" }}>
                                <button type="submit" name="submitButton" className="btn btn-success border border-dark shadow-lg" disabled={!this.state.formValidation.button}><b>Create Request</b></button>
                            </center>
                        </div>
                    </div>
                    <span className="text-success font-weight-bold message">
                        {this.state.successMessage}
                    </span>
                    <span className="text-danger font-weight-bold message">
                        {this.state.errorMessage}
                    </span>
                </form>
            </React.Fragment>
        )
    }
}



const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(CreateRequest);
