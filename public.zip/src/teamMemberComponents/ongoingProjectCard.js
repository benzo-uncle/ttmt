import React from 'react'
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { Button } from 'primereact/button';
import { OngoingViewDetails } from './ongoingViewDetails';
import axios from "axios";
import { connect } from 'react-redux'
import { log } from 'util';
import { ExcelService } from '../testFolderDoNotDelete/excelDownloadTest';
const url1 = 'http://localhost:2040/viewOngoingProjectDetailsForTeamMember/';



class Ongoingcard extends React.Component{
    constructor(props) {
 
        super(props);
        this.state = {
            btnLabel: "View Details",
            btnStatus: false,
            projectDetailsData: {
                description: "",
                tasks: [],
                status: false,
            },
            projectTrial:{
                description:{
                    abc:true,
                    abc:false
                },
                status:false,
            },
            errorMessage: "",
            id: this.props.loginDetails.userId
        }
    }
    handleClick = (projectId) => {
        if (this.state.btnLabel === "View Details") {
            this.setState({ btnStatus: true, btnLabel: "Close" })
            this.fetchOngoingProjectDetails(projectId);
        }
        else {
            this.setState({ btnStatus: false, btnLabel: "View Details" })
        }
    }
    fetchOngoingProjectDetails = (projectId) => {
        axios.get(url1 + this.state.id + "/" + projectId)
            .then(response => {
                this.setState({ projectDetailsData: response.data, errorMessage: "" })
            })
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, projectDetailsData: {} })
                } else {
                    this.setState({ errorMessage: error.message, projectDetailsData: {} })
                }
            })
    }

    downloadFile = () =>{
        let excel = new ExcelService()
        console.log(excel,this.state.projectTrial);
        
        excel.exportAsExcelFile([this.state.projectTrial],"download")
    }
    render(){
        return(
            <div className="card shadow bg-white rounded mt-1">
                <div className="card-header">
                    <div className="row ">
                        <div className="col-md-12">
                            <span className="text-muted" style={{ fontSize: "16px" }}>Project Name : </span>
                            <span className="blockquote" >{this.props.project.projectName}</span>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-9">
                            <div style={{ float: "left" }}>
                                <span className="text-info m-1" style={{ display: "inline" }}>Start Date : <strong>{new Date(this.props.project.timeline.startDate).toLocaleDateString()}</strong></span>
                                <span className="text-info m-1" style={{ display: "inline" }}>End Date : <strong>{new Date(this.props.project.timeline.endDate).toLocaleDateString()}</strong></span>
                            </div>
                            <div style={{ float: "right" }}>
                                <span className="text-danger mt-1 mr-4" >Days Left:{new Date(new Date(this.props.project.timeline.endDate) - new Date()).getDate()} </span>
                            </div>
                        </div>
                        <div className="col-md-3 d-flex justify-content-center">
                            {/* <Button label={this.state.buttonLabel} className="p-button-raised p-button-rounded" onClick={()=>this.handleClick(project.projectId)} /> */}
                            <button type="submit" value={this.props.project.projectId} name={this.state.btnLabel} id={this.state.btnLabel} onClick={() => this.handleClick(this.props.project.projectId)} className="btn btn-rounded btn-primary"><b>{this.state.btnLabel}</b></button>
                        </div>
                    </div>
                    <div className="col-md-3 d-flex justify-content-center">
                    <button onClick={this.downloadFile}> Download </button>
                        {/* <Button label={this.state.buttonLabel} className="p-button-raised p-button-rounded" onClick={()=>this.handleClick(project.projectId)} /> */}
                        <button type="submit" value={this.props.project.projectId} name={this.state.btnLabel} id={this.state.btnLabel} onClick={()=>this.handleClick(this.props.project.projectId)} className="btn btn-rounded btn-primary"><b>{this.state.btnLabel}</b></button>
                    </div>
                </div>
                <div className="row mt-1">
                    <div className="col-md-2">
                        <div className="text-muted" style={{ fontSize: "16px" }}>Status : </div>
                    </div>
                    <div className="col-md-8" style={{ marginLeft: "-6.2em", marginTop: ".34em" }}>
                        <div className="progress">
                            <div className="progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style={{ width: this.props.project.percentage + "%", color: "black" }}>{this.props.project.percentage}</div>
                        </div>
                    </div>
                </div>
                {this.state.btnStatus ? <OngoingViewDetails key={this.props.project.projectId} projectDetailsData={this.state.projectDetailsData} /> : null}
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(Ongoingcard);