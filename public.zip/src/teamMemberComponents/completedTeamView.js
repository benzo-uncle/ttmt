import React from 'react'
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

export class CompletedTeamView extends React.Component{
    render(){
    
       
       
        return(
            this.props.details.tasks.map((detail, index)=>(
            <React.Fragment>
                <div className="card-body">
                <div className="row ">
                    <div className="col-md-12">
                        <div>
                            <table className="table table-hover text-center">
                                <thead className="thead-light">
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Member Name</th>
                                        <th scope="col">Task Name</th>
                                        <th scope="col">Timeline</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">{index+1}</th>
                                        <td>{detail.empId}</td>
                                        <td>{detail.tasksName}</td>
                                        <td>
                                            <span className="text-info" style={{ fontSize: "14px" }}>Start Date : {new Date(detail.timeline.startDate).toLocaleDateString()}<br /> End Date : {new Date(detail.timeline.endDate).toLocaleDateString()}</span> &nbsp;
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            
        </React.Fragment>
            ))
        )
    }
}