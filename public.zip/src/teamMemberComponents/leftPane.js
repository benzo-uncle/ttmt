import React from 'react'
import Calendar from 'react-calendar'
import { Button } from 'primereact/button';
import axios from 'axios';
import ReactTooltip from 'react-tooltip';
import Alert from './alert';
import { connect } from 'react-redux';

const url = 'http://localhost:2040/viewOngoingProjectsForTeamMember/';
const url4 = 'http://localhost:2040/viewEventByEventId/';
const url2 = 'http://localhost:2040/viewEventByDate/';
const url1 = 'http://localhost:2040/createEvent/';
const url5 = 'http://localhost:2040/updateEvent/';
const url6 = 'http://localhost:2040/deleteEvent/';

class Leftpane extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            date: new Date(),
            today: new Date(),
            eventsArr: [],
            projectsArr: [],
            projectName: "",
            eventName: "",
            eventId: "",
            venue: "",
            time: "",
            reason: "",
            successMessage: "",
            successMessageCreateEvent: "",
            successMessageUpdateEvent: "",
            successMessageDeleteEvent: "",
            errorMessage: "",
            errorMessageCreateEvent: "",
            errorMessageUpdateEvent: "",
            errorMessageDeleteEvent: "",
            errorMessageNoEventOnThatDate: "",
            userId: this.props.loginDetails.userId,
            value: "3",
            alertStatus: false,
            formValidation: {
                projectName: false,
                eventName: false,
                venue: false,
                time: false,
                buttonValid: false,

            }

        }


    }
    componentDidMount() {
        this.fetchOngoingProjects();
        this.fetchEvents(this.state.date.toDateString());

    }

    handleSubmitForCreate = (event) => {
        event.preventDefault();
        this.createEvent();
    }
    handleSubmitforUpdate = (event) => {
        event.preventDefault();
        this.updateEvent();
    }
    handleSubmitforDelete = (event) => {
        event.preventDefault();
        this.deleteEvent();
    }

    fetchEvents = (eDate) => {
        axios.get(url2 + eDate + "/" + this.state.userId)
            .then(response => this.setState({ eventsArr: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, eventsArr: [] })
                } else {
                    this.setState({ errorMessage: error.message, eventsArr: [] })
                }
            })
    }


      onChange = date => {
        this.setState({ date })
        this.setState({ eventsArr: [] })
        this.fetchEvents(date.toDateString());
    }

    handleChange = (event) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        this.setState({ [name]: value });
        if (name === "projectName") {
            this.setState({ projectName: value })
        }
        this.validation(name, value);
    }


    handleChangeEvent = (event) => {
        const target = event.target;
        const value = target.value;
        this.setState({ eventId: value });
        this.fetchEventbyEventId(value);

    }

    fetchEventbyEventId = (eventId) => {
        axios.get(url4 + eventId)
            .then(response => this.setState({ eventId: response.data.eventId, eventName: response.data.eventName, userId: response.data.createdBy, projectName: response.data.projectName, time: response.data.time, venue: response.data.venue, reason: response.data.reason, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, eventId: "", eventName: "", projectName: "", time: "", venue: "", reason: "" })
                } else {
                    this.setState({ errorMessage: error.message, eventId: "", eventName: "", projectName: "", time: "", venue: "", reason: "" })
                }
            })
    }


    validation = (fieldName, value) => {
        var formValid = this.state.formValidation;
        if (fieldName === "projectName") {
            if (value === "") {
                formValid.projectName = false;
            }
            else {
                formValid.projectName = true;
            }
        }
        if (fieldName === "eventName") {
            if (value === "") {
                formValid.eventName = false;
            }
            else {
                formValid.eventName = true;
            }
        }
        else if (fieldName === "venue") {
            if (value === "") {
                formValid.venue = false;
            }
            else {
                formValid.venue = true;
            }
        }
        else if (fieldName === "time") {
            if (value === "00:00") {
                formValid.time = false;
            }
            else {
                formValid.time = true;
            }
        }
        formValid.buttonValid = formValid.eventName && formValid.venue && formValid.time && formValid.projectName
        this.setState({ formValidation: formValid });

    }






    formatDate(date) {
        var monthNames = [
            "January", "February", "March",
            "April", "May", "June", "July",
            "August", "September", "October",
            "November", "December"
        ];

        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();

        return day + ' ' + monthNames[monthIndex] + ' ' + year;
    }

    messageAction = (message, messageType) => {
        var action = {
            type: "ALERT_MESSAGE",
            message: message,
            messageType: messageType
        }
        this.props.dispatch(action);
        this.setState({ messageStatus: false })
    }



    createEvent = () => {
        var dateString = this.state.date.getMonth() + 1 + "-" + this.state.date.getDate() + "-" + this.state.date.getFullYear()
        var form = {
            eventName: this.state.eventName,
            createdBy: this.state.userId,
            projectName: this.state.projectName,
            members:[],
            eventDate: dateString,
            time: this.state.time,
            venue: this.state.venue,
            reason: this.state.reason,


        }
        this.setState({ successMessageCreateEvent: "", errorMessageCreateEvent: "" })
        axios.post(url1 + this.state.userId, form)
            .then(response => {
                this.messageAction(response.data.message, "success")
                this.setState({ alertStatus: true, errorMessage: [], eventId: "", eventName: "", projectName: "", time: "", venue: "", reason: "" });
            }).catch(error => {
                this.messageAction(error.response.data.message, "danger")
                this.setState({ alertStatus: true, errorMessageCreateEvent: error.response.data.message, successMessage: "" });
            });
    }


    updateEvent = () => {
        var dateString = this.state.date.getMonth() + 1 + "-" + this.state.date.getDate() + "-" + this.state.date.getFullYear()
        var form = {
            eventId: this.state.eventId,
            eventName: this.state.eventName,
            createdBy: this.state.userId,
            members:[],
            projectName: this.state.projectName,
            eventDate: dateString,
            time: this.state.time,
            venue: this.state.venue,
            reason: this.state.reason,


        }
        this.setState({ successMessageUpdateEvent: "", errorMessageUpdateEvent: "" })
        axios.put(url5 + this.state.userId + "/" + this.state.eventId, form)
            .then(response => {
                this.messageAction(response.data.message, "warn")
                this.setState({ errorMessageUpdateEvent: "", eventId: "", eventName: "", projectName: "", time: "", venue: "", reason: "", alertStatus: true });
                
            }).catch(error => {
                this.messageAction(error.response.data.message, "danger")
                this.setState({ alertStatus: true, errorMessageUpdateEvent: error.response.data.message, successMessageUpdateEvent: "" });
            });
    }

    deleteEvent = () => {
        this.setState({ successMessageDeleteEvent: "", errorMessageDeleteEvent: "" })
        axios.delete(url6 + this.state.eventId)
            .then(response => {
                this.messageAction(response.data.message, "info")
                this.setState({ alertStatus: true, successMessageDeleteEvent: response.data.message, errorMessage: [], eventId: "", eventName: "", projectName: "", time: "", venue: "", reason: "" });
               
            }).catch(error => {
                this.messageAction(error.response.data.message, "danger")
                this.setState({ alertStatus: true, errorMessageDeleteEvent: error.response.data.message, successMessage: "" });
            });
    }



    fetchOngoingProjects = () => {
        axios.get(url + this.state.userId)
            .then(response => this.setState({ projectsArr: response.data, errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, projectsArr: "" })
                } else {
                    this.setState({ errorMessage: error.message, projectsArr: "" })
                }
            })
    }

 

    render() {
        return (
            <React.Fragment>
                {this.state.alertStatus ? <Alert /> : null}

                <div className="row mt-2">
                    <div className="col-sm-12">
                        <Calendar onChange={this.onChange} value={this.state.date} className="card shadow border-0 bg-white rounded " />
                    </div>
                </div>
                <div className="row mt-1">
                    <div className="col-md-12">
                        <div className="card mt-1 shadow bg-white rounded" style={{ height: "14em" }}>
                            <div className="card-header text-success d-flex justify-content-center" style={{ backgroundColor: "#FFFACD", fontSize: "1.15em" }}>
                                Events on date :  {this.formatDate(this.state.date)}
                            </div>
                            <div className="card-body" style={{ paddingLeft: "0.5em", paddingRight: ".5em", paddingBottom: "0em", paddingTop: "0.3em", overflowY: "auto", backgroundColor: "#ffffe6" }}>
                                <ul className="list-group list-group-flush">
                                    {this.state.eventsArr.length > 0 ?
                                        this.state.eventsArr.map(event =>
                                            <li className="list-group-item list-group-item-action" style={{ paddingLeft: "0.5em", paddingRight: ".5em", paddingBottom: "0.3em", paddingTop: "0em", backgroundColor: "#ffffe6" }}>
                                                <a data-tip={event.reason} data-for="event">
                                                    <div className="row">
                                                        <div className="col-md-11 m-0 text-capitalize " style={{ fontSize: "0.85em", color: "#829356" }}>{event.projectName}</div>
                                                    </div>
                                                    <div className="row" style={{ marginTop: "-0.3em" }}>
                                                        <div className="col-md-1"></div>
                                                        <div className="col-md-8 p-0 text-capitalize" style={{ fontSize: "1em", color: "#107896" }}>{event.eventName}</div>
                                                        <div className="col-md-2 p-0 text-right" style={{ fontSize: "0.75em", color: "#c02f1d" }}><strong>{event.time}</strong></div>
                                                    </div>
                                                    <div className="row" style={{ marginTop: "-0.2em" }}>
                                                        <div className="col-md-1"></div>
                                                        <div className="col-md-10 p-0" style={{ fontSize: "0.75em", color: "#c02f1d" }}>Venue : {event.venue}</div>

                                                    </div>
                                                </a><ReactTooltip id="event" place="right" type="info" effect="float" className="w-25" html={true} />
                                            </li>)
                                        : null}

                                </ul>
                                {this.state.eventsArr.length > 0 ? null : <div className="text-center text-secondary" style={{ marginTop: "3.5em", backgroundColor: "#ffffe6" }}><h3>No Events to Display</h3></div>}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row mt-2">
                    {/* <div className="col-md-6 d-flex justify-content-center">
                        <Button label="Report" className="p-button-raised p-button-success " icon="pi pi-download" data-toggle="modal" data-target="#exampleModalCenter1" />
                    </div>
                    <div className="col-md-6 d-flex justify-content-center">
                    <a data-tip={this.state.value} data-for="rating">
                    <Rating value={this.state.value} cancel={false} readonly={true} onChange={(e) => this.setState({ value: e.value })}/>
                    </a><ReactTooltip id="rating" place="right" type="info" effect="float" html={true} />
                    </div> */}
                    <div className="col-md-6 d-flex justify-content-center">
                        <Button label="Create Event" className="p-button-raised p-button-success " icon="pi pi-calendar-plus" data-toggle="modal" data-target="#exampleModalCenter1" />
                    </div>
                    <div className="col-md-6 d-flex justify-content-center">
                        <Button label="Update Event" className="p-button-raised p-button-secondary" icon="pi pi-replay" data-toggle="modal" data-target="#exampleModalCenter2" />
                    </div>
                </div>


                <div className="modal fade" id="exampleModalCenter1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-centered modal-lg" role="document">
                        <div className="modal-content">
                            <div className="modal-header bg-light ">
                                <h5 className="modal-title text-success" id="exampleModalLongTitle">Create Event for {this.formatDate(this.state.date)}</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <form>
                                    <div className="row form-group">
                                        <label for="projectName" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Project Name :</strong></label>
                                        <select name="projectName" value={this.state.projectName} className="col-sm-4 form-control form-control-sm" id="projectName" onChange={this.handleChange} >
                                            <option value="" selected>--SELECT--</option>
                                            {this.state.projectsArr.length > 0 ?
                                                this.state.projectsArr.map(project => <option key={project.projectId} value={project.projectName}>{project.projectName}</option>)
                                                : null}
                                        </select>
                                        <label for="eventName" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Event Name :</strong></label>
                                        <input type='text' name="eventName" value={this.state.eventName} className="col-sm-3 form-control form-control-sm" id="eventName" placeholder="Enter Event Name" onChange={this.handleChange} />
                                    </div>
                                    <div className="row form-group">
                                        <label for="time" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Time : </strong></label>
                                        <input type="time" name="time" value={this.state.time} className="col-sm-2 form-control form-control-sm" id="time" onChange={this.handleChange} />
                                        <div className="col-sm-2"></div>
                                        <label for="venue" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Venue : </strong></label>
                                        <input type="text" name="venue" value={this.state.venue} className="col-sm-2 form-control form-control-sm" id="venue" onChange={this.handleChange} placeholder="Enter Venue" />
                                    </div>

                                    <div className="row form-group">
                                        <label for="reason" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Reason : </strong></label>
                                        <input type="text" name="reason" value={this.state.reason} className="col-sm-9 form-control form-control-sm" id="reason" onChange={this.handleChange} placeholder="Enter Reason" />

                                    </div>

                                </form>
                            </div>
                            <div className="modal-footer">

                                <span className="text-success font-weight-bold message">
                                    {this.state.successMessage}
                                </span>
                                <span className="text-danger font-weight-bold message">
                                    {this.state.errorMessage}
                                </span>
                                <Button className="float-right" type="submit" name="submitButton" label="Save" className="close" data-dismiss="modal" icon="pi pi-save" disabled={!this.state.formValidation.buttonValid} onClick={this.handleSubmitForCreate} className="p-button p-button-success shadow" />
                            </div>
                        </div>
                    </div>
                </div>




                <div className="modal fade" id="exampleModalCenter2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-centered modal-lg" role="document">
                        <div className="modal-content">
                            <div className="modal-header ">
                                <h5 className="modal-title text-success" id="exampleModalLongTitle">Update Event for {this.formatDate(this.state.date)}</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <form>
                                    <div className="row form-group">
                                        <label for="eventName" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Event Name :</strong></label>
                                        <select name="eventName" value={this.state.eventId} className="col-sm-4 form-control form-control-sm" id="eventName" onChange={this.handleChangeEvent} >
                                            <option value="" selected>--SELECT--</option>
                                            {this.state.eventsArr.length > 0 ?
                                                this.state.eventsArr.map(event => <option key={event.eventId} value={event.eventId}>{event.eventName}</option>)
                                                : null}
                                        </select>
                                        <label for="projectName" className="col-sm-2 col-form-label col-form-label-sm text-info"><strong>Project Name :</strong></label>
                                        <select name="projectName" value={this.state.projectName} className="col-sm-3 form-control form-control-sm" id="projectName" onChange={this.handleChange} >
                                            <option value="" selected>--SELECT--</option>
                                            {this.state.projectsArr.length > 0 ?
                                                this.state.projectsArr.map(project => <option key={project.projectId} value={project.projectName}>{project.projectName}</option>)
                                                : null}
                                        </select>
                                    </div>
                                    <div className="row form-group">
                                        <label for="time" className="col-sm-2 col-form-label col-form-label-sm text-info "><strong>Time : </strong></label>
                                        <input type="time" name="time" value={this.state.time} className="col-sm-2 form-control form-control-sm" id="time" onChange={this.handleChange} />
                                        <div className="col-sm-2"></div>
                                        <label for="venue" className="col-sm-2 col-form-label col-form-label-sm text-info "><strong>Venue : </strong></label>
                                        <input type="text" name="venue" value={this.state.venue} className="col-sm-2 form-control form-control-sm" id="venue" onChange={this.handleChange} />
                                    </div>

                                    <div className="row form-group">
                                        <label for="reason" className="col-sm-2 col-form-label col-form-label-sm text-info "><strong>Reason : </strong></label>
                                        <input type="text" name="reason" value={this.state.reason} className="col-sm-9 form-control form-control-sm" id="reason" onChange={this.handleChange} />

                                    </div>

                                </form>
                            </div>
                            <div className="modal-footer">
                                <span className="text-success font-weight-bold message">
                                    {this.state.successMessage}
                                </span>
                                <span className="text-danger font-weight-bold message">
                                    {this.state.errorMessage}
                                </span>
                                <Button type="submit" name="submitButton" label="Save" icon="fa fa-pencil-square-o" className="close" data-dismiss="modal" onClick={this.handleSubmitforUpdate} className="p-button p-button-info shadow" />
                                <Button type="submit" name="submitButton" label="Delete" icon="fa fa-times" className="close" data-dismiss="modal" onClick={this.handleSubmitforDelete} className="p-button-danger shadow" />
                            </div>
                        </div>
                    </div>
                </div>



            </React.Fragment>
        )
    }
}



const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(Leftpane);
