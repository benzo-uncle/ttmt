import React from 'react';
import axios from "axios";
import { ProgressSpinner } from 'primereact/progressspinner';
import { connect } from 'react-redux'
import { MySpinner } from '../MySpinner';
import {Calendar} from 'primereact/calendar';

const url = 'http://localhost:2040/viewOngoingTasksForTeamMember/';
const url1 = 'http://localhost:2040/updateStatus/';
class Tasks extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            taskStatus: "",
            id: this.props.loginDetails.userId,
            taskArr: [],
            taskArr1:[],
            errorMessage: "",
            successMessage: "",

            projectName: "",
            projectId: "",
            userId: "",
            taskStatus: "",
            taskName: "",
            tasksId: "",
            startDate: "",
            endDate: "",
            modalValidationStatus:false,
            dates2:[]
        };

    }
    handleChange = (event) => {
        this.setState({ taskStatus: event.target.value })
        this.validation(event.target.value);
    }

    validation = (value) => {
        if (value === "") {
            this.setState({ modalValidationStatus: false })
        }
        else {
            this.setState({ modalValidationStatus: true })
        }
    }

    handleClick = (event) => {
        event.preventDefault();
        this.updateRequest();
    }

    componentDidMount() {
        this.fetchOngoingTasks();
    }
    fetchOngoingTasks = () => {
        axios.get(url + this.state.id)
            .then(response => this.setState({ taskArr: response.data,taskArr1:response.data,errorMessage: "" }))
            .catch(error => {
                if (error.status === 404) {
                    this.setState({ errorMessage: error.response.data.message, taskArr: [] })
                } else {
                    this.setState({ errorMessage: error.message, taskArr: [] })
                }
            })
    }
    createForm = (task) => {

        this.setState({ projectId: task.projectId, projectName: task.projectName, tasksId: task.tasksId, taskName: task.tasksName, startDate: task.timeline.startDate, endDate: task.timeline.endDate })
    }
    updateRequest = () => {
        var form = {
            projectName: this.state.projectName,
            projectId: this.state.projectId,
            userId: this.state.id,
            taskName: this.state.taskName,
            tasksId: this.state.tasksId,
            timeline: {
                startDate: this.state.startDate,
                endDate: this.state.endDate
            },
            taskStatus: this.state.taskStatus
        }

        this.setState({ successMessage: "", errorMessage: "" })
        axios.post(url1 + this.state.id, form)
            .then(response => {
                this.setState({ successMessage: response.data.message, errorMessage: "" });
                this.fetchOngoingTasks();
            }).catch(error => { this.setState({ errorMessage: error.response.data.message, successMessage: "" }); });
    }

////////////////////////
handelChange=(event)=>{
    const target = event.target;
    const value = target.value;
    if(target.name==="searchTasks"){
    this.setState({projectName:value})
var  value1=value.toLowerCase()
var Regex = new RegExp(value1);
var arr=[]
this.state.taskArr.map((project)=>{
            
            if(project.projectName.toLowerCase().match(Regex)){
                          arr.push(project)          
                
            }
        
    })
    this.setState({taskArr1:arr})
}
else{
this.setState({dates2:value})
var startDate=new Date(value[0])
var endDate=new Date(value[1])

var arr=[]

this.state.taskArr.map((project)=>{
        
            if(new Date(project.tasks.timeline.startDate)>=startDate && new Date(project.tasks.timeline.endDate)<=(endDate)){
                    arr.push(project)          
                
            }
        
    })
    this.setState({taskArr1:arr})


}}






    createOngoingTaskCard = (task) => {
        return (
            <div className="card border shadow-lg m-1">
                <div className="card-body">
                    <div className="row">
                        <div className="col-md-12">
                            <span className="text-info"><b>Project Name:  </b></span><span>{task.projectName}</span>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-3">
                            <span className="text-info"><b>Task Name :  </b>{task.tasksName}</span>
                        </div>
                        <div className="col-md-4">
                            <span className="text-info"><b>Task Description :  </b>{task.comment}</span>
                        </div>
                        <div className="col-md-3 offset-2">
                            <button type="button" onClick={() => { this.createForm(task) }} class="btn shadow-lg btn-warning " data-toggle="modal" data-target="#updateStatus">
                                Update Status
                            </button>
                            <div className="modal fade" id="updateStatus" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div className="modal-dialog modal-dialog-centered" role="document">
                                    <div className="modal-content">
                                        <div className="modal-header">
                                            <h5 className="modal-title" id="exampleModalLabel">Update Status</h5>
                                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div className="modal-body">
                                            <form>
                                                <div className="form-group">
                                                    <label htmlFor="taskStatus" className="col-form-label">Task Status:</label>
                                                    <input type="text" className="form-control" id="taskStatus" value={this.state.taskStatus} onChange={this.handleChange} />
                                                </div>
                                            </form>
                                            <span className="text-success font-weight-bold message">
                                                {this.state.successMessage}
                                            </span>
                                            <span className="text-danger font-weight-bold message">
                                                {this.state.errorMessage}
                                            </span>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-primary" disabled={!this.state.modalValidationStatus} onClick={this.handleClick} data-dismiss="modal">Update Status</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-2">
                            <span className="text-info"><b>From :  </b>{new Date(task.timeline.startDate).toLocaleDateString()}</span>
                        </div>
                        <div className="col-md-2">
                            <span className="text-info"><b>To :  </b>{new Date(task.timeline.endDate).toLocaleDateString()}</span>
                        </div>
                        <div className="col-md-4 offset-1">
                            <span className="text-danger"><b>Days Allocated :  </b>{new Date(new Date(task.timeline.endDate) - new Date(task.timeline.startDate)).getDate()}</span>
                        </div>
                    </div>

                </div>
            </div>
        )
    }
    render() {
        console.log(this.state.taskArr,"tasks h ye bc")

        return (
            <React.Fragment>
                <div className="row" style={{ marginBottom: "-0.5em", marginLeft: "-0.9em" }}>
                    <div className="col-sm-8 form-group ">
                        <input type="text" className="form-control form-control-sm" placeholder="Search for tasks" name="searchTasks" value={this.state.projectName} onChange={this.handelChange} />  
                    </div>
                    <div className="col-sm-4 form-group ">
                    <Calendar value={this.state.dates2} placeholder="Staring and End Date" onChange={this.handelChange} name="dates2" selectionMode="range" readonlyInput={true} />
                    </div>
                    </div>

                {this.state.taskArr1.length ? this.state.taskArr1.map((task) => (this.createOngoingTaskCard(task))) : <MySpinner/>}

            </React.Fragment>
        )
    }
}

const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(Tasks);
