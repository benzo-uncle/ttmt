import React from 'react';
import axios from 'axios';
import { ProgressSpinner } from 'primereact/progressspinner';
import { connect } from 'react-redux'
import { MySpinner } from '../MySpinner';
const url = "http://localhost:2040/viewRequestsForTeamMember/";
class ViewRequest extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            requestData: [],
            errorMessage: '',
            id: this.props.loginDetails.userId
        }
    }
    componentDidMount() {
        this.fetchRequest();
    }
    fetchRequest = () => {
        axios.get(url + this.state.id).then(response => {
            this.setState({ requestData: response.data, errorMessage: '' })
        }).catch((error) => {
            if (error.status === 404) {
                this.setState({ errorMessage: error.response.data.message, requestData: [] })
            } else {
                this.setState({ errorMessage: error.message, requestData: [] })
            }
        })
    }

    requestStatusStyle = (requestStatus) => {
        if (requestStatus === "Accepted") {
            return <div className="text-success">ACCEPTED</div>
        }
        else if (requestStatus === "Pending") {
            return <div className="text-warning">PENDING</div>
        }
        else {
            return <div className="text-danger">REJECTED</div>
        }
    }

    generateRequestCard = (request) => {
        if (request.requestType === 'TimeExtension') {
            return (<div className="row m-1">
                <div className="col-md-12">
                    <div className="card">
                        <div className="card-body shadow-lg rounded">
                            <div className="card-title">
                                <div className="row" style={{ marginBottom: "-10px" }}>
                                    <div className="col-md-12 text-info">
                                        <span><b>Time Extension Request</b></span>
                                    </div>
                                </div>
                            </div>
                            <hr />
                            <div className="card-text">
                                <div className="row" style={{ marginTop: "-10px" }}>
                                    <div className="col-md-9" style={{ marginTop: "-25px" }}>
                                        <span className="text-info"><b>Project Name :  </b></span><span className="text-muted">{request.projectName}</span>
                                        <span className="text-info m-4"><b>Task Name :  </b><span className="text-muted">{request.taskName}</span></span>
                                    </div>
                                    <div className="col-md-3">
                                        <h4><span><b>{this.requestStatusStyle(request.requestStatus)}</b></span></h4>
                                    </div>
                                </div>
                                <div className="row" style={{ marginTop: "-10px" }}>
                                    <div className="col-md-12" style={{ marginTop: "-10px" }} >
                                        <span className="text-danger"><b>Extension Required :  </b><span>{request.NoOfDays}</span></span>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-12" style={{ marginTop: "5px" }}>
                                        <span className="text-muted"><i><b>Reason :  </b><span className="text-muted">{request.requestReason}</span></i></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>)
        }
        else if (request.requestType === 'Leave') {
            return (<div className="row m-1">
                <div className="col-md-12">
                    <div className="card">
                        <div className="card-body shadow-lg rounded">
                            <div className="card-title">
                                <div className="row" style={{ marginBottom: "-10px" }}>
                                    <div className="col-md-12 text-info">
                                        <span><b>Leave Request</b></span>
                                    </div>
                                </div>
                            </div>
                            <hr />
                            <div className="card-text">
                                <div className="row" style={{ marginTop: "-10px" }}>
                                    <div className="col-md-8" style={{ marginTop: "-25px" }}>
                                        <span className="text-info"><b>From :  </b></span><span className="text-muted">{new Date(request.timeline.startDate).toLocaleDateString()}</span>
                                        <span className="text-info m-4"><b>To :  </b><span className="text-muted">{new Date(request.timeline.endDate).toLocaleDateString()}</span></span>
                                    </div>
                                    <div className="col-md-3 offset-1">
                                        <h4><span><b>{this.requestStatusStyle(request.requestStatus)}</b></span></h4>
                                    </div>
                                </div>
                                <div className="row" style={{ marginTop: "-10px" }}>
                                    <div className="col-md-12">
                                        <span className="text-muted"><i><b>Reason :  </b><span className="text-muted">{request.requestReason}</span></i></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>)
        }
        else if (request.requestType === 'NewTask') {
            return (

                <div className="row m-1">
                    <div className="col-md-12">
                        <div className="card">
                            <div className="card-body shadow-lg rounded">
                                <div className="card-title">
                                    <div className="row" style={{ marginBottom: "-10px" }}>
                                        <div className="col-md-12 text-info">
                                            <span><b>New Task Request</b></span>
                                        </div>
                                    </div>
                                </div>
                                <hr />
                                <div className="card-text">
                                    <div className="row" style={{ marginTop: "-10px" }}>
                                        <div className="col-md-9" style={{ marginTop: "-25px" }}>
                                            <span className="text-info"><b>Project Name :  </b></span><span className="text-muted">{request.projectName}</span>
                                            <span className="text-info m-4"><b>Task Name :  </b><span className="text-muted">{request.taskName}</span></span>
                                        </div>
                                        <div className="col-md-3">
                                            <h4><span><b>{this.requestStatusStyle(request.requestStatus)}</b></span></h4>
                                        </div>
                                    </div>
                                    <div className="row" style={{ marginTop: "-10px" }}>
                                        <div className="col-md-12" style={{ marginTop: "-25px" }}>
                                            <span className="text-muted"><i><b>Reason :  </b><span className="text-muted">{request.requestReason}</span></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )

        }
        else {
            return (
                <div className="row m-1">
                    <div className="col-md-12">
                        <div className="card">
                            <div className="card-body shadow-lg rounded">
                                <div className="card-title">
                                    <div className="row" style={{ marginBottom: "-10px" }}>
                                        <div className="col-md-12 text-info">
                                            <span><b>Update Request</b></span>
                                        </div>
                                    </div>
                                </div>
                                <hr />
                                <div className="card-text">
                                    <div className="row" style={{ marginTop: "-10px" }}>
                                        <div className="col-md-9" style={{ marginTop: "-25px" }}>
                                            <span className="text-info"><b>Project Name :  </b></span><span className="text-muted">{request.projectName}</span>
                                            <span className="text-info m-4"><b>Task Name :  </b><span className="text-muted">{request.taskName}</span></span>
                                        </div>
                                        <div className="col-md-3">
                                            <h4><span><b>{this.requestStatusStyle(request.requestStatus)}</b></span></h4>
                                        </div>
                                    </div>
                                    <div className="row" style={{ marginTop: "-10px" }}>
                                        <div className="col-md-12" style={{ marginTop: "-5px" }}>
                                            <span className="text-muted"><i><b>Task Status :  </b><span className="text-muted">{request.taskStatus}</span></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )
        }
    }
    render() {
        return (
            <div>
                {this.state.requestData.length > 0 ? this.state.requestData.map((request) => this.generateRequestCard(request)) : <MySpinner/>}
            </div>

        )
    }
}


const mapStateToProps = (state) => {
    return { loginDetails: state.loginDetails }
}

export default connect(mapStateToProps)(ViewRequest);
